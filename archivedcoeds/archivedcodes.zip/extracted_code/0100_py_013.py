"""
read_mca_raw.py — Parse .mca files directly from binary (no anvil-parser).
Works with Java Edition region files (both old and modern formats).

Requirements:
    pip install nbt

Usage:
    python read_mca_raw.py                   # searches current directory
    python read_mca_raw.py /path/to/region   # specific folder
    python read_mca_raw.py file.mca          # single file
"""

import sys
import os
import glob
import struct
import zlib
import gzip
import io

try:
    import nbt
    from nbt import nbt as nbtlib
except ImportError:
    sys.exit("Missing dependency. Install it with:\n    pip install nbt\n")


# ──────────────────────────────────────────────
# Region file reader (raw binary, no anvil-parser)
# ──────────────────────────────────────────────

SECTOR = 4096  # bytes per sector in .mca files

def read_chunk_nbt(data: bytes):
    """Decompress and parse NBT from raw chunk bytes."""
    if len(data) < 5:
        return None
    length = struct.unpack(">I", data[0:4])[0]
    compression = data[4]
    payload = data[5:5 + length - 1]

    if compression == 2:          # zlib (most common)
        raw = zlib.decompress(payload)
    elif compression == 1:        # gzip
        raw = gzip.decompress(payload)
    elif compression == 3:        # uncompressed
        raw = payload
    else:
        return None               # unknown compression

    return nbtlib.NBTFile(buffer=io.BytesIO(raw))


def get_block_from_section_116_plus(section, x, y_in_section, z):
    """
    Read a block from a 1.16+ palette-based section.
    Returns block name string or None.
    """
    try:
        palette = section["block_states"]["palette"]
    except KeyError:
        try:
            palette = section["Palette"]
        except KeyError:
            return None

    if len(palette) == 0:
        return None

    if len(palette) == 1:
        # Only one block type — no bit-packed array needed
        block = palette[0]
        name = str(block["Name"])
        return name

    # Read the packed long array
    try:
        states = section["block_states"]["data"]
    except KeyError:
        try:
            states = section["BlockStates"]
        except KeyError:
            return None

    palette_size = len(palette)
    bits = max(4, (palette_size - 1).bit_length())

    # Block index within section (0–4095)
    block_index = (y_in_section * 16 + z) * 16 + x

    # Two packing formats: pre-1.16 (values span longs) and 1.16+ (values don't)
    values_per_long = 64 // bits

    long_index = block_index // values_per_long
    bit_offset = (block_index % values_per_long) * bits

    if long_index >= len(states):
        return None

    long_val = states[long_index].value
    # Convert signed to unsigned
    if long_val < 0:
        long_val += (1 << 64)

    mask = (1 << bits) - 1
    palette_idx = (long_val >> bit_offset) & mask

    if palette_idx >= len(palette):
        return None

    return str(palette[palette_idx]["Name"])


def iter_blocks_raw(mca_path: str):
    """
    Read every non-air block from an .mca file.
    Yields (chunk_x, chunk_z, x, y, z, block_name).
    """
    with open(mca_path, "rb") as f:
        header = f.read(SECTOR * 2)

    if len(header) < SECTOR:
        return

    file_size = os.path.getsize(mca_path)

    for chunk_z in range(32):
        for chunk_x in range(32):
            offset_entry = (chunk_x + chunk_z * 32) * 4
            offset_raw = struct.unpack(">I", header[offset_entry:offset_entry + 4])[0]
            offset_sectors = offset_raw >> 8
            size_sectors = offset_raw & 0xFF

            if offset_sectors == 0 or size_sectors == 0:
                continue  # chunk not generated

            byte_offset = offset_sectors * SECTOR
            byte_length = size_sectors * SECTOR

            if byte_offset + byte_length > file_size:
                continue

            with open(mca_path, "rb") as f:
                f.seek(byte_offset)
                chunk_data = f.read(byte_length)

            nbt_data = read_chunk_nbt(chunk_data)
            if nbt_data is None:
                continue

            # Locate sections (differs between old/new format)
            try:
                # 1.18+ format: top-level sections
                sections = nbt_data["sections"]
            except KeyError:
                try:
                    sections = nbt_data["Level"]["Sections"]
                except KeyError:
                    continue

            for section in sections:
                try:
                    section_y = section["Y"].value
                except (KeyError, AttributeError):
                    continue

                y_base = section_y * 16

                for y_local in range(16):
                    for z_local in range(16):
                        for x_local in range(16):
                            name = get_block_from_section_116_plus(
                                section, x_local, y_local, z_local
                            )
                            if name is None:
                                continue
                            if name in ("minecraft:air",
                                        "minecraft:cave_air",
                                        "minecraft:void_air"):
                                continue
                            yield chunk_x, chunk_z, x_local, y_base + y_local, z_local, name


# ──────────────────────────────────────────────
# File processing
# ──────────────────────────────────────────────

def process_file(mca_path: str, verbose: bool = True) -> dict:
    print(f"\n{'='*60}")
    print(f"File: {mca_path}")
    print(f"Size: {os.path.getsize(mca_path):,} bytes")
    print(f"{'='*60}")

    block_count = 0
    type_counts: dict[str, int] = {}
    printed = 0

    try:
        for chunk_x, chunk_z, x, y, z, name in iter_blocks_raw(mca_path):
            block_count += 1
            type_counts[name] = type_counts.get(name, 0) + 1

            if verbose and printed < 10_000:
                print(f"  chunk({chunk_x:2d},{chunk_z:2d})  "
                      f"pos({x:2d},{y:4d},{z:2d})  {name}")
                printed += 1

    except Exception as e:
        print(f"  ERROR while reading: {e}")

    if verbose and block_count > 10_000:
        print(f"\n  ... output truncated after 10,000 lines ...")

    print(f"\n  --- Summary ---")
    print(f"  Total non-air blocks : {block_count:,}")
    print(f"  Unique block types   : {len(type_counts):,}")

    if type_counts:
        print("  Top 20 block types:")
        for name, count in sorted(type_counts.items(),
                                  key=lambda kv: kv[1], reverse=True)[:20]:
            print(f"    {count:>12,}  {name}")

    return type_counts


def find_mca_files(path: str) -> list[str]:
    if os.path.isfile(path) and path.endswith(".mca"):
        return [path]
    pattern = os.path.join(path, "**", "*.mca")
    return sorted(glob.glob(pattern, recursive=True))


def main():
    target = sys.argv[1] if len(sys.argv) > 1 else "."
    target = os.path.abspath(target)

    print(f"Searching: {target}")
    files = find_mca_files(target)

    if not files:
        print("No .mca files found.")
        return

    print(f"Found {len(files)} .mca file(s).")

    grand_total = 0
    grand_types: dict[str, int] = {}

    for path in files:
        counts = process_file(path, verbose=True)
        for name, n in counts.items():
            grand_total += n
            grand_types[name] = grand_types.get(name, 0) + n

    print(f"\n{'#'*60}")
    print(f"GRAND TOTAL across all files")
    print(f"{'#'*60}")
    print(f"  Total non-air blocks : {grand_total:,}")
    print(f"  Unique block types   : {len(grand_types):,}")
    if grand_types:
        print("  Top 30 block types (all files combined):")
        for name, count in sorted(grand_types.items(),
                                  key=lambda kv: kv[1], reverse=True)[:30]:
            print(f"    {count:>12,}  {name}")

    print("\nDone.")


if __name__ == "__main__":
    main()
