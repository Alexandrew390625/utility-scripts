    92	# Rasterize a single page (page 3 here) at 150 DPI
    93	pdftoppm -jpeg -r 150 -f 3 -l 3 document.pdf /tmp/page
    94	
    95	# pdftoppm zero-pads the output filename based on TOTAL page count
    96	# (e.g., page-03.jpg for a 50-page PDF, page-003.jpg for 200+ pages)
    97	# Don't guess the filename — find it:
    98	ls /tmp/page-*.jpg
    99	