    68	// ✅ CORRECT: Multiple bullets
    69	slide.addText([
    70	  { text: "First item", options: { bullet: true, breakLine: true } },
    71	  { text: "Second item", options: { bullet: true, breakLine: true } },
    72	  { text: "Third item", options: { bullet: true } }
    73	], { x: 0.5, y: 0.5, w: 8, h: 3 });
    74	
    75	// ❌ WRONG: Never use unicode bullets
    76	slide.addText("• First item", { ... });  // Creates double bullets
    77	
    78	// Sub-items and numbered lists
    79	{ text: "Sub-item", options: { bullet: true, indentLevel: 1 } }
    80	{ text: "First", options: { bullet: { type: "number" }, breakLine: true } }
    81	