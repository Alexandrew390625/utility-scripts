const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");

// Color palette - Ocean/Australia theme
const COLORS = {
  darkBlue: "003366",
  medBlue: "005B99",
  lightBlue: "0077CC",
  gold: "FFCC00",
  darkGold: "CC9900",
  white: "FFFFFF",
  offWhite: "F4F8FC",
  lightGray: "E8EEF4",
  darkGray: "2D3A4A",
  text: "1A2B3C",
  accent: "FF6B35",
  green: "2D7D46",
};

const makeShadow = () => ({ type: "outer", blur: 8, offset: 3, angle: 135, color: "000000", opacity: 0.15 });

async function createPresentation() {
  let pres = new pptxgen();
  pres.layout = "LAYOUT_16x9";
  pres.title = "Australia - Prezentare Geografică";

  // ============================================================
  // SLIDE 1 - Informații Generale
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkBlue };

    // Top accent band
    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.gold }, line: { color: COLORS.gold } });

    // Australian flag from Wikipedia (SVG)
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Flag_of_Australia_%28converted%29.svg/640px-Flag_of_Australia_%28converted%29.svg.png",
      x: 0.4, y: 0.25, w: 3.8, h: 1.9,
    });

    // Coat of Arms
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Coat_of_Arms_of_Australia.svg/500px-Coat_of_Arms_of_Australia.svg.png",
      x: 0.4, y: 2.35, w: 1.4, h: 1.8,
    });

    // Title
    slide.addText("Commonwealth of Australia", {
      x: 4.6, y: 0.3, w: 5.2, h: 0.8,
      fontSize: 28, bold: true, color: COLORS.white,
      fontFace: "Calibri", align: "left",
    });
    slide.addText("Commonwealth-ul Australiei", {
      x: 4.6, y: 1.0, w: 5.2, h: 0.5,
      fontSize: 17, color: COLORS.gold, fontFace: "Calibri", align: "left", italic: true,
    });

    // Info cards - right side
    const stats = [
      { label: "Suprafață", value: "7.692.024 km²", icon: "🗺️" },
      { label: "Populație", value: "~27,1 milioane", icon: "👥" },
      { label: "Capitală", value: "Canberra", icon: "🏛️" },
      { label: "Cel mai mare oraș", value: "Sydney", icon: "🌆" },
    ];
    stats.forEach((s, i) => {
      const cx = 4.6 + (i % 2) * 2.7;
      const cy = 1.65 + Math.floor(i / 2) * 1.3;
      slide.addShape(pres.shapes.RECTANGLE, {
        x: cx, y: cy, w: 2.5, h: 1.1,
        fill: { color: "FFFFFF", transparency: 92 },
        line: { color: COLORS.gold, width: 1.5 },
        shadow: makeShadow(),
      });
      slide.addText(s.icon + "  " + s.label, {
        x: cx + 0.1, y: cy + 0.08, w: 2.3, h: 0.35,
        fontSize: 10, color: COLORS.gold, fontFace: "Calibri", bold: true,
      });
      slide.addText(s.value, {
        x: cx + 0.1, y: cy + 0.42, w: 2.3, h: 0.5,
        fontSize: 13, color: COLORS.white, fontFace: "Calibri", bold: true,
      });
    });

    // Bottom stema label
    slide.addText("Stema Australiei", {
      x: 0.4, y: 4.2, w: 1.7, h: 0.3,
      fontSize: 9, color: COLORS.gold, fontFace: "Calibri", align: "center", italic: true,
    });

    // Bottom info bar
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 5.12, w: 10, h: 0.5,
      fill: { color: COLORS.medBlue }, line: { color: COLORS.medBlue },
    });
    slide.addText("Al 6-lea continent ca suprafață  •  Singurul continent-stat din lume  •  Densitate: 3,5 loc/km²", {
      x: 0.2, y: 5.17, w: 9.6, h: 0.4,
      fontSize: 11, color: COLORS.gold, fontFace: "Calibri", align: "center", bold: true,
    });
  }

  // ============================================================
  // SLIDE 2 - Harta și Vecinii
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.offWhite };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.darkBlue }, line: { color: COLORS.darkBlue } });

    slide.addText("🗺️ Harta Australiei și Vecinii", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    // Map image
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Australia_with_AAT_%28orthographic_projection%29.svg/640px-Australia_with_AAT_%28orthographic_projection%29.svg.png",
      x: 0.3, y: 0.9, w: 5.5, h: 4.2,
    });

    // Neighbor cards
    const neighbors = [
      { name: "Indonezia", dir: "Nord-Vest", dist: "~500 km" },
      { name: "Papua Noua Guinee", dir: "Nord", dist: "~150 km" },
      { name: "Insulele Solomon", dir: "Nord-Est", dist: "~1.700 km" },
      { name: "Noua Zeelandă", dir: "Sud-Est", dist: "~2.000 km" },
      { name: "Timor de Est", dir: "Nord", dist: "~500 km" },
    ];

    slide.addText("Vecini și Proximitate Geografică", {
      x: 6.0, y: 0.9, w: 3.8, h: 0.45,
      fontSize: 14, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    neighbors.forEach((n, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 6.0, y: 1.45 + i * 0.72, w: 3.8, h: 0.62,
        fill: { color: COLORS.darkBlue }, line: { color: COLORS.medBlue },
        shadow: makeShadow(),
      });
      slide.addText(n.name, {
        x: 6.1, y: 1.48 + i * 0.72, w: 2.5, h: 0.3,
        fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(n.dir + "  |  " + n.dist, {
        x: 6.1, y: 1.75 + i * 0.72, w: 3.5, h: 0.25,
        fontSize: 10, color: COLORS.white, fontFace: "Calibri",
      });
    });

    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 5.12, w: 10, h: 0.5,
      fill: { color: COLORS.darkBlue }, line: { color: COLORS.darkBlue },
    });
    slide.addText("Australia este înconjurată de Oceanul Indian la Vest, Oceanul Pacific la Est și Oceanul Antarctic la Sud", {
      x: 0.2, y: 5.17, w: 9.6, h: 0.4,
      fontSize: 10, color: COLORS.white, fontFace: "Calibri", align: "center",
    });
  }

  // ============================================================
  // SLIDE 3 - Cadrul Natural
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkGray };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.accent }, line: { color: COLORS.accent } });

    slide.addText("🌿 Cadrul Natural al Australiei", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.white, fontFace: "Calibri",
    });

    // Uluru image
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Uluru_Landscape.jpg/640px-Uluru_Landscape.jpg",
      x: 0.3, y: 0.9, w: 4.2, h: 2.8,
    });

    // Great Barrier Reef
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Coral_reef_at_palmyra.jpg/640px-Coral_reef_at_palmyra.jpg",
      x: 0.3, y: 3.8, w: 4.2, h: 1.65,
    });

    // Right side content
    const sections = [
      {
        title: "🏔️ Relief",
        text: "Australia are un relief variat: Great Dividing Range (Est, cel mai lung lanț muntos), Câmpia Centrală Australiană, Podișul Vestic (67% din teritoriu) și Munții Snowy (2.228m - Mt. Kosciuszko - cel mai înalt vârf)."
      },
      {
        title: "🌊 Fluvii și Lacuri",
        text: "Murray-Darling (3.750 km) - cel mai important sistem fluvial. Lacul Eyre (Kati Thanda) - cel mai mare lac, frecvent secat. Râul Murchison, Fitzroy și Ord sunt alte artere importante."
      },
      {
        title: "🌡️ Climate",
        text: "Climate tropicale în Nord, deșertice în centru (Marele Deșert Victoria, Gibson, Simpson), temperate în Sud-Est. 70% din teritoriu primește sub 500mm ploaie/an."
      },
      {
        title: "🐨 Faună Unică",
        text: "Australia găzduiește mamifere marsupiale unice: cangur, koala, wombat, diavol tasmaniac. 80% din specii sunt endemice. Platypus și echidna sunt singurele mamifere ovipare."
      },
    ];

    sections.forEach((s, i) => {
      const x = 4.7;
      const y = 0.9 + i * 1.15;
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y, w: 5.1, h: 1.05,
        fill: { color: "FFFFFF", transparency: 88 },
        line: { color: COLORS.accent, width: 1.5 },
        shadow: makeShadow(),
      });
      slide.addText(s.title, {
        x: x + 0.12, y: y + 0.06, w: 4.8, h: 0.32,
        fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(s.text, {
        x: x + 0.12, y: y + 0.38, w: 4.85, h: 0.62,
        fontSize: 9.5, color: COLORS.white, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 4 - Populatie si Demografie
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.offWhite };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.darkBlue }, line: { color: COLORS.darkBlue } });
    slide.addText("👥 Populație & Demografie", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    // Big stat boxes
    const bigStats = [
      { val: "27,1M", label: "Populație totală\n(2024)" },
      { val: "3,5", label: "Densitate\nloc/km²" },
      { val: "86%", label: "Pop. urbană" },
      { val: "26 ani", label: "Vârstă mediană" },
    ];

    bigStats.forEach((s, i) => {
      const x = 0.3 + i * 2.4;
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y: 0.9, w: 2.1, h: 1.4,
        fill: { color: COLORS.darkBlue },
        line: { color: COLORS.lightBlue },
        shadow: makeShadow(),
      });
      slide.addText(s.val, {
        x: x + 0.05, y: 1.0, w: 2.0, h: 0.7,
        fontSize: 36, bold: true, color: COLORS.gold, fontFace: "Calibri", align: "center",
      });
      slide.addText(s.label, {
        x: x + 0.05, y: 1.68, w: 2.0, h: 0.55,
        fontSize: 11, color: COLORS.white, fontFace: "Calibri", align: "center",
      });
    });

    // Ethnic composition chart
    slide.addText("Compoziție Etnică", {
      x: 0.3, y: 2.5, w: 4.8, h: 0.4,
      fontSize: 14, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    slide.addChart(pres.charts.PIE, [{
      name: "Etnii",
      labels: ["Europeni (Anglo-Celtici)", "Asiatici", "Alți europeni", "Aborigeni", "Alte origini"],
      values: [58, 20, 12, 3.3, 6.7],
    }], {
      x: 0.3, y: 2.95, w: 4.8, h: 2.5,
      chartColors: ["003366", "0077CC", "66AADD", "FF6B35", "FFCC00"],
      showPercent: true,
      showLegend: true,
      legendPos: "b",
      legendFontSize: 9,
      chartArea: { fill: { color: COLORS.offWhite } },
    });

    // Right side info
    const popInfo = [
      { icon: "🏠", title: "Speranța de Viață", text: "82,1 ani (una din cele mai ridicate din lume)" },
      { icon: "📈", title: "Creștere Naturală", text: "1,5% anual, susținută de imigrație (80% din creștere)" },
      { icon: "🌍", title: "Imigranți", text: "30% din populație s-a născut în afara Australiei" },
      { icon: "🏛️", title: "Popoare Indigene", text: "Aborigenii și insularii Torres Strait - primii locuitori, acum ~3,3% din populație" },
    ];

    popInfo.forEach((p, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 5.4, y: 2.5 + i * 0.72, w: 4.35, h: 0.62,
        fill: { color: COLORS.lightGray },
        line: { color: COLORS.medBlue, width: 1 },
        shadow: makeShadow(),
      });
      slide.addText(p.icon + " " + p.title, {
        x: 5.55, y: 2.53 + i * 0.72, w: 4.1, h: 0.28,
        fontSize: 11, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
      });
      slide.addText(p.text, {
        x: 5.55, y: 2.8 + i * 0.72, w: 4.1, h: 0.28,
        fontSize: 9.5, color: COLORS.text, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 5 - Așezări și Orașe
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkBlue };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.gold }, line: { color: COLORS.gold } });

    slide.addText("🏙️ Principalele Orașe ale Australiei", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.white, fontFace: "Calibri",
    });

    // City images
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Sydney_from_the_air.jpg/640px-Sydney_from_the_air.jpg",
      x: 0.3, y: 0.9, w: 3.0, h: 1.9,
    });
    slide.addText("Sydney", {
      x: 0.3, y: 2.82, w: 3.0, h: 0.3,
      fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri", align: "center",
    });

    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/22/Melbourne_CBD_from_Rialto.jpg/640px-Melbourne_CBD_from_Rialto.jpg",
      x: 3.5, y: 0.9, w: 3.0, h: 1.9,
    });
    slide.addText("Melbourne", {
      x: 3.5, y: 2.82, w: 3.0, h: 0.3,
      fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri", align: "center",
    });

    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Canberra_cityscape.jpg/640px-Canberra_cityscape.jpg",
      x: 6.7, y: 0.9, w: 3.0, h: 1.9,
    });
    slide.addText("Canberra - Capitala", {
      x: 6.7, y: 2.82, w: 3.0, h: 0.3,
      fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri", align: "center",
    });

    // City details table
    const cities = [
      { name: "Sydney", pop: "5,3M", special: "Casa Operei, Harbour Bridge, cel mai populat oraș" },
      { name: "Melbourne", pop: "5,1M", special: "Capitala culturală, „cel mai locuibil oraș din lume"" },
      { name: "Brisbane", pop: "2,6M", special: "Gazdă JO 2032, climat subtropical" },
      { name: "Perth", pop: "2,1M", special: "Cel mai izolat oraș mare din lume, minereuri" },
      { name: "Adelaide", pop: "1,4M", special: "Oraș al festivalurilor, vin Barossa Valley" },
      { name: "Canberra", pop: "470K", special: "Capitala națională planificată, gândită ca compromis între Sydney și Melbourne" },
    ];

    cities.forEach((c, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = 0.3 + col * 4.9;
      const y = 3.2 + row * 0.68;
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y, w: 4.6, h: 0.6,
        fill: { color: "FFFFFF", transparency: 90 },
        line: { color: COLORS.lightBlue, width: 1 },
      });
      slide.addText(c.name + "  (" + c.pop + ")", {
        x: x + 0.1, y: y + 0.04, w: 4.3, h: 0.26,
        fontSize: 11, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(c.special, {
        x: x + 0.1, y: y + 0.3, w: 4.3, h: 0.26,
        fontSize: 9, color: COLORS.white, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 6 - Economia
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.offWhite };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.green }, line: { color: COLORS.green } });

    slide.addText("💰 Economia Australiei", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    // Key economic stats
    const econStats = [
      { val: "$1,7T", label: "PIB (2023)", color: COLORS.green },
      { val: "AUD", label: "Moneda Oficială\n(Dolarul Australian)", color: COLORS.darkBlue },
      { val: "#13", label: "Economie Mondială", color: COLORS.accent },
      { val: "$62K", label: "PIB/cap locuitor", color: "6B21A8" },
    ];

    econStats.forEach((s, i) => {
      const x = 0.3 + i * 2.38;
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y: 0.88, w: 2.2, h: 1.3,
        fill: { color: s.color },
        line: { color: s.color },
        shadow: makeShadow(),
      });
      slide.addText(s.val, {
        x: x + 0.05, y: 0.95, w: 2.1, h: 0.6,
        fontSize: 30, bold: true, color: COLORS.white, fontFace: "Calibri", align: "center",
      });
      slide.addText(s.label, {
        x: x + 0.05, y: 1.53, w: 2.1, h: 0.55,
        fontSize: 10, color: COLORS.white, fontFace: "Calibri", align: "center",
      });
    });

    // Sector chart
    slide.addText("Sectoare Economice (% din PIB)", {
      x: 0.3, y: 2.35, w: 4.5, h: 0.4,
      fontSize: 13, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    slide.addChart(pres.charts.BAR, [{
      name: "% PIB",
      labels: ["Servicii", "Minerit", "Construcții", "Agricultură", "Industrie"],
      values: [70, 10, 8, 2.2, 6],
    }], {
      x: 0.3, y: 2.8, w: 4.5, h: 2.65,
      barDir: "col",
      chartColors: ["003366", "0077CC", "00A896", "FFCC00", "FF6B35"],
      showValue: true,
      dataLabelFontSize: 9,
      chartArea: { fill: { color: COLORS.offWhite }, roundedCorners: true },
      catAxisLabelColor: "333333",
      valAxisLabelColor: "333333",
      valGridLine: { color: "DDDDDD", size: 0.5 },
    });

    // Right side
    const econInfo = [
      { icon: "⛏️", title: "Minerit & Resurse", text: "Australia este cel mai mare exportator mondial de cărbune, fier, aur, bauxită. Minele din Western Australia sunt sursa a 80% din exporturi." },
      { icon: "🌾", title: "Agricultură", text: "Grâu, lână (top 2 mondial), carne de vită, zahăr. Agricultura ocupă 54% din suprafața țării." },
      { icon: "🏦", title: "Servicii Financiare", text: "Sydney este al 9-lea centru financiar global. Bursa ASX gestionează active de peste 2 trilioane AUD." },
      { icon: "🐄", title: "Turism", text: "Al 3-lea sector ca importanță, generând peste $60 miliarde AUD anual pre-pandemie." },
    ];

    econInfo.forEach((e, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 5.1, y: 2.35 + i * 0.78, w: 4.65, h: 0.68,
        fill: { color: COLORS.lightGray },
        line: { color: COLORS.green, width: 1.5 },
        shadow: makeShadow(),
      });
      slide.addText(e.icon + " " + e.title, {
        x: 5.25, y: 2.38 + i * 0.78, w: 4.4, h: 0.3,
        fontSize: 11, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
      });
      slide.addText(e.text, {
        x: 5.25, y: 2.67 + i * 0.78, w: 4.4, h: 0.32,
        fontSize: 9, color: COLORS.text, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 7 - Densitate si Regiuni
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkGray };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.lightBlue }, line: { color: COLORS.lightBlue } });

    slide.addText("📊 Densitate și Distribuție Regională", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 24, bold: true, color: COLORS.white, fontFace: "Calibri",
    });

    // Density chart by state
    slide.addText("Densitate Populație pe State (loc/km²)", {
      x: 0.3, y: 0.85, w: 5.5, h: 0.38,
      fontSize: 13, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });

    slide.addChart(pres.charts.BAR, [{
      name: "Densitate loc/km²",
      labels: ["ACT", "VIC", "NSW", "TAS", "QLD", "SA", "WA", "NT"],
      values: [160, 28, 10, 7.8, 3.3, 1.6, 1.0, 0.2],
    }], {
      x: 0.3, y: 1.28, w: 5.5, h: 3.05,
      barDir: "bar",
      chartColors: ["0077CC"],
      showValue: true,
      dataLabelFontSize: 9,
      chartArea: { fill: { color: "2D3A4A" }, roundedCorners: true },
      catAxisLabelColor: "CCCCCC",
      valAxisLabelColor: "CCCCCC",
      dataLabelColor: "FFFFFF",
      valGridLine: { color: "444444", size: 0.5 },
    });

    // Right side - regional info
    const regions = [
      { name: "ACT (Canberra)", pop: "470K", dens: "160 loc/km²", note: "Cel mai dens, capitala națională" },
      { name: "Victoria", pop: "6,7M", dens: "28 loc/km²", note: "Cea mai densă provincie" },
      { name: "NSW", pop: "8,3M", dens: "10 loc/km²", note: "Cea mai populată provincie" },
      { name: "Queensland", pop: "5,4M", dens: "3,3 loc/km²", note: "Crește rapid prin migrație internă" },
      { name: "Western Australia", pop: "2,8M", dens: "1,0 loc/km²", note: "1/3 din suprafață, bogat în resurse" },
      { name: "Northern Territory", pop: "250K", dens: "0,2 loc/km²", note: "Cel mai puțin populat, 30% aborigeni" },
    ];

    slide.addText("Provincii și Teritorii", {
      x: 6.0, y: 0.85, w: 3.8, h: 0.38,
      fontSize: 13, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });

    regions.forEach((r, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 6.0, y: 1.28 + i * 0.67, w: 3.8, h: 0.58,
        fill: { color: "FFFFFF", transparency: 90 },
        line: { color: COLORS.lightBlue, width: 1 },
      });
      slide.addText(r.name + " — " + r.pop + " / " + r.dens, {
        x: 6.1, y: 1.31 + i * 0.67, w: 3.6, h: 0.28,
        fontSize: 10, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(r.note, {
        x: 6.1, y: 1.57 + i * 0.67, w: 3.6, h: 0.25,
        fontSize: 9, color: COLORS.white, fontFace: "Calibri",
      });
    });

    // Bottom note
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 5.05, w: 10, h: 0.57,
      fill: { color: COLORS.medBlue }, line: { color: COLORS.medBlue },
    });
    slide.addText("⚠️  90% din australieni trăiesc pe o fâșie de max. 50 km de coastă — interiorul este aproape nelocuit (Outback)", {
      x: 0.2, y: 5.12, w: 9.6, h: 0.4,
      fontSize: 11, color: COLORS.gold, fontFace: "Calibri", align: "center", bold: true,
    });
  }

  // ============================================================
  // SLIDE 8 - Turism
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.offWhite };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.accent }, line: { color: COLORS.accent } });

    slide.addText("🏖️ Zone Turistice de Top", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    // Tourist destination images
    const destinations = [
      {
        name: "Great Barrier Reef",
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Coral_reef_at_palmyra.jpg/400px-Coral_reef_at_palmyra.jpg",
        desc: "Cel mai mare recif de corali din lume, UNESCO. 2.300 km, vizibil din spațiu."
      },
      {
        name: "Uluru (Ayers Rock)",
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Uluru_Landscape.jpg/400px-Uluru_Landscape.jpg",
        desc: "Monolit sacru, 348m înălțime, simbolul Australiei. Patrimoniu UNESCO."
      },
      {
        name: "Sydney Opera House",
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Sydney_Opera_House_Exterior_2019.jpg/400px-Sydney_Opera_House_Exterior_2019.jpg",
        desc: "Capodoperă arhitecturală, UNESCO. 2.000 de spectacole/an, 8 milioane vizitatori."
      },
    ];

    destinations.forEach((d, i) => {
      const x = 0.3 + i * 3.25;
      slide.addImage({
        path: d.img,
        x, y: 0.88, w: 3.0, h: 1.85,
      });
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y: 2.76, w: 3.0, h: 1.3,
        fill: { color: COLORS.darkBlue }, line: { color: COLORS.lightBlue },
        shadow: makeShadow(),
      });
      slide.addText(d.name, {
        x: x + 0.1, y: 2.82, w: 2.8, h: 0.32,
        fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(d.desc, {
        x: x + 0.1, y: 3.13, w: 2.8, h: 0.85,
        fontSize: 9.5, color: COLORS.white, fontFace: "Calibri",
      });
    });

    // More tourist info
    const moreInfo = [
      { icon: "🐊", title: "Kakadu NP", text: "Cel mai mare parc național, 19.804 km², artă rupestră aborigenă de 40.000 ani" },
      { icon: "🌊", title: "Bondi Beach", text: "Cea mai faimoasă plajă, Sydney. Surf internaţional, populara cu turiştii" },
      { icon: "🦘", title: "Kangaroo Island", text: "Rezervație naturală cu fauna sălbatică protejată, koala, canguri, focă" },
      { icon: "🌿", title: "Daintree Rainforest", text: "Cea mai veche pădure tropicală din lume, 135 milioane ani, UNESCO" },
    ];

    moreInfo.forEach((m, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = 0.3 + col * 4.9;
      const y = 4.18 + row * 0.6;
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y, w: 4.6, h: 0.5,
        fill: { color: COLORS.lightGray },
        line: { color: COLORS.accent, width: 1 },
      });
      slide.addText(m.icon + " " + m.title + ": " + m.text, {
        x: x + 0.1, y: y + 0.06, w: 4.4, h: 0.38,
        fontSize: 9, color: COLORS.text, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 9 - Festivaluri, Cultura, Guvernare
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkBlue };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.gold }, line: { color: COLORS.gold } });

    slide.addText("🎉 Festivaluri, Cultură & Guvernare", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 24, bold: true, color: COLORS.white, fontFace: "Calibri",
    });

    // Left - Festivals
    slide.addText("🎊 Festivaluri Specifice", {
      x: 0.3, y: 0.9, w: 4.7, h: 0.4,
      fontSize: 15, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });

    const festivals = [
      { name: "Australia Day (26 Ian)", desc: "Ziua națională, comemorează sosirea britanicilor în 1788. Focuri de artificii, concerte, dezbateri despre identitate națională." },
      { name: "Anzac Day (25 Apr)", desc: "Ziua comemorativă a veteranilor. Parade solemne, ceremonia Zorilor (Dawn Service), cea mai importantă zi națională." },
      { name: "Sydney Mardi Gras (Feb)", desc: "Cel mai mare festival LGBT din lume, 500.000 participanți, parade spectaculoase." },
      { name: "Melbourne Cup (Nov)", desc: "„Cursa care oprește o națiune" — cel mai faimos eveniment ecvestru, zi liberă în Victoria." },
      { name: "Vivid Sydney (Mai-Iun)", desc: "Festival de lumini, muzică și idei, 2,4 milioane vizitatori, spectacole pe Opera House." },
    ];

    festivals.forEach((f, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 0.3, y: 1.38 + i * 0.78, w: 4.7, h: 0.68,
        fill: { color: "FFFFFF", transparency: 90 },
        line: { color: COLORS.gold, width: 1 },
      });
      slide.addText(f.name, {
        x: 0.4, y: 1.41 + i * 0.78, w: 4.5, h: 0.28,
        fontSize: 11, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(f.desc, {
        x: 0.4, y: 1.68 + i * 0.78, w: 4.5, h: 0.33,
        fontSize: 9, color: COLORS.white, fontFace: "Calibri",
      });
    });

    // Right - Governance
    slide.addText("🏛️ Forma de Guvernare", {
      x: 5.3, y: 0.9, w: 4.5, h: 0.4,
      fontSize: 15, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });

    const govInfo = [
      { icon: "👑", label: "Forma de stat", val: "Monarhie constituțională parlamentară federală" },
      { icon: "👸", label: "Șef de stat", val: "Regele Charles III, reprezentat de Guvernatorul General" },
      { icon: "🗳️", label: "Șef de guvern", val: "Primul Ministru Anthony Albanese (Australian Labor Party)" },
      { icon: "🏛️", label: "Parlamentul", val: "Bicameral: Senat (76 senatori) + Camera Reprezentanților (151 membri)" },
      { icon: "⚖️", label: "Sistem juridic", val: "Common law britanic, Curtea Supremă (High Court of Australia)" },
      { icon: "🗺️", label: "Structura federală", val: "6 state + 2 teritorii: NSW, VIC, QLD, SA, WA, TAS, ACT, NT" },
    ];

    govInfo.forEach((g, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 5.3, y: 1.38 + i * 0.65, w: 4.5, h: 0.55,
        fill: { color: COLORS.medBlue, transparency: 30 },
        line: { color: COLORS.lightBlue, width: 1 },
      });
      slide.addText(g.icon + " " + g.label, {
        x: 5.4, y: 1.41 + i * 0.65, w: 4.3, h: 0.24,
        fontSize: 10, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(g.val, {
        x: 5.4, y: 1.64 + i * 0.65, w: 4.3, h: 0.24,
        fontSize: 9, color: COLORS.white, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 10 - Limbă, Internet, Concluzii
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkGray };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.lightBlue }, line: { color: COLORS.lightBlue } });

    slide.addText("🌐 Limbă, Internet & Date Diverse", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 24, bold: true, color: COLORS.white, fontFace: "Calibri",
    });

    // Left - Language
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0.3, y: 0.88, w: 4.5, h: 2.2,
      fill: { color: COLORS.darkBlue, transparency: 30 },
      line: { color: COLORS.lightBlue, width: 1.5 },
      shadow: makeShadow(),
    });
    slide.addText("🗣️ Limbă Oficială", {
      x: 0.45, y: 0.95, w: 4.2, h: 0.38,
      fontSize: 15, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });
    slide.addText([
      { text: "Engleza australiană", options: { bold: true, breakLine: true } },
      { text: "De facto (nu există limbă oficială declarată prin constituție)\n", options: { breakLine: true } },
      { text: "98% din australieni vorbesc engleza acasă sau o cunosc.", options: { breakLine: true } },
      { text: "\nAlte limbi vorbite:", options: { bold: true, breakLine: true } },
      { text: "Mandarina (~2,9%), Arabă (1,4%), Cantoneza (1,2%),\nVietnameză (1,2%), Italiană (1,2%), limbile aborigene (~250 de limbi).", options: { breakLine: false } },
    ], {
      x: 0.45, y: 1.38, w: 4.2, h: 1.55,
      fontSize: 10, color: COLORS.white, fontFace: "Calibri",
    });

    // Internet
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0.3, y: 3.2, w: 4.5, h: 1.2,
      fill: { color: COLORS.green, transparency: 20 },
      line: { color: COLORS.green, width: 1.5 },
      shadow: makeShadow(),
    });
    slide.addText("🌐 Domeniu de Internet", {
      x: 0.45, y: 3.27, w: 4.2, h: 0.38,
      fontSize: 15, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });
    slide.addText(".au  (pentru persoane fizice: .com.au, .org.au, .edu.au, .gov.au)\nIntroduced: 1986  |  Registrar: auDA (au Domain Administration)\n14,3 milioane domenii înregistrate (2024)", {
      x: 0.45, y: 3.65, w: 4.2, h: 0.65,
      fontSize: 10, color: COLORS.white, fontFace: "Calibri",
    });

    // Right - Miscellaneous facts
    slide.addText("🦘 Fapte Interesante", {
      x: 5.1, y: 0.88, w: 4.65, h: 0.4,
      fontSize: 15, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });

    const facts = [
      { icon: "⏰", text: "Australia are 9 fuse orare diferite, inclusiv jumătăți de oră" },
      { icon: "🔵", text: "Drapelul include Union Jack (legătura cu Marea Britanie) și Crucea Sudului" },
      { icon: "🌡️", text: "Temperatura record: 50,7°C la Oodnadatta (1960)" },
      { icon: "🐊", text: "Mai mulți canguri decât oameni: 50M canguri vs 27M oameni" },
      { icon: "🏆", text: "Australia a câștigat de 5 ori titlul „Cel mai locuibil oraș" pentru Melbourne" },
      { icon: "🌊", text: "A 3-a zonă economică exclusivă din lume: 8,5M km² de ocean" },
      { icon: "🎓", text: "8 universități în Top 100 mondial, inclusiv Australian National University" },
      { icon: "🚂", text: "Indian Pacific: una din cele mai lungi rute feroviare din lume (4.352 km Sydney-Perth)" },
    ];

    facts.forEach((f, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 5.1, y: 1.35 + i * 0.52, w: 4.65, h: 0.44,
        fill: { color: "FFFFFF", transparency: 92 },
        line: { color: COLORS.lightBlue, width: 0.8 },
      });
      slide.addText(f.icon + "  " + f.text, {
        x: 5.22, y: 1.38 + i * 0.52, w: 4.42, h: 0.38,
        fontSize: 9.5, color: COLORS.white, fontFace: "Calibri",
      });
    });

    // Bottom footer
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 5.1, w: 10, h: 0.52,
      fill: { color: COLORS.lightBlue }, line: { color: COLORS.lightBlue },
    });
    slide.addText("🦘 Australia — Continentul de Jos, Insula de Sus, Națiunea Unicornului 🌏", {
      x: 0.2, y: 5.16, w: 9.6, h: 0.38,
      fontSize: 13, bold: true, color: COLORS.white, fontFace: "Calibri", align: "center",
    });
  }

  await pres.writeFile({ fileName: "/home/claude/australia.pptx" });
  console.log("Done!");
}

createPresentation().catch(console.error);
