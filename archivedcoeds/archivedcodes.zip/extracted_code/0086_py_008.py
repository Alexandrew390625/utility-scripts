"""
number_namer.py
===============
Name any number using standard English -illion names (short scale),
SI / binary prefixes, and a plain English description.

Usage
-----
    python number_namer.py                  # interactive mode
    python number_namer.py 1e27             # single number from CLI
    python number_namer.py 1500000 1e9 2e60 # multiple numbers from CLI
"""

import sys
import math
from decimal import Decimal

# ---------------------------------------------------------------------------
# SI metric prefixes  (symbol, name, exponent of 10)
# ---------------------------------------------------------------------------
SI_PREFIXES = [
    (1e30,  "Q",  "Quetta"),
    (1e27,  "R",  "Ronna"),
    (1e24,  "Y",  "Yotta"),
    (1e21,  "Z",  "Zetta"),
    (1e18,  "E",  "Exa"),
    (1e15,  "P",  "Peta"),
    (1e12,  "T",  "Tera"),
    (1e9,   "G",  "Giga"),
    (1e6,   "M",  "Mega"),
    (1e3,   "k",  "kilo"),
    (1e2,   "h",  "hecto"),
    (1e1,   "da", "deca"),
    (1e-1,  "d",  "deci"),
    (1e-2,  "c",  "centi"),
    (1e-3,  "m",  "milli"),
    (1e-6,  "µ",  "micro"),
    (1e-9,  "n",  "nano"),
    (1e-12, "p",  "pico"),
    (1e-15, "f",  "femto"),
    (1e-18, "a",  "atto"),
    (1e-21, "z",  "zepto"),
    (1e-24, "y",  "yocto"),
    (1e-27, "r",  "ronto"),
    (1e-30, "q",  "quecto"),
]

# ---------------------------------------------------------------------------
# Binary (IEC) prefixes  (value, symbol, name)
# ---------------------------------------------------------------------------
BINARY_PREFIXES = [
    (2**80, "Yi", "Yobi"),
    (2**70, "Zi", "Zebi"),
    (2**60, "Ei", "Exbi"),
    (2**50, "Pi", "Pebi"),
    (2**40, "Ti", "Tebi"),
    (2**30, "Gi", "Gibi"),
    (2**20, "Mi", "Mebi"),
    (2**10, "Ki", "Kibi"),
]

# ---------------------------------------------------------------------------
# Standard -illion names (short scale, N=1…)
# Name for 10^(3N+3)
# ---------------------------------------------------------------------------
_ONES = [
    "", "un", "duo", "tre", "quattuor", "quin", "se", "septen", "octo", "novem"
]
_TENS = [
    "", "dec", "vigint", "trigint", "quadragint", "quinquagint",
    "sexagint", "septuagint", "octogint", "nonagint",
]
_HUNDREDS = [
    "", "cent", "ducent", "trecent", "quadringent", "quingent",
    "sescent", "septingent", "octingent", "nongent",
]

# Hard-coded names for N = 1..9 (Chuquet names)
_NAMED = {
    0:   "thousand",        # 10^3
    1:   "million",         # 10^6
    2:   "billion",         # 10^9
    3:   "trillion",        # 10^12
    4:   "quadrillion",     # 10^15
    5:   "quintillion",     # 10^18
    6:   "sextillion",      # 10^21
    7:   "septillion",      # 10^24
    8:   "octillion",       # 10^27
    9:   "nonillion",       # 10^30
    10:  "decillion",
    11:  "undecillion",
    12:  "duodecillion",
    13:  "tredecillion",
    14:  "quattuordecillion",
    15:  "quindecillion",
    16:  "sexdecillion",
    17:  "septendecillion",
    18:  "octodecillion",
    19:  "novemdecillion",
    20:  "vigintillion",
    100: "centillion",
    1000: "millillion",
}

# Special small names
_SMALL = {
    10:  "ten",
    100: "hundred",
    1_000: "thousand",
    10_000: "myriad",
    1_000_000: "million",
}


def _illion_name(n: int) -> str:
    """
    Return the -illion name for the number 10^(3n+3), n >= 1.
    For n <= 20 and a few specials, uses the standard table.
    For larger n, constructs the Latin-prefix name.
    """
    if n in _NAMED:
        return _NAMED[n]
    if n > 1000:
        return f"10^{3*n+3} (unnamed)"

    # Build Latin prefix for n up to 999
    h = n // 100
    t = (n % 100) // 10
    o = n % 10
    prefix = _HUNDREDS[h] + _TENS[t] + _ONES[o]
    # Clean up double-vowel collisions at joins
    if prefix.endswith("i") and "illion".startswith("i"):
        prefix = prefix[:-1]
    return prefix + "illion"


# ---------------------------------------------------------------------------
# Core naming function
# ---------------------------------------------------------------------------

def name_number(value) -> dict:
    """
    Given a numeric value (int, float, or string), return a dict with:
      - 'input'        : original string
      - 'scientific'   : e.g. "1.50 × 10^6"
      - 'illion_name'  : e.g. "million"
      - 'si_prefix'    : e.g. "1.50 M (Mega)"
      - 'binary_prefix': e.g. "1.43 Mi (Mebi)"  [if applicable]
      - 'description'  : human-readable summary
    """
    original = str(value)
    try:
        num = float(value)
    except (ValueError, TypeError):
        return {"error": f"Cannot parse '{value}' as a number."}

    negative = num < 0
    abs_num = abs(num)
    result = {
        "input": original,
        "negative": negative,
        "abs_value": abs_num,
    }

    # --- Scientific notation ---
    if abs_num == 0:
        result["scientific"] = "0"
        result["illion_name"] = "zero"
        result["si_prefix"] = "0"
        result["binary_prefix"] = None
        result["description"] = "Zero"
        return result

    exp = math.floor(math.log10(abs_num))
    mantissa = abs_num / (10 ** exp)
    result["scientific"] = f"{mantissa:.6g} × 10^{exp}"

    # --- Standard -illion name ---
    # 10^(3N+3) => N = (exp - 3) / 3
    if exp >= 3:
        N = (exp - 3) // 3  # integer part
        illion = _illion_name(N)
        scale = 10 ** (3 * N + 3)
        coeff = abs_num / scale
        result["illion_name"] = f"{coeff:.6g} {illion}"
    elif exp >= 0:
        small_keys = sorted(_SMALL.keys())
        best = 1
        for k in small_keys:
            if abs_num >= k:
                best = k
        result["illion_name"] = f"{abs_num/best:.6g} {_SMALL.get(best, '')}"
    else:
        result["illion_name"] = None  # sub-one

    # --- SI prefix ---
    si_str = None
    for threshold, symbol, name in SI_PREFIXES:
        if abs_num >= threshold * 0.999:
            si_val = abs_num / threshold
            si_str = f"{si_val:.6g} {symbol}  ({name}-)"
            break
    result["si_prefix"] = si_str or f"{abs_num:.6g} (no SI prefix)"

    # --- Binary prefix (only if integer-like and >= 1024) ---
    bin_str = None
    if abs_num >= 1024 and abs_num == int(abs_num):
        for threshold, symbol, name in BINARY_PREFIXES:
            if abs_num >= threshold:
                bin_val = abs_num / threshold
                bin_str = f"{bin_val:.6g} {symbol}i  ({name}-)"
                break
    result["binary_prefix"] = bin_str

    # --- Human description ---
    sign = "negative " if negative else ""
    parts = [f"{sign}{result['scientific']}"]
    if result["illion_name"]:
        parts.append(f"≈ {sign}{result['illion_name']}")
    parts.append(f"SI: {sign}{result['si_prefix']}")
    if bin_str:
        parts.append(f"Binary: {sign}{bin_str}")
    result["description"] = " | ".join(parts)

    return result


# ---------------------------------------------------------------------------
# Pretty printer
# ---------------------------------------------------------------------------

def print_result(r: dict) -> None:
    if "error" in r:
        print(f"  ✗  {r['error']}")
        return
    sign = "−" if r["negative"] else ""
    print(f"  Input        : {r['input']}")
    print(f"  Scientific   : {sign}{r['scientific']}")
    if r.get("illion_name"):
        print(f"  -illion name : {sign}{r['illion_name']}")
    print(f"  SI prefix    : {sign}{r['si_prefix']}")
    if r.get("binary_prefix"):
        print(f"  Binary prefix: {sign}{r['binary_prefix']}")


# ---------------------------------------------------------------------------
# Demos shown at startup
# ---------------------------------------------------------------------------

DEMO_VALUES = [
    1, 10, 100, 1_000, 1_000_000, 1e9, 1e12, 1e15, 1e18, 1e21,
    1e24, 1e27, 1e30, 1e33, 1e63, 1e303,
    1024, 2**20, 2**30, 2**40, 2**50, 2**60,
    1500, 2.5e6, 9.99e-7,
]

BANNER = r"""
╔══════════════════════════════════════════════════════╗
║         N U M B E R   N A M E R                      ║
║  SI prefixes · -illion names · Binary (IEC) prefixes ║
╚══════════════════════════════════════════════════════╝
"""


def run_demo() -> None:
    print(BANNER)
    print("=" * 58)
    print("  DEMO — standard reference values")
    print("=" * 58)
    for v in DEMO_VALUES:
        print()
        print_result(name_number(v))
    print()


def interactive_mode() -> None:
    print(BANNER)
    print("Type a number and press Enter.  Type 'quit' to exit.\n")
    while True:
        try:
            raw = input("Number > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break
        if not raw:
            continue
        if raw.lower() in ("quit", "exit", "q"):
            print("Goodbye!")
            break
        print()
        print_result(name_number(raw))
        print()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    args = sys.argv[1:]
    if args:
        print(BANNER)
        for arg in args:
            print()
            print_result(name_number(arg))
        print()
    else:
        # No arguments: show demo then enter interactive mode
        run_demo()
        interactive_mode()
