    32	// Basic text
    33	slide.addText("Simple Text", {
    34	  x: 1, y: 1, w: 8, h: 2, fontSize: 24, fontFace: "Arial",
    35	  color: "363636", bold: true, align: "center", valign: "middle"
    36	});
    37	
    38	// Character spacing (use charSpacing, not letterSpacing which is silently ignored)
    39	slide.addText("SPACED TEXT", { x: 1, y: 1, w: 8, h: 1, charSpacing: 6 });
    40	
    41	// Rich text arrays
    42	slide.addText([
    43	  { text: "Bold ", options: { bold: true } },
    44	  { text: "Italic ", options: { italic: true } }
    45	], { x: 1, y: 3, w: 8, h: 1 });
    46	
    47	// Multi-line text (requires breakLine: true)
    48	slide.addText([
    49	  { text: "Line 1", options: { breakLine: true } },
    50	  { text: "Line 2", options: { breakLine: true } },
    51	  { text: "Line 3" }  // Last item doesn't need breakLine
    52	], { x: 0.5, y: 0.5, w: 8, h: 2 });
    53	
    54	// Text box margin (internal padding)
    55	slide.addText("Title", {
    56	  x: 0.5, y: 0.3, w: 9, h: 0.6,
    57	  margin: 0  // Use 0 when aligning text with other elements like shapes or icons
    58	});
    59	