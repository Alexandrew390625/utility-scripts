"""
Roblox Game Stats Checker
Fetches public stats for a Roblox game using the Roblox API.
"""

import requests

# ── Config ────────────────────────────────────────────────────────────────────
PLACE_ID = 4943297844          # from the URL
UNIVERSE_API = "https://games.roblox.com/v1/games"
THUMBNAIL_API = "https://thumbnails.roblox.com/v1/games/icons"
# ─────────────────────────────────────────────────────────────────────────────


def get_universe_id(place_id: int) -> int | None:
    """Convert a Place ID to its Universe ID."""
    url = f"https://apis.roblox.com/universes/v1/places/{place_id}/universe"
    r = requests.get(url, timeout=10)
    if r.status_code == 200:
        return r.json().get("universeId")
    print(f"[!] Could not resolve Universe ID (status {r.status_code})")
    return None


def get_game_stats(universe_id: int) -> dict | None:
    """Fetch game details from the Roblox Games API."""
    r = requests.get(UNIVERSE_API, params={"universeIds": universe_id}, timeout=10)
    if r.status_code == 200:
        data = r.json().get("data", [])
        return data[0] if data else None
    print(f"[!] Could not fetch game stats (status {r.status_code})")
    return None


def get_active_servers(universe_id: int) -> dict | None:
    """Fetch active server / player counts."""
    url = f"https://games.roblox.com/v1/games/{universe_id}/servers/Public"
    r = requests.get(url, params={"limit": 10}, timeout=10)
    if r.status_code == 200:
        return r.json()
    return None


def format_number(n: int) -> str:
    """Pretty-format large numbers (e.g. 1234567 → 1,234,567)."""
    return f"{n:,}"


def print_stats(place_id: int) -> None:
    print("\n🎮 Roblox Game Stats Checker")
    print("=" * 40)

    # Step 1 – resolve universe ID
    universe_id = get_universe_id(place_id)
    if not universe_id:
        return
    print(f"Place ID   : {place_id}")
    print(f"Universe ID: {universe_id}")

    # Step 2 – game details
    game = get_game_stats(universe_id)
    if not game:
        print("[!] No game data returned.")
        return

    print("\n📋 Game Info")
    print("-" * 40)
    print(f"  Name        : {game.get('name', 'N/A')}")
    print(f"  Description : {(game.get('description') or 'N/A')[:80]}")
    print(f"  Creator     : {game.get('creator', {}).get('name', 'N/A')}")
    print(f"  Genre       : {game.get('genre', 'N/A')}")
    print(f"  Max players : {game.get('maxPlayers', 'N/A')}")

    print("\n📊 Engagement Stats")
    print("-" * 40)
    visits      = game.get("visits", 0)
    playing     = game.get("playing", 0)
    favourites  = game.get("favoritedCount", 0)
    likes       = game.get("likeCount", 0)
    dislikes    = game.get("dislikeCount", 0)
    total_votes = likes + dislikes
    ratio       = f"{likes / total_votes * 100:.1f}%" if total_votes else "N/A"

    print(f"  Total visits   : {format_number(visits)}")
    print(f"  Currently playing: {format_number(playing)}")
    print(f"  Favourites     : {format_number(favourites)}")
    print(f"  👍 Likes       : {format_number(likes)}")
    print(f"  👎 Dislikes    : {format_number(dislikes)}")
    print(f"  Like ratio     : {ratio}")

    # Step 3 – live server info
    servers_data = get_active_servers(universe_id)
    if servers_data:
        servers = servers_data.get("data", [])
        print(f"\n🖥️  Live Servers: {len(servers)} public server(s) listed")
        for i, s in enumerate(servers[:5], 1):
            players  = s.get("playing", 0)
            capacity = s.get("maxPlayers", "?")
            ping     = s.get("ping", "?")
            fps      = s.get("fps", "?")
            print(f"  Server {i}: {players}/{capacity} players | ping {ping} ms | {fps} FPS")
    else:
        print("\n🖥️  No public server data available (game may be offline).")

    print("\n" + "=" * 40)
    print("✅ Done!")


if __name__ == "__main__":
    print_stats(PLACE_ID)
