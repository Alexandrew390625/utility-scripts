   266	unzip -l /mnt/user-data/uploads/bundle.zip
   267	tar -tf /mnt/user-data/uploads/bundle.tar
   268	