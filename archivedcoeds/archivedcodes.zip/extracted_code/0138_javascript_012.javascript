   269	slide.addTable([
   270	  ["Header 1", "Header 2"],
   271	  ["Cell 1", "Cell 2"]
   272	], {
   273	  x: 1, y: 1, w: 8, h: 2,
   274	  border: { pt: 1, color: "999999" }, fill: { color: "F1F1F1" }
   275	});
   276	
   277	// Advanced with merged cells
   278	let tableData = [
   279	  [{ text: "Header", options: { fill: { color: "6699CC" }, color: "FFFFFF", bold: true } }, "Cell"],
   280	  [{ text: "Merged", options: { colspan: 2 } }]
   281	];
   282	slide.addTable(tableData, { x: 1, y: 3.5, w: 8, colW: [4, 4] });
   283	