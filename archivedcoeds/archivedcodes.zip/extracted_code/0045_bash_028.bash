    68	# Layout mode preserves spatial positioning
    69	pdftotext -layout document.pdf output.txt
    70	
    71	# Specific page range
    72	pdftotext -f 1 -l 5 document.pdf output.txt
    73	