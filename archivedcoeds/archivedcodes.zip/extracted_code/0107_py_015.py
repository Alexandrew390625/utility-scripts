"""
read_mca_legacy.py — Read .mca files using pre-1.13 numeric block ID format.

Requirements:
    pip install nbt

Change SEARCH_DIR to your world folder path.
"""

import os, sys, glob, struct, zlib, gzip, io

try:
    from nbt import nbt as nbtlib
except ImportError:
    sys.exit("Missing dependency. Install with:\n    pip install nbt")

# ── CHANGE THIS to your world folder ──────────────────────
SEARCH_DIR = "/storage/emulated/0/Download/New Folder/Minecraft unknown world"
# ──────────────────────────────────────────────────────────

SECTOR = 4096

# Numeric block ID → name map (most common blocks)
BLOCK_NAMES = {
    0: "air", 1: "stone", 2: "grass", 3: "dirt", 4: "cobblestone",
    5: "planks", 6: "sapling", 7: "bedrock", 8: "flowing_water",
    9: "water", 10: "flowing_lava", 11: "lava", 12: "sand",
    13: "gravel", 14: "gold_ore", 15: "iron_ore", 16: "coal_ore",
    17: "log", 18: "leaves", 19: "sponge", 20: "glass",
    21: "lapis_ore", 22: "lapis_block", 24: "sandstone",
    25: "noteblock", 26: "bed", 27: "golden_rail", 28: "detector_rail",
    29: "sticky_piston", 30: "web", 31: "tallgrass", 32: "deadbush",
    33: "piston", 35: "wool", 37: "yellow_flower", 38: "red_flower",
    39: "brown_mushroom", 40: "red_mushroom", 41: "gold_block",
    42: "iron_block", 43: "double_stone_slab", 44: "stone_slab",
    45: "brick_block", 46: "tnt", 47: "bookshelf", 48: "mossy_cobblestone",
    49: "obsidian", 50: "torch", 51: "fire", 52: "mob_spawner",
    53: "oak_stairs", 54: "chest", 55: "redstone_wire", 56: "diamond_ore",
    57: "diamond_block", 58: "crafting_table", 59: "wheat",
    60: "farmland", 61: "furnace", 62: "lit_furnace", 63: "standing_sign",
    64: "wooden_door", 65: "ladder", 66: "rail", 67: "stone_stairs",
    68: "wall_sign", 69: "lever", 70: "stone_pressure_plate",
    71: "iron_door", 72: "wooden_pressure_plate", 73: "redstone_ore",
    74: "lit_redstone_ore", 78: "snow_layer", 79: "ice", 80: "snow",
    81: "cactus", 82: "clay", 83: "reeds", 85: "fence",
    86: "pumpkin", 87: "netherrack", 88: "soul_sand", 89: "glowstone",
    90: "portal", 91: "lit_pumpkin", 95: "stained_glass",
    97: "monster_egg", 98: "stonebrick", 99: "brown_mushroom_block",
    100: "red_mushroom_block", 101: "iron_bars", 102: "glass_pane",
    103: "melon_block", 106: "vine", 107: "fence_gate",
    108: "brick_stairs", 109: "stone_brick_stairs", 110: "mycelium",
    111: "waterlily", 112: "nether_brick", 113: "nether_brick_fence",
    114: "nether_brick_stairs", 115: "nether_wart", 116: "enchanting_table",
    117: "brewing_stand", 120: "end_portal_frame", 121: "end_stone",
    122: "dragon_egg", 123: "redstone_lamp", 125: "double_wooden_slab",
    126: "wooden_slab", 128: "sandstone_stairs", 129: "emerald_ore",
    130: "ender_chest", 132: "tripwire", 133: "emerald_block",
    134: "spruce_stairs", 135: "birch_stairs", 136: "jungle_stairs",
    137: "command_block", 138: "beacon", 139: "cobblestone_wall",
    141: "carrots", 142: "potatoes", 143: "wooden_button",
    145: "anvil", 146: "trapped_chest", 147: "light_weighted_pressure_plate",
    148: "heavy_weighted_pressure_plate", 151: "daylight_detector",
    152: "redstone_block", 153: "quartz_ore", 154: "hopper",
    155: "quartz_block", 156: "quartz_stairs", 157: "activator_rail",
    158: "dropper", 159: "stained_hardened_clay", 160: "stained_glass_pane",
    161: "leaves2", 162: "log2", 163: "acacia_stairs", 164: "dark_oak_stairs",
    165: "slime", 166: "barrier", 167: "iron_trapdoor", 168: "prismarine",
    169: "sea_lantern", 170: "hay_block", 171: "carpet",
    172: "hardened_clay", 173: "coal_block", 174: "packed_ice",
    175: "double_plant", 176: "standing_banner", 177: "wall_banner",
    178: "daylight_detector_inverted", 179: "red_sandstone",
    180: "red_sandstone_stairs", 182: "stone_slab2", 183: "spruce_fence_gate",
    184: "birch_fence_gate", 185: "jungle_fence_gate",
    186: "dark_oak_fence_gate", 187: "acacia_fence_gate",
    188: "spruce_fence", 189: "birch_fence", 190: "jungle_fence",
    191: "dark_oak_fence", 192: "acacia_fence", 193: "spruce_door",
    194: "birch_door", 195: "jungle_door", 196: "acacia_door",
    197: "dark_oak_door", 198: "end_rod", 199: "chorus_plant",
    200: "chorus_flower", 201: "purpur_block", 202: "purpur_pillar",
    203: "purpur_stairs", 205: "purpur_double_slab", 206: "purpur_slab",
    207: "beetroots", 208: "grass_path", 209: "end_gateway",
    210: "repeating_command_block", 211: "chain_command_block",
    212: "frosted_ice", 213: "magma", 214: "nether_wart_block",
    215: "red_nether_brick", 216: "bone_block", 218: "observer",
    219: "white_shulker_box", 220: "orange_shulker_box",
    255: "structure_block",
}

def block_name(block_id):
    return BLOCK_NAMES.get(block_id, f"unknown_block_{block_id}")

AIR_IDS = {0}  # only air is skipped

def read_chunk_nbt(mca_path, offset_sectors, size_sectors):
    byte_offset = offset_sectors * SECTOR
    with open(mca_path, "rb") as f:
        f.seek(byte_offset)
        data = f.read(size_sectors * SECTOR)

    if len(data) < 5:
        return None
    length = struct.unpack(">I", data[0:4])[0]
    comp   = data[4]
    payload = data[5:5 + length - 1]

    try:
        if comp == 2:
            raw = zlib.decompress(payload)
        elif comp == 1:
            raw = gzip.decompress(payload)
        elif comp == 3:
            raw = payload
        else:
            return None
    except Exception:
        return None

    try:
        return nbtlib.NBTFile(buffer=io.BytesIO(raw))
    except Exception:
        return None


def iter_blocks_legacy(mca_path):
    """
    Yield (chunk_x, chunk_z, x, y, z, block_name) for every non-air block
    using the pre-1.13 numeric ID format.
    """
    file_size = os.path.getsize(mca_path)

    with open(mca_path, "rb") as f:
        header = f.read(SECTOR * 2)

    for chunk_z in range(32):
        for chunk_x in range(32):
            entry = (chunk_x + chunk_z * 32) * 4
            raw_entry = struct.unpack(">I", header[entry:entry+4])[0]
            offset_sectors = raw_entry >> 8
            size_sectors   = raw_entry & 0xFF

            if offset_sectors == 0 or size_sectors == 0:
                continue
            if offset_sectors * SECTOR + size_sectors * SECTOR > file_size:
                continue

            nbt_data = read_chunk_nbt(mca_path, offset_sectors, size_sectors)
            if nbt_data is None:
                continue

            try:
                level = nbt_data["Level"]
                sections = level["Sections"]
            except KeyError:
                continue

            for section in sections:
                try:
                    section_y = section["Y"].value
                    blocks_tag = section["Blocks"]
                except KeyError:
                    continue

                blocks = bytes(blocks_tag.value)  # 4096 bytes, one per block

                # Data tag holds the 4-bit metadata (2 per byte, 2048 bytes)
                try:
                    data_tag = bytes(section["Data"].value)
                except KeyError:
                    data_tag = bytes(2048)

                y_base = section_y * 16

                for i, block_id in enumerate(blocks):
                    if block_id in AIR_IDS:
                        continue

                    # Decode index: blocks are stored YZX order
                    y_local = (i >> 8) & 0xF
                    z_local = (i >> 4) & 0xF
                    x_local =  i       & 0xF

                    # Get 4-bit metadata
                    meta_byte = data_tag[i >> 1]
                    if i & 1:
                        meta = (meta_byte >> 4) & 0xF
                    else:
                        meta = meta_byte & 0xF

                    name = block_name(block_id)
                    yield chunk_x, chunk_z, x_local, y_base + y_local, z_local, block_id, meta, name


def process_file(mca_path, verbose=True):
    print(f"\n{'='*60}")
    print(f"File: {os.path.basename(mca_path)}")
    print(f"Size: {os.path.getsize(mca_path):,} bytes")
    print(f"{'='*60}")

    block_count = 0
    type_counts = {}
    printed = 0

    try:
        for cx, cz, x, y, z, bid, meta, name in iter_blocks_legacy(mca_path):
            block_count += 1
            key = f"{name}" + (f":{meta}" if meta != 0 else "")
            type_counts[key] = type_counts.get(key, 0) + 1

            if verbose and printed < 5000:
                print(f"  chunk({cx:2d},{cz:2d})  pos({x:2d},{y:3d},{z:2d})"
                      f"  id={bid:3d}:{meta}  {name}")
                printed += 1
    except Exception as e:
        print(f"  ERROR: {e}")

    if verbose and block_count > 5000:
        print(f"\n  ... output truncated after 5,000 lines ...")

    print(f"\n  --- Summary ---")
    print(f"  Total non-air blocks : {block_count:,}")
    print(f"  Unique block types   : {len(type_counts):,}")
    if type_counts:
        print("  Top 20 block types:")
        for name, count in sorted(type_counts.items(),
                                  key=lambda kv: kv[1], reverse=True)[:20]:
            print(f"    {count:>12,}  {name}")

    return type_counts


def find_mca_files(search_dir):
    pattern = os.path.join(search_dir, "**", "*.mca")
    return sorted(glob.glob(pattern, recursive=True))


def main():
    print(f"Searching: {SEARCH_DIR}\n")
    files = find_mca_files(SEARCH_DIR)

    if not files:
        print("No .mca files found.")
        return

    print(f"Found {len(files)} .mca file(s).")

    grand_total = 0
    grand_types = {}

    for path in files:
        counts = process_file(path, verbose=True)
        for name, n in counts.items():
            grand_total += n
            grand_types[name] = grand_types.get(name, 0) + n

    print(f"\n{'#'*60}")
    print(f"GRAND TOTAL")
    print(f"{'#'*60}")
    print(f"  Total non-air blocks : {grand_total:,}")
    print(f"  Unique block types   : {len(grand_types):,}")
    if grand_types:
        print("  Top 30 block types (all files combined):")
        for name, count in sorted(grand_types.items(),
                                  key=lambda kv: kv[1], reverse=True)[:30]:
            print(f"    {count:>12,}  {name}")

    print("\nDone.")


if __name__ == "__main__":
    main()
