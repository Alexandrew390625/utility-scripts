cd /storage/emulated/0/download
python grok_challenge.py