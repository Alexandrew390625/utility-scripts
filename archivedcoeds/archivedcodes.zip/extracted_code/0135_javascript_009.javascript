   205	const React = require("react");
   206	const ReactDOMServer = require("react-dom/server");
   207	const sharp = require("sharp");
   208	const { FaCheckCircle, FaChartLine } = require("react-icons/fa");
   209	
   210	function renderIconSvg(IconComponent, color = "#000000", size = 256) {
   211	  return ReactDOMServer.renderToStaticMarkup(
   212	    React.createElement(IconComponent, { color, size: String(size) })
   213	  );
   214	}
   215	
   216	async function iconToBase64Png(IconComponent, color, size = 256) {
   217	  const svg = renderIconSvg(IconComponent, color, size);
   218	  const pngBuffer = await sharp(Buffer.from(svg)).png().toBuffer();
   219	  return "image/png;base64," + pngBuffer.toString("base64");
   220	}
   221	