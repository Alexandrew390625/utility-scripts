   276	unzip -p /mnt/user-data/uploads/bundle.zip path/inside/file.txt
   277	