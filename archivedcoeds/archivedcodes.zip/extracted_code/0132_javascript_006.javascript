   155	slide.addImage({
   156	  path: "image.png",
   157	  x: 1, y: 1, w: 5, h: 3,
   158	  rotate: 45,              // 0-359 degrees
   159	  rounding: true,          // Circular crop
   160	  transparency: 50,        // 0-100
   161	  flipH: true,             // Horizontal flip
   162	  flipV: false,            // Vertical flip
   163	  altText: "Description",  // Accessibility
   164	  hyperlink: { url: "https://example.com" }
   165	});
   166	