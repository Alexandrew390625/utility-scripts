

<!-- 1 | Python script for word identification and validation | txt -->
```txt
This block is not supported on your current device yet.
```


<!-- 2 | Python script for word identification and validation | bash -->
```bash
python word_checker.py /path/to/your/file.txt
# or just run it and it will prompt you for the path
python word_checker.py
```


<!-- 3 | Python script for word identification and validation | txt -->
```txt
────────────────────────────────────────────────────────────
  WORD CHECK REPORT — myfile.txt
────────────────────────────────────────────────────────────
  Total word tokens   : 1,243
  Unique words        : 387
  Recognized          : 361  (93.3%)
  Unrecognized        : 26   (6.7%)
────────────────────────────────────────────────────────────

  ❌ Words NOT found in dictionary:

  valorant    idk    lol    omg    ...
```


<!-- 4 | Python script for word identification and validation | bash -->
```bash
    33	   stat -c '%s bytes, %y' /mnt/user-data/uploads/report.pdf
    34	   file /mnt/user-data/uploads/report.pdf
    35	   
```


<!-- 5 | Python script for word identification and validation | bash -->
```bash
    90	pdfinfo /mnt/user-data/uploads/report.pdf
    91	pdftotext -f 1 -l 1 /mnt/user-data/uploads/report.pdf - | head -20
    92	
```


<!-- 6 | Python script for word identification and validation | python -->
```python
    97	from pypdf import PdfReader
    98	r = PdfReader("/mnt/user-data/uploads/report.pdf")
    99	print(f"{len(r.pages)} pages")
   100	print(r.pages[0].extract_text()[:2000])
   101	
```


<!-- 7 | Python script for word identification and validation | bash -->
```bash
   120	extract-text /mnt/user-data/uploads/memo.docx | head -200
   121	
```


<!-- 8 | Python script for word identification and validation | bash -->
```bash
   134	extract-text /mnt/user-data/uploads/data.xlsx | head -100
   135	
```


<!-- 9 | Python script for word identification and validation | python -->
```python
   141	from openpyxl import load_workbook
   142	wb = load_workbook("/mnt/user-data/uploads/data.xlsx", read_only=True)
   143	print("Sheets:", wb.sheetnames)
   144	ws = wb.active
   145	for row in ws.iter_rows(max_row=5, values_only=True):
   146	    print(row)
   147	
```


<!-- 10 | Python script for word identification and validation | python -->
```python
   158	import pandas as pd
   159	df = pd.read_excel("/mnt/user-data/uploads/old.xls", engine="xlrd", nrows=5)
   160	
```


<!-- 11 | Python script for word identification and validation | python -->
```python
   165	import pandas as pd
   166	df = pd.read_excel("/mnt/user-data/uploads/data.ods", engine="odf", nrows=5)
   167	
```


<!-- 12 | Python script for word identification and validation | bash -->
```bash
   174	extract-text /mnt/user-data/uploads/deck.pptx | head -200
   175	
```


<!-- 13 | Python script for word identification and validation | python -->
```python
   193	import pandas as pd
   194	df = pd.read_csv("/mnt/user-data/uploads/data.csv", nrows=5)
   195	print(df)
   196	print()
   197	print(df.dtypes)
   198	
```


<!-- 14 | Python script for word identification and validation | bash -->
```bash
   205	wc -l /mnt/user-data/uploads/data.csv
   206	
```


<!-- 15 | Python script for word identification and validation | python -->
```python
   211	df = pd.read_csv("/mnt/user-data/uploads/data.csv")
   212	print(df.describe())
   213	
```


<!-- 16 | Python script for word identification and validation | bash -->
```bash
   224	jq 'type' /mnt/user-data/uploads/data.json
   225	jq 'if type == "array" then length elif type == "object" then keys else . end' /mnt/user-data/uploads/data.json
   226	
```


<!-- 17 | Python script for word identification and validation | bash -->
```bash
   237	head -3 /mnt/user-data/uploads/data.jsonl | jq .
   238	wc -l /mnt/user-data/uploads/data.jsonl
   239	
```


<!-- 18 | Python script for word identification and validation | python -->
```python
   253	from PIL import Image
   254	img = Image.open("/mnt/user-data/uploads/photo.jpg")
   255	print(img.size, img.mode, img.format)
   256	
```


<!-- 19 | Python script for word identification and validation | python -->
```python
   261	import pytesseract
   262	print(pytesseract.image_to_string(img))
   263	
```


<!-- 20 | Python script for word identification and validation | bash -->
```bash
   278	unzip -l /mnt/user-data/uploads/bundle.zip
   279	tar -tf /mnt/user-data/uploads/bundle.tar
   280	
```


<!-- 21 | Python script for word identification and validation | bash -->
```bash
   288	unzip -p /mnt/user-data/uploads/bundle.zip path/inside/file.txt
   289	
```


<!-- 22 | Python script for word identification and validation | bash -->
```bash
   295	zcat /mnt/user-data/uploads/data.json.gz | head -50
   296	
```


<!-- 23 | Python script for word identification and validation | bash -->
```bash
   303	extract-text /mnt/user-data/uploads/book.epub | head -200
   304	
```


<!-- 24 | Python script for word identification and validation | bash -->
```bash
   314	extract-text /mnt/user-data/uploads/notes.rtf | head -200
   315	extract-text /mnt/user-data/uploads/notebook.ipynb | head -200
   316	
```


<!-- 25 | Python script for word identification and validation | bash -->
```bash
   325	wc -c /mnt/user-data/uploads/app.log
   326	
```


<!-- 26 | Python script for word identification and validation | bash -->
```bash
   336	tail -200 /mnt/user-data/uploads/app.log
   337	
```


<!-- 27 | Python script for word identification and validation | bash -->
```bash
   344	file /mnt/user-data/uploads/mystery.bin
   345	xxd /mnt/user-data/uploads/mystery.bin | head -5
   346	
```


<!-- 28 | Python script for word identification and validation | py -->
```py
"""
word_checker.py
---------------
Reads a target file, extracts every word from it, and checks each word
against a dictionary. Prints a summary of recognized vs. unrecognized words.

Dictionary path: /storage/emulated/0/download/words.txt
"""

import re
import sys
import os
from pathlib import Path

# ── Configuration ────────────────────────────────────────────────────────────

DICTIONARY_PATH = "/storage/emulated/0/download/words.txt"

# ── Helpers ──────────────────────────────────────────────────────────────────

def load_dictionary(path: str) -> set[str]:
    """Load words from the dictionary file into a lowercase set."""
    dict_path = Path(path)
    if not dict_path.exists():
        print(f"[ERROR] Dictionary not found: {path}")
        sys.exit(1)

    with open(dict_path, "r", encoding="utf-8", errors="ignore") as f:
        words = {line.strip().lower() for line in f if line.strip()}

    print(f"[✓] Dictionary loaded: {len(words):,} words from '{path}'")
    return words


def extract_words(filepath: str) -> list[str]:
    """Extract all alphabetic words from a text file (order preserved)."""
    path = Path(filepath)
    if not path.exists():
        print(f"[ERROR] Input file not found: {filepath}")
        sys.exit(1)

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()

    # Keep only sequences of letters (strips punctuation, numbers, etc.)
    words = re.findall(r"[a-zA-Z]+", text)
    return words


def check_words(words: list[str], dictionary: set[str]) -> dict:
    """
    Compare words against the dictionary.

    Returns a dict with:
      - all_words        : original list (lowercase)
      - unique_words     : deduplicated set
      - recognized       : words found in dictionary
      - unrecognized     : words NOT found in dictionary
      - unrecognized_ordered : unrecognized words in first-appearance order
    """
    lowered = [w.lower() for w in words]
    unique = set(lowered)

    recognized = unique & dictionary
    unrecognized = unique - dictionary

    # Preserve first-appearance order for unrecognized words
    seen: set[str] = set()
    unrecognized_ordered: list[str] = []
    for w in lowered:
        if w in unrecognized and w not in seen:
            unrecognized_ordered.append(w)
            seen.add(w)

    return {
        "all_words": lowered,
        "unique_words": unique,
        "recognized": recognized,
        "unrecognized": unrecognized,
        "unrecognized_ordered": unrecognized_ordered,
    }


def print_report(results: dict, input_file: str) -> None:
    """Print a formatted summary report."""
    total     = len(results["all_words"])
    unique    = len(results["unique_words"])
    known     = len(results["recognized"])
    unknown   = len(results["unrecognized"])
    pct_known = (known / unique * 100) if unique else 0

    sep = "─" * 60

    print()
    print(sep)
    print(f"  WORD CHECK REPORT — {os.path.basename(input_file)}")
    print(sep)
    print(f"  Total word tokens   : {total:,}")
    print(f"  Unique words        : {unique:,}")
    print(f"  Recognized          : {known:,}  ({pct_known:.1f}%)")
    print(f"  Unrecognized        : {unknown:,}  ({100 - pct_known:.1f}%)")
    print(sep)

    if results["unrecognized_ordered"]:
        print("\n  ❌ Words NOT found in dictionary (first-appearance order):\n")
        # Print in columns for readability
        cols = 4
        words = results["unrecognized_ordered"]
        col_width = max(len(w) for w in words) + 3
        for i, word in enumerate(words):
            end = "\n" if (i + 1) % cols == 0 else ""
            print(f"  {word:<{col_width}}", end=end)
        if len(words) % cols != 0:
            print()  # newline after last partial row
    else:
        print("\n  ✅ All words were found in the dictionary!")

    print()


# ── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    # --- Get input file from argument or prompt ---
    if len(sys.argv) >= 2:
        input_file = sys.argv[1]
    else:
        input_file = input("Enter the path to the file you want to check: ").strip()

    if not input_file:
        print("[ERROR] No file path provided.")
        sys.exit(1)

    print(f"\n[→] Checking file: {input_file}")

    # --- Load dictionary ---
    dictionary = load_dictionary(DICTIONARY_PATH)

    # --- Extract words ---
    words = extract_words(input_file)
    if not words:
        print("[!] No words found in the input file.")
        sys.exit(0)
    print(f"[✓] Extracted {len(words):,} word tokens ({len(set(w.lower() for w in words)):,} unique)")

    # --- Check against dictionary ---
    results = check_words(words, dictionary)

    # --- Print report ---
    print_report(results, input_file)

    # --- Optional: save unrecognized words to a file ---
    if results["unrecognized_ordered"]:
        save = input("Save unrecognized words to a file? (y/n): ").strip().lower()
        if save == "y":
            out_path = Path(input_file).stem + "_unrecognized.txt"
            with open(out_path, "w", encoding="utf-8") as f:
                f.write("\n".join(results["unrecognized_ordered"]))
            print(f"[✓] Saved to: {out_path}")


if __name__ == "__main__":
    main()

```


<!-- 29 | Python script to find obscure words in dictionary | py -->
```py
"""
Word Checker — ChatGPT Challenge Edition
Checks which words from the challenge list exist in your dictionary file.
"""

import os
import sys

DICTIONARY_PATH = "/storage/emulated/0/download/words_backup.txt"

CHALLENGE_WORDS = [
    "syzygy",
    "floccinaucinihilipilification",
    "antidisestablishmentarianism",
    "pneumatoultramicroscopicsilicovolcanoconiosis",
    "qiviut",
    "susurrus",
    "callipygian",
    "petrichor",
    "defenestration",
    "ultracrepidarian",
    "xylophagous",
    "psithurism",
    "aeipathy",
    "oubliette",
    "kakorrhaphiophobia",
    "honorificabilitudinitatibus",
    "zwitterion",
    "thaumaturgy",
    "quomodocunquizing",
    "hippopotomonstrosesquipedaliophobia",
    "yeet",
    "rizz",
    "unalive",
    "skibidi",
    "gyatt",
    "blorbo",
]

def load_dictionary(path):
    if not os.path.exists(path):
        print(f"❌ Dictionary file not found: {path}")
        print("   Make sure the path is correct and the file exists.")
        sys.exit(1)

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        words = set(line.strip().lower() for line in f if line.strip())

    print(f"📖 Loaded {len(words):,} words from dictionary.\n")
    return words

def check_words(dictionary):
    found = []
    not_found = []

    for word in CHALLENGE_WORDS:
        if word.lower() in dictionary:
            found.append(word)
        else:
            not_found.append(word)

    return found, not_found

def print_results(found, not_found):
    total = len(CHALLENGE_WORDS)
    print("=" * 55)
    print("        🏆 CHATGPT WORD CHALLENGE RESULTS")
    print("=" * 55)

    print(f"\n✅ FOUND in your dictionary ({len(found)}/{total}):")
    if found:
        for w in found:
            print(f"   ✔  {w}")
    else:
        print("   (none)")

    print(f"\n❌ NOT FOUND in your dictionary ({len(not_found)}/{total}):")
    if not_found:
        for w in not_found:
            print(f"   ✘  {w}")
    else:
        print("   (none — your dictionary is insane!)")

    print("\n" + "=" * 55)
    score = len(found) / total * 100
    print(f"  Score: {len(found)}/{total} words found ({score:.1f}%)")
    print("=" * 55)

if __name__ == "__main__":
    # Allow overriding the path via command line argument
    path = sys.argv[1] if len(sys.argv) > 1 else DICTIONARY_PATH

    print(f"🔍 Checking dictionary: {path}\n")
    dictionary = load_dictionary(path)
    found, not_found = check_words(dictionary)
    print_results(found, not_found)

```


<!-- 30 | Python script to find obscure words in dictionary | bash -->
```bash
python check_words.py
```


<!-- 31 | Python script to find obscure words in dictionary | bash -->
```bash
python check_words.py /path/to/your/dictionary.txt
```


<!-- 32 | Python script to find obscure words in dictionary | bash -->
```bash
python check_words.py /storage/emulated/0/download/words.txt
```


<!-- 33 | Python script to find obscure words in dictionary | bash -->
```bash
wc -l /storage/emulated/0/download/words_backup.txt
```


<!-- 34 | Python script to find obscure words in dictionary | bash -->
```bash
# 1. Install Python first
pkg install python

# 2. Navigate to your download folder
cd /storage/emulated/0/download

# 3. Run the script
python check_words.py
```


<!-- 35 | Python script to find obscure words in dictionary | bash -->
```bash
termux-setup-storage
```


<!-- 36 | Python script to find obscure words in dictionary | python -->
```python
words = set(line.strip().lower() for line in f if line.strip())
```


<!-- 37 | Python script to find obscure words in dictionary | python -->
```python
words = {line.strip() for line in f if line.strip()}
```


<!-- 38 | Python script to find obscure words in dictionary | bash -->
```bash
cd /storage/emulated/0/download
python grok_challenge.py
```


<!-- 39 | Python script to find obscure words in dictionary | py -->
```py
"""
Grok Paragraph Challenge Checker
Extracts every word from Grok's challenge paragraph and checks
which ones exist in your dictionary.
"""

import re
import os
import sys

DICTIONARY_PATH = "/storage/emulated/0/download/words_backup.txt"

GROK_PARAGRAPH = """
In the crepuscular gloaming, a sesquipedalian xenologist pondered the nyctophobia-inducing
chthonic abysses of an exoplanet, where polyphyletic extremophiles exhibited pleiotropic
phenotypic plasticity under hyperbaric conditions. The eldritch thaumaturge, wielding a
quinquireme of iridescent orichalcum, deciphered petroglyphs etched by a palaeoanthropic
hominin with hapax legomenon inscriptions. Meanwhile, in the antediluvian archives, a
flibbertigibbet philomath discovered a palimpsest containing words like
supercalifragilisticexpialidocious alongside genuine logological oddities:
pneumonoultramicroscopicsilicovolcanoconiosis, hippopotomonstrosesquipedaliophobia, and the
Welsh Llanfairpwllgwyngyllgogerychwyrndrobwllllantysiliogogogoch. The astrophysicist
calculated the Schwarzschild radius while muttering about quantum chromodynamics and the
uncomputable Busy Beaver function BB(5).
"""

def load_dictionary(path):
    if not os.path.exists(path):
        print(f"❌ Dictionary not found: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        words = set(line.strip().lower() for line in f if line.strip())
    print(f"📖 Loaded {len(words):,} words from dictionary.\n")
    return words

def extract_words(text):
    # Extract only alphabetic words (no numbers, no punctuation)
    raw = re.findall(r"[a-zA-Z]+", text)
    # Deduplicate but preserve order
    seen = set()
    unique = []
    for w in raw:
        low = w.lower()
        if low not in seen:
            seen.add(low)
            unique.append(low)
    return unique

def check(words, dictionary):
    found = [w for w in words if w in dictionary]
    not_found = [w for w in words if w not in dictionary]
    return found, not_found

def print_results(found, not_found):
    total = len(found) + len(not_found)

    print("=" * 60)
    print("        🔥 GROK PARAGRAPH CHALLENGE RESULTS")
    print("=" * 60)

    print(f"\n✅ FOUND in dictionary ({len(found)}/{total}):")
    for w in found:
        print(f"   ✔  {w}")

    print(f"\n❌ NOT FOUND / Unknown ({len(not_found)}/{total}):")
    if not_found:
        for w in not_found:
            print(f"   ✘  {w}")
    else:
        print("   (none — perfect score!)")

    print("\n" + "=" * 60)
    score = len(found) / total * 100
    print(f"  Score: {len(found)}/{total} words recognized ({score:.1f}%)")
    print("=" * 60)

    # Reply text you can copy-paste back to Grok
    print("\n📋 COPY-PASTE REPLY FOR GROK:\n")
    print(f"My dictionary recognized {len(found)}/{total} unique words ({score:.1f}%).")
    if not_found:
        print(f"The ones it missed: {', '.join(not_found)}")
    else:
        print("It caught everything. Bring on the next round!")

if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else DICTIONARY_PATH
    print(f"🔍 Using dictionary: {path}\n")

    dictionary = load_dictionary(path)
    words = extract_words(GROK_PARAGRAPH)
    print(f"📝 Unique words extracted from paragraph: {len(words)}\n")

    found, not_found = check(words, dictionary)
    print_results(found, not_found)

```


<!-- 40 | Python script to find obscure words in dictionary | bash -->
```bash
python grok_pdf_challenge.py
```


<!-- 41 | Python script to find obscure words in dictionary | py -->
```py
"""
Grok PDF Challenge Checker
Checks all unique words from Chalmers' "Facing Up to the Problem of Consciousness"
against your dictionary file.
"""

import re
import os
import sys

DICTIONARY_PATH = "/storage/emulated/0/download/words_backup.txt"

# Full text extracted from the Chalmers PDF
PDF_TEXT = """
Facing Up to the Problem of Consciousness David J. Chalmers Philosophy Program
Research School of Social Sciences Australian National University

Consciousness poses the most baffling problems in the science of the mind. There is
nothing that we know more intimately than conscious experience, but there is nothing that is
harder to explain. All sorts of mental phenomena have yielded to scientific investigation in
recent years, but consciousness has stubbornly resisted. Many have tried to explain it, but the
explanations always seem to fall short of the target. Some have been led to suppose that the
problem is intractable, and that no good explanation can be given.

To make progress on the problem of consciousness, we have to confront it directly. In
this paper, I first isolate the truly hard part of the problem, separating it from more tractable
parts and giving an account of why it is so difficult to explain. I critique some recent work
that uses reductive methods to address consciousness, and argue that these methods inevitably
fail to come to grips with the hardest part of the problem. Once this failure is recognized, the
door to further progress is opened. In the second half of the paper, I argue that if we move to a
new kind of nonreductive explanation, a naturalistic account of consciousness can be given.
I put forward my own candidate for such an account: a nonreductive theory based on
principles of structural coherence and organizational invariance and a double-aspect view
of information.

The easy problems of consciousness include those of explaining the following phenomena:
the ability to discriminate, categorize, and react to environmental stimuli;
the integration of information by a cognitive system;
the reportability of mental states;
the ability of a system to access its own internal states;
the focus of attention;
the deliberate control of behavior;
the difference between wakefulness and sleep.

The really hard problem of consciousness is the problem of experience. When we think
and perceive, there is a whir of information-processing, but there is also a subjective aspect.
As Nagel has put it, there is something it is like to be a conscious organism. This
subjective aspect is experience. When we see, for example, we experience visual sensations:
the felt quality of redness, the experience of dark and light, the quality of depth in a visual
field. Other experiences go along with perception in different modalities: the sound of a
clarinet, the smell of mothballs. Then there are bodily sensations, from pains to orgasms;
mental images that are conjured up internally; the felt quality of emotion, and the experience
of a stream of conscious thought. What unites all of these states is that there is something it is
like to be in them. All of them are states of experience.

Why is it that when our cognitive systems engage in visual and auditory information-processing,
we have visual or auditory experience: the quality of deep blue, the sensation of middle C?
How can we explain why there is something it is like to entertain a mental image, or to
experience an emotion? It is widely agreed that experience arises from a physical basis, but we
have no good explanation of why and how it so arises. Why should physical processing give
rise to a rich inner life at all? It seems objectively unreasonable that it should, and yet it does.

Sometimes terms such as phenomenal consciousness and qualia are also used here, but I
find it more natural to speak of conscious experience or simply experience. Another
useful way to avoid confusion is to reserve the term consciousness for the phenomena of
experience, using the less loaded term awareness for the more straightforward phenomena
described earlier.

Why are the easy problems easy, and why is the hard problem hard? The easy problems
are easy precisely because they concern the explanation of cognitive abilities and functions.
To explain a cognitive function, we need only specify a mechanism that can perform the
function. The methods of cognitive science are well-suited for this sort of explanation.
By contrast, the hard problem is hard precisely because it is not a problem about the
performance of functions. The problem persists even when the performance of all the
relevant functions is explained.

To explain reportability, for instance, is just to explain how a system could perform the
function of producing reports on internal states. To explain internal access, we need to explain
how a system could be appropriately affected by its internal states and use information about
those states in directing later processes. To explain integration and control, we need to explain
how a system's central processes can bring information contents together and use them in the
facilitation of various behaviors.

The first is the neurobiological theory of consciousness outlined by Crick and Koch.
This theory centers on certain neural oscillations in the cerebral cortex; Crick and Koch
hypothesize that these oscillations are the basis of consciousness. This is partly because the
oscillations seem to be correlated with awareness in a number of different modalities within
the visual and olfactory systems, and also because they suggest a mechanism by which the
binding of information contents might be achieved. Binding is the process whereby separately
represented pieces of information about a single entity are brought together to be used by
later processing, as when information about the color and shape of a perceived object is
integrated from separate visual pathways.

The second example is an approach at the level of cognitive psychology. This is Bernard
Baars global workspace theory of consciousness. According to this theory, the contents of
consciousness are contained in a global workspace, a central processor used to mediate
communication between a host of specialized nonconscious processors. When these
specialized processors need to broadcast information to the rest of the system, they do so by
sending this information to the workspace, which acts as a kind of communal blackboard for
the rest of the system, accessible to all the other processors.

Nonalgorithmic processing is put forward by Penrose because of the role it might play
in the process of conscious mathematical insight. The arguments about mathematics are
controversial, but even if they succeed and an account of nonalgorithmic processing in the
human brain is given, it will still only be an account of the functions involved in mathematical
reasoning and the like.

Perhaps the most popular extra ingredient of all is quantum mechanics. The attractiveness
of quantum theories of consciousness may stem from a Law of Minimization of Mystery:
consciousness is mysterious and quantum mechanics is mysterious, so maybe the two
mysteries have a common source. Nevertheless, quantum theories of consciousness suffer
from the same difficulties as neural or computational theories. Quantum phenomena have some
remarkable functional properties, such as nondeterminism and nonlocality.

At the end of the day, the same criticism applies to any purely physical account of
consciousness. For any physical process we specify there will be an unanswered question:
Why should this process give rise to experience? Given any such process, it is conceptually
coherent that it could be instantiated in the absence of experience. It follows that no mere
account of the physical process will tell us why experience arises. The emergence of
experience goes beyond what can be derived from physical theory.

I suggest that a theory of consciousness should take experience as fundamental. We
know that a theory of consciousness requires the addition of something fundamental to our
ontology, as everything in physical theory is compatible with the absence of consciousness.
We might add some entirely new nonphysical feature, from which experience can be derived,
but it is hard to see what such a feature would be like. More likely, we will take experience
itself as a fundamental feature of the world, alongside mass, charge, and space-time.

This position qualifies as a variety of dualism, as it postulates basic properties over and
above the properties invoked by physics. But it is an innocent version of dualism, entirely
compatible with the scientific view of the world. Nothing in this approach contradicts
anything in physical theory; we simply need to add further bridging principles to explain how
experience arises from physical processes. There is nothing particularly spiritual or mystical
about this theory. If the position is to have a name, a good choice might be naturalistic dualism.

The principle of structural coherence. This is a principle of coherence between the
structure of consciousness and the structure of awareness. The contents of awareness are to be
understood as those information contents that are accessible to central systems, and brought
to bear in a widespread way in the control of behavior.

The principle of organizational invariance. This principle states that any two systems
with the same fine-grained functional organization will have qualitatively identical experiences.
If the causal patterns of neural organization were duplicated in silicon, for example, with a
silicon chip for every neuron and the same patterns of interaction, then the same experiences
would arise. According to this principle, what matters for the emergence of experience is not
the specific physical makeup of a system, but the abstract pattern of causal interaction
between its components.

The double-aspect theory of information. I understand information in more or less the
sense of Shannon. Where there is information, there are information states embedded in an
information space. An information space has a basic structure of difference relations between
its elements, characterizing the ways in which different elements in a space are similar or
different, possibly in complex ways. An information space is an abstract object, but following
Shannon we can see information as physically embodied when there is a space of distinct
physical states.

Wheeler has suggested that information is fundamental to the physics of the universe.
According to this it from bit doctrine, the laws of physics can be cast in terms of
information, postulating different states that give rise to different effects without actually
saying what those states are. If so, then information is a natural candidate to also play a role
in a fundamental theory of consciousness. We are led to a conception of the world on which
information is truly fundamental, and on which it has two basic aspects, corresponding to the
physical and the phenomenal features of the world.

The theory I have presented is speculative, but it is a candidate theory. I suspect that the
principles of structural coherence and organizational invariance will be planks in any
satisfactory theory of consciousness; the status of the double-aspect theory of information is
less certain. Most existing theories of consciousness either deny the phenomenon, explain
something else, or elevate the problem to an eternal mystery. I hope to have shown that it is
possible to make progress on the problem even while taking it seriously. The hard problem is
a hard problem, but there is no reason to believe that it will remain permanently unsolved.

Additional terms from the paper: psychophysical, nonreductive, reductio, explanandum,
isomorphism, phenomenal, qualia, epiphenomenal, neurophysiological, neurobiological,
introspective, nondeterminism, nonlocality, ontology, a posteriori, electromagnetism,
electromagnetic, vitalist, biochemical, cognitively, intersubjective, homogeneity,
underdetermined, extrinsic, panpsychism, thermostat, isomorph, nomologically,
intractable, ineffability, subjectivity, reportability, wakefulness, nonconscious,
nonalgorithmic, metaphysical, psychophysics, functionalism, eliminativism
"""


def load_dictionary(path):
    if not os.path.exists(path):
        print(f"❌ Dictionary not found: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        words = set(line.strip().lower() for line in f if line.strip())
    print(f"📖 Loaded {len(words):,} words from dictionary.\n")
    return words


def extract_words(text):
    raw = re.findall(r"[a-zA-Z]+", text)
    seen = set()
    unique = []
    for w in raw:
        low = w.lower()
        if low not in seen and len(low) > 2:  # skip tiny words like "a", "of"
            seen.add(low)
            unique.append(low)
    return unique


def check(words, dictionary):
    found = [w for w in words if w in dictionary]
    not_found = [w for w in words if w not in dictionary]
    return found, not_found


def print_results(found, not_found, total):
    print("=" * 60)
    print("      📄 GROK PDF CHALLENGE — CHALMERS PAPER")
    print("=" * 60)

    print(f"\n✅ FOUND in dictionary ({len(found)}/{total}):")
    for w in found:
        print(f"   ✔  {w}")

    print(f"\n❌ NOT FOUND / Unknown ({len(not_found)}/{total}):")
    if not_found:
        for w in not_found:
            print(f"   ✘  {w}")
    else:
        print("   (none — dictionary is a beast!)")

    print("\n" + "=" * 60)
    score = len(found) / total * 100
    print(f"  Score: {len(found)}/{total} unique words recognized ({score:.1f}%)")
    print("=" * 60)

    print("\n📋 COPY-PASTE REPLY FOR GROK:\n")
    print(f"My dictionary recognized {len(found)}/{total} unique words from the Chalmers paper ({score:.1f}%).")
    if not_found:
        missed = ", ".join(not_found)
        print(f"Words it missed: {missed}")
    else:
        print("It caught every single word. What's next?")


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else DICTIONARY_PATH
    print(f"🔍 Using dictionary: {path}\n")

    dictionary = load_dictionary(path)
    words = extract_words(PDF_TEXT)
    total = len(words)
    print(f"📝 Unique words extracted from PDF: {total}\n")

    found, not_found = check(words, dictionary)
    print_results(found, not_found, total)

```


<!-- 42 | Python script to find obscure words in dictionary | bash -->
```bash
# Install pypdf first (only needed once)
pip install pypdf

# Run it
cd /storage/emulated/0/download
python grok_pdf_challenge.py
```


<!-- 43 | Python script to find obscure words in dictionary | bash -->
```bash
    24	# Always: page count, file size, PDF version, metadata
    25	pdfinfo document.pdf
    26	
    27	# Always: quick text extraction check — is this a text PDF or a scan?
    28	pdftotext -f 1 -l 1 document.pdf - | head -20
    29	
    30	# If figures/charts may matter:
    31	pdfimages -list document.pdf
    32	
    33	# If the PDF might contain embedded files (reports, portfolios):
    34	pdfdetach -list document.pdf
    35	
    36	# If text extraction looks garbled:
    37	pdffonts document.pdf
    38	
```


<!-- 44 | Python script to find obscure words in dictionary | python -->
```python
    55	from pypdf import PdfReader
    56	
    57	reader = PdfReader("document.pdf")
    58	print(f"Pages: {len(reader.pages)}")
    59	
    60	# Extract text
    61	text = ""
    62	for page in reader.pages:
    63	    text += page.extract_text()
    64	
```


<!-- 45 | Python script to find obscure words in dictionary | bash -->
```bash
    68	# Layout mode preserves spatial positioning
    69	pdftotext -layout document.pdf output.txt
    70	
    71	# Specific page range
    72	pdftotext -f 1 -l 5 document.pdf output.txt
    73	
```


<!-- 46 | Python script to find obscure words in dictionary | python -->
```python
    77	import pdfplumber
    78	
    79	with pdfplumber.open("document.pdf") as pdf:
    80	    for page in pdf.pages:
    81	        text = page.extract_text()
    82	        print(text)
    83	
```


<!-- 47 | Python script to find obscure words in dictionary | bash -->
```bash
    92	# Rasterize a single page (page 3 here) at 150 DPI
    93	pdftoppm -jpeg -r 150 -f 3 -l 3 document.pdf /tmp/page
    94	
    95	# pdftoppm zero-pads the output filename based on TOTAL page count
    96	# (e.g., page-03.jpg for a 50-page PDF, page-003.jpg for 200+ pages)
    97	# Don't guess the filename — find it:
    98	ls /tmp/page-*.jpg
    99	
```


<!-- 48 | Python script to find obscure words in dictionary | bash -->
```bash
   147	# List all embedded images with metadata (size, color, compression)
   148	pdfimages -list document.pdf
   149	
   150	# Extract all images as PNG
   151	pdfimages -png document.pdf /tmp/img
   152	
   153	# Extract from specific pages only (pages 3-5)
   154	pdfimages -png -f 3 -l 5 document.pdf /tmp/img
   155	
   156	# Extract in original format (JPEG stays JPEG, etc.)
   157	pdfimages -all document.pdf /tmp/img
   158	
```


<!-- 49 | Python script to find obscure words in dictionary | python -->
```python
   175	import fitz  # PyMuPDF
   176	
   177	doc = fitz.open("document.pdf")
   178	for page in doc:
   179	    for img in page.get_images():
   180	        xref = img[0]
   181	        pix = fitz.Pixmap(doc, xref)
   182	        if pix.n - pix.alpha > 3:  # CMYK or other non-RGB
   183	            pix = fitz.Pixmap(fitz.csRGB, pix)
   184	        pix.save(f"/tmp/img_{xref}.png")
   185	
```


<!-- 50 | Python script to find obscure words in dictionary | bash -->
```bash
   194	# List all attachments
   195	pdfdetach -list document.pdf
   196	
   197	# Extract all attachments to a directory
   198	mkdir -p /tmp/attachments
   199	pdfdetach -saveall -o /tmp/attachments/ document.pdf
   200	
   201	# Extract a specific attachment by number (1-based index from -list output)
   202	pdfdetach -save 1 -o /tmp/attachment.pdf document.pdf
   203	
```


<!-- 51 | Python script to find obscure words in dictionary | python -->
```python
   207	import os
   208	from pypdf import PdfReader
   209	
   210	reader = PdfReader("document.pdf")
   211	for name, content_list in reader.attachments.items():
   212	    safe_name = os.path.basename(name)  # sanitize — name comes from the PDF
   213	    for content in content_list:
   214	        with open(f"/tmp/{safe_name}", "wb") as f:
   215	            f.write(content)
   216	
```


<!-- 52 | Python script to find obscure words in dictionary | python -->
```python
   231	from pypdf import PdfReader
   232	
   233	reader = PdfReader("form.pdf")
   234	
   235	# Text input fields only:
   236	fields = reader.get_form_text_fields()
   237	for name, value in fields.items():
   238	    print(f"{name}: {value}")
   239	
   240	# All field types (checkboxes, radio buttons, dropdowns too):
   241	all_fields = reader.get_fields() or {}
   242	for name, field in all_fields.items():
   243	    print(f"{name}: {field.get('/V', '')} (type: {field.get('/FT', '')})")
   244	
```


<!-- 53 | Python script to find obscure words in dictionary | bash -->
```bash
   252	pdftk form.pdf dump_data_fields
   253	
```


<!-- 54 | Python script to find obscure words in dictionary | bash -->
```bash
   273	pdffonts document.pdf
   274	
```


<!-- 55 | Python script to find obscure words in dictionary | py -->
```py
"""
Grok PDF Challenge Checker
Reads the PDF directly — no copy-pasting, no hallucinations.
Checks every unique word against your dictionary.

Usage:
    python grok_pdf_challenge.py
    python grok_pdf_challenge.py /path/to/other_dictionary.txt
"""

import re
import os
import sys

DICTIONARY_PATH = "/storage/emulated/0/download/words_backup.txt"
PDF_PATH        = "/storage/emulated/0/download/facing.pdf"

def load_dictionary(path):
    if not os.path.exists(path):
        print(f"❌ Dictionary not found: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        words = set(line.strip().lower() for line in f if line.strip())
    print(f"📖 Loaded {len(words):,} words from dictionary.")
    return words

def extract_text_from_pdf(path):
    try:
        from pypdf import PdfReader
    except ImportError:
        print("❌ pypdf not installed. Run: pip install pypdf")
        sys.exit(1)

    if not os.path.exists(path):
        print(f"❌ PDF not found: {path}")
        sys.exit(1)

    reader = PdfReader(path)
    print(f"📄 PDF loaded: {len(reader.pages)} pages.")
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    print(f"🔤 Characters extracted from PDF: {len(text):,}")
    return text

def extract_words(text):
    raw = re.findall(r"[a-zA-Z]+", text)
    seen = set()
    unique = []
    for w in raw:
        low = w.lower()
        if low not in seen and len(low) > 2:  # skip tiny words like "a", "of"
            seen.add(low)
            unique.append(low)
    return unique

def check(words, dictionary):
    found     = [w for w in words if w in dictionary]
    not_found = [w for w in words if w not in dictionary]
    return found, not_found

def print_results(found, not_found):
    total = len(found) + len(not_found)
    print("\n" + "=" * 60)
    print("      📄 GROK PDF CHALLENGE — CHALMERS PAPER")
    print("=" * 60)

    print(f"\n✅ FOUND in dictionary ({len(found)}/{total}):")
    for w in found:
        print(f"   ✔  {w}")

    print(f"\n❌ NOT FOUND ({len(not_found)}/{total}):")
    if not_found:
        for w in not_found:
            print(f"   ✘  {w}")
    else:
        print("   (none — perfect score!)")

    print("\n" + "=" * 60)
    score = len(found) / total * 100
    print(f"  Score: {len(found)}/{total} unique words recognized ({score:.1f}%)")
    print("=" * 60)

    print("\n📋 COPY-PASTE REPLY FOR GROK:\n")
    print(f"My dictionary recognized {len(found)}/{total} unique words from the Chalmers paper ({score:.1f}%).")
    if not_found:
        print(f"Words it missed: {', '.join(not_found)}")
    else:
        print("It caught every single word. What's next?")

if __name__ == "__main__":
    dict_path = sys.argv[1] if len(sys.argv) > 1 else DICTIONARY_PATH
    pdf_path  = sys.argv[2] if len(sys.argv) > 2 else PDF_PATH

    print(f"🔍 Dictionary: {dict_path}")
    print(f"📂 PDF: {pdf_path}\n")

    dictionary = load_dictionary(dict_path)
    text       = extract_text_from_pdf(pdf_path)
    words      = extract_words(text)

    print(f"📝 Unique words extracted (length > 2): {len(words):,}\n")

    found, not_found = check(words, dictionary)
    print_results(found, not_found)

```


<!-- 56 | Python script to find obscure words in dictionary | py -->
```py
"""
Grok PDF Challenge Checker
Reads the PDF directly — no copy-pasting, no hallucinations.
Checks every unique word against your dictionary.

Usage:
    python grok_pdf_challenge.py
    python grok_pdf_challenge.py /path/to/other_dictionary.txt
"""

import re
import os
import sys

DICTIONARY_PATH = "/storage/emulated/0/download/words_backup.txt"
PDF_PATH        = "/storage/emulated/0/download/facing.pdf"

def load_dictionary(path):
    if not os.path.exists(path):
        print(f"❌ Dictionary not found: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        words = set(line.strip().lower() for line in f if line.strip())
    print(f"📖 Loaded {len(words):,} words from dictionary.")
    return words

def extract_text_from_pdf(path):
    try:
        from pypdf import PdfReader
    except ImportError:
        print("❌ pypdf not installed. Run: pip install pypdf")
        sys.exit(1)

    if not os.path.exists(path):
        print(f"❌ PDF not found: {path}")
        sys.exit(1)

    reader = PdfReader(path)
    print(f"📄 PDF loaded: {len(reader.pages)} pages.")
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    print(f"🔤 Characters extracted from PDF: {len(text):,}")
    return text

def extract_words(text):
    raw = re.findall(r"[a-zA-Z]+", text)
    seen = set()
    unique = []
    for w in raw:
        low = w.lower()
        if low not in seen and len(low) > 2:
            seen.add(low)
            unique.append(low)
    return unique

def check(words, dictionary):
    found     = [w for w in words if w in dictionary]
    not_found = [w for w in words if w not in dictionary]
    return found, not_found

def print_results(found, not_found):
    total = len(found) + len(not_found)
    print("\n" + "=" * 60)
    print("      📄 GROK PDF CHALLENGE — CHALMERS PAPER")
    print("=" * 60)

    print(f"\n✅ FOUND in dictionary ({len(found)}/{total}):")
    for w in found:
        print(f"   ✔  {w}")

    print(f"\n❌ NOT FOUND ({len(not_found)}/{total}):")
    if not_found:
        for w in not_found:
            print(f"   ✘  {w}")
    else:
        print("   (none — perfect score!)")

    print("\n" + "=" * 60)
    score = len(found) / total * 100
    print(f"  Score: {len(found)}/{total} unique words recognized ({score:.1f}%)")
    print("=" * 60)

    print("\n📋 COPY-PASTE REPLY FOR GROK:\n")
    print(f"My dictionary recognized {len(found)}/{total} unique words ({score:.1f}%).")
    if not_found:
        print(f"Words it missed: {', '.join(not_found)}")
    else:
        print("It caught every single word. What's next?")

if __name__ == "__main__":
    dict_path = sys.argv[1] if len(sys.argv) > 1 else DICTIONARY_PATH
    pdf_path  = sys.argv[2] if len(sys.argv) > 2 else PDF_PATH

    print(f"🔍 Dictionary: {dict_path}")
    print(f"📂 PDF: {pdf_path}\n")

    dictionary = load_dictionary(dict_path)
    text       = extract_text_from_pdf(pdf_path)
    words      = extract_words(text)

    print(f"📝 Unique words extracted (length > 2): {len(words):,}\n")

    found, not_found = check(words, dictionary)
    print_results(found, not_found)

```


<!-- 57 | Expanding word list with Python script | txt -->
```txt
Viewing artifacts created via the Analysis Tool web feature preview isn’t yet supported on mobile.
```


<!-- 58 | Expanding word list with Python script | txt -->
```txt
https://raw.githubusercontent.com/hyperreality/American-British-English-Translator/master/data/british_spellings.json
```


<!-- 59 | Expanding word list with Python script | txt -->
```txt
https://raw.githubusercontent.com/nsoubes/medical-word-list/master/medical_word_list.txt
```


<!-- 60 | Expanding word list with Python script | txt -->
```txt
Terms:              98119
Contents:           drug names (up-to-date with FDA-approvals as of 2014-04-02, trade and generic names),
                    anatomical terms, dermatological terms, internal medicine terms, surgical terms,
                    DSM-IV terms, ICD-9 terms, and many more
Author:             (c) 2014-2017 Aristotelis P. (https://github.com/Glutanimate)
Original Authors:   (c) 2007-2014 R. Robinson <info@e-medtools.com>, 
                    (c) 2009-2014 Rajasekharan N. <https://plus.google.com/u/0/+Rajasekharan-N/>
Original Sources:   - OpenMedSpel by R. Robinson of e-MedTools (Version 2.0.0, released 2014-01-21)
                      <http://www.e-medtools.com/openmedspel.html>
                    - MTH-Med-Spel-Chek by Rajasekharan N. of MT-Herald (released 2014-04-02)
                      <http://mtherald.com/free-medical-spell-checker-for-microsoft-word-custom-dictionary/>
License:            GNU GPL v3 (see LICENSEs for more information)
```


<!-- 61 | Expanding word list with Python script | txt -->
```txt
https://raw.githubusercontent.com/medical-spell-checker-dictionary/medical-spell-checker-dictionary.github.io/master/US-English-Medical-Dictionary.dic
```


<!-- 62 | Expanding word list with Python script | txt -->
```txt
https://raw.githubusercontent.com/scrabblewords/scrabblewords/main/words/North-American/NWL2020.txt
```


<!-- 63 | Expanding word list with Python script | txt -->
```txt
https://raw.githubusercontent.com/titoBouzout/Dictionaries/master/Latin_la.txt
```


<!-- 64 | Expanding word list with Python script | txt -->
```txt
https://raw.githubusercontent.com/david47k/top-english-wordlists/refs/heads/master/top_english_words_lower_50000.txt
```


<!-- 65 | Expanding word list with Python script | python -->
```python
import os
os.replace("/storage/emulated/0/download/words_backup.txt",
           "/storage/emulated/0/download/words.txt")
print("Done! Backup is now the main file.")
```


<!-- 66 | Custom Scratch block for list range extraction | js -->
```js
// ============================================================
//  Scratch 3.0 Custom Extension — List Range with Custom Join
//  Block: "list items [FROM] to [TO] of [LIST] joined by [SEP]"
// ============================================================

(function () {
  'use strict';

  // ---------- Extension Class ----------
  class ListRangeExtension {
    getInfo() {
      return {
        id: 'listrange',
        name: 'List Range',
        color1: '#5C6BC0',
        color2: '#3949AB',
        color3: '#283593',
        blocks: [
          {
            opcode: 'getRange',
            blockType: Scratch.BlockType.REPORTER,
            text: 'list items [FROM] to [TO] of [LIST] joined by [SEP]',
            arguments: {
              FROM: {
                type: Scratch.ArgumentType.NUMBER,
                defaultValue: 1,
              },
              TO: {
                type: Scratch.ArgumentType.NUMBER,
                defaultValue: 5,
              },
              LIST: {
                type: Scratch.ArgumentType.STRING,
                defaultValue: 'my list',
              },
              SEP: {
                type: Scratch.ArgumentType.STRING,
                defaultValue: ', ',
              },
            },
          },
          {
            opcode: 'getRangeCount',
            blockType: Scratch.BlockType.REPORTER,
            text: 'number of items [FROM] to [TO] of [LIST]',
            arguments: {
              FROM: {
                type: Scratch.ArgumentType.NUMBER,
                defaultValue: 1,
              },
              TO: {
                type: Scratch.ArgumentType.NUMBER,
                defaultValue: 5,
              },
              LIST: {
                type: Scratch.ArgumentType.STRING,
                defaultValue: 'my list',
              },
            },
          },
          '---', // separator line
          {
            opcode: 'getItem',
            blockType: Scratch.BlockType.REPORTER,
            text: 'item [INDEX] of [LIST]',
            arguments: {
              INDEX: {
                type: Scratch.ArgumentType.NUMBER,
                defaultValue: 1,
              },
              LIST: {
                type: Scratch.ArgumentType.STRING,
                defaultValue: 'my list',
              },
            },
          },
        ],
      };
    }

    // ---- Helper: resolve list by name from runtime ----
    _getList(args, util) {
      const name = args.LIST;
      const stage = util.runtime.getTargetForStage();
      const target = util.target;

      // Search in current sprite, then stage
      const findIn = (t) =>
        Object.values(t.variables).find(
          (v) => v.type === 'list' && v.name === name
        );

      return findIn(target) || findIn(stage) || null;
    }

    // ---- Block: list items FROM to TO joined by SEP ----
    getRange(args, util) {
      const from = Math.round(Number(args.FROM));
      const to   = Math.round(Number(args.TO));
      const sep  = String(args.SEP);          // user-defined separator
      const list = this._getList(args, util);

      if (!list || !list.value || list.value.length === 0) return '';

      const items = list.value;
      const len   = items.length;

      // Clamp indices to valid range (1-based → 0-based)
      const start = Math.max(1, Math.min(from, len));
      const end   = Math.max(1, Math.min(to,   len));

      // Support reverse ranges (e.g. 5 to 1)
      const slice =
        start <= end
          ? items.slice(start - 1, end)
          : items.slice(end - 1, start).reverse();

      return slice.join(sep);
    }

    // ---- Block: count items FROM to TO ----
    getRangeCount(args, util) {
      const from = Math.round(Number(args.FROM));
      const to   = Math.round(Number(args.TO));
      const list = this._getList(args, util);

      if (!list || !list.value) return 0;

      const len   = list.value.length;
      const start = Math.max(1, Math.min(from, len));
      const end   = Math.max(1, Math.min(to,   len));

      return Math.abs(end - start) + 1;
    }

    // ---- Block: get single item by index ----
    getItem(args, util) {
      const index = Math.round(Number(args.INDEX));
      const list  = this._getList(args, util);

      if (!list || !list.value) return '';
      if (index < 1 || index > list.value.length) return '';

      return list.value[index - 1];
    }
  }

  // ---------- Register the extension ----------
  Scratch.extensions.register(new ListRangeExtension());
})();

```


<!-- 67 | Custom Scratch block for list range extraction | python -->
```python
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>List Range Extension — Preview</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0f0f14;
    --panel: #18181f;
    --border: #2a2a38;
    --accent: #5C6BC0;
    --accent2: #9575CD;
    --good: #66BB6A;
    --text: #e8e8f0;
    --muted: #7070a0;
    --mono: 'Space Mono', monospace;
    --sans: 'DM Sans', sans-serif;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    min-height: 100vh;
    padding: 32px 20px;
  }

  header {
    text-align: center;
    margin-bottom: 40px;
  }

  header h1 {
    font-family: var(--mono);
    font-size: clamp(1.2rem, 4vw, 1.8rem);
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: -0.5px;
  }

  header p {
    color: var(--muted);
    margin-top: 8px;
    font-size: 0.9rem;
  }

  .badge {
    display: inline-block;
    background: var(--accent);
    color: #fff;
    font-family: var(--mono);
    font-size: 0.65rem;
    padding: 2px 8px;
    border-radius: 20px;
    margin-top: 10px;
    letter-spacing: 1px;
  }

  /* --- Block Preview --- */
  .block-preview {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 24px;
    max-width: 700px;
    margin: 0 auto 32px;
  }

  .block-preview h2 {
    font-family: var(--mono);
    font-size: 0.75rem;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 2px;
    margin-bottom: 16px;
  }

  .scratch-block {
    display: inline-flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
    background: #5C6BC0;
    color: #fff;
    padding: 10px 14px;
    border-radius: 8px;
    font-family: var(--mono);
    font-size: 0.82rem;
    box-shadow: 0 4px 20px rgba(92,107,192,0.4);
    position: relative;
    line-height: 1.8;
  }

  .scratch-block::before {
    content: '';
    position: absolute;
    left: 8px;
    top: -8px;
    width: 20px;
    height: 10px;
    background: #5C6BC0;
    border-radius: 4px 4px 0 0;
  }

  .block-arg {
    background: rgba(255,255,255,0.2);
    border-radius: 4px;
    padding: 2px 8px;
    font-weight: 700;
    white-space: nowrap;
  }

  /* --- Playground --- */
  .playground {
    max-width: 700px;
    margin: 0 auto;
    display: grid;
    gap: 20px;
  }

  .card {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 24px;
  }

  .card h3 {
    font-family: var(--mono);
    font-size: 0.75rem;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 2px;
    margin-bottom: 16px;
  }

  .list-editor {
    display: flex;
    gap: 8px;
    margin-bottom: 12px;
  }

  input[type="text"], input[type="number"], select {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 8px;
    color: var(--text);
    font-family: var(--sans);
    font-size: 0.9rem;
    padding: 8px 12px;
    outline: none;
    transition: border-color 0.2s;
  }

  input:focus, select:focus {
    border-color: var(--accent);
  }

  input[type="text"] { flex: 1; }
  input[type="number"] { width: 70px; }

  button {
    background: var(--accent);
    border: none;
    border-radius: 8px;
    color: #fff;
    cursor: pointer;
    font-family: var(--mono);
    font-size: 0.78rem;
    padding: 8px 14px;
    transition: background 0.2s, transform 0.1s;
  }

  button:hover { background: #3949AB; }
  button:active { transform: scale(0.97); }

  .btn-remove {
    background: #37373f;
    font-size: 1rem;
    padding: 6px 10px;
  }
  .btn-remove:hover { background: #c62828; }

  .list-items {
    display: flex;
    flex-direction: column;
    gap: 6px;
    max-height: 200px;
    overflow-y: auto;
  }

  .list-item {
    display: flex;
    align-items: center;
    gap: 8px;
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 6px 12px;
    font-family: var(--mono);
    font-size: 0.85rem;
  }

  .item-index {
    color: var(--muted);
    min-width: 24px;
    font-size: 0.7rem;
  }

  .item-val { flex: 1; }

  /* Controls */
  .controls {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
  }

  .control-group label {
    display: block;
    font-size: 0.78rem;
    color: var(--muted);
    margin-bottom: 6px;
    font-family: var(--mono);
  }

  .sep-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 4px;
  }

  .sep-btn {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 6px;
    color: var(--text);
    font-family: var(--mono);
    font-size: 0.8rem;
    padding: 5px 12px;
    cursor: pointer;
    transition: all 0.15s;
  }

  .sep-btn:hover, .sep-btn.active {
    background: var(--accent);
    border-color: var(--accent);
    color: #fff;
  }

  .sep-custom {
    display: flex;
    gap: 8px;
    margin-top: 8px;
    align-items: center;
  }

  .sep-custom label {
    font-size: 0.78rem;
    color: var(--muted);
    white-space: nowrap;
    font-family: var(--mono);
  }

  /* Output */
  .output-box {
    background: var(--bg);
    border: 1px solid var(--accent);
    border-radius: 10px;
    padding: 16px 20px;
    font-family: var(--mono);
    font-size: 0.9rem;
    min-height: 52px;
    color: var(--good);
    word-break: break-all;
    transition: all 0.2s;
    position: relative;
  }

  .output-box::before {
    content: 'OUTPUT';
    position: absolute;
    top: -9px;
    left: 14px;
    background: var(--bg);
    padding: 0 6px;
    font-size: 0.6rem;
    letter-spacing: 2px;
    color: var(--accent);
    font-family: var(--mono);
  }

  .output-count {
    color: var(--muted);
    font-size: 0.75rem;
    margin-top: 8px;
    font-family: var(--mono);
  }

  .run-btn {
    width: 100%;
    padding: 12px;
    font-size: 0.85rem;
    margin-top: 4px;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    box-shadow: 0 4px 20px rgba(92,107,192,0.35);
    border-radius: 10px;
  }

  .run-btn:hover {
    background: linear-gradient(135deg, #3949AB, #7B1FA2);
  }

  /* How to use */
  .how-to {
    background: #101018;
    border: 1px dashed var(--border);
    border-radius: 14px;
    padding: 24px;
    max-width: 700px;
    margin: 0 auto 32px;
  }

  .how-to h2 {
    font-family: var(--mono);
    font-size: 0.75rem;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 2px;
    margin-bottom: 14px;
  }

  .step {
    display: flex;
    gap: 14px;
    margin-bottom: 12px;
    font-size: 0.88rem;
    color: #b0b0d0;
  }

  .step-num {
    font-family: var(--mono);
    font-size: 0.7rem;
    background: var(--accent);
    color: #fff;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    margin-top: 1px;
  }

  code {
    background: var(--border);
    padding: 1px 6px;
    border-radius: 4px;
    font-family: var(--mono);
    font-size: 0.82em;
    color: var(--accent2);
  }

  .pulse {
    animation: pulse 0.4s ease;
  }

  @keyframes pulse {
    0% { box-shadow: 0 0 0 0 rgba(92,107,192,0.6); }
    100% { box-shadow: 0 0 0 12px rgba(92,107,192,0); }
  }
</style>
</head>
<body>

<header>
  <h1>List Range Extension</h1>
  <p>Custom Scratch 3.0 block — extract & join list items between two indices</p>
  <span class="badge">SCRATCH EXTENSION</span>
</header>

<!-- Block visual -->
<div class="block-preview">
  <h2>Block Shape</h2>
  <div class="scratch-block">
    list items
    <span class="block-arg">FROM</span>
    to
    <span class="block-arg">TO</span>
    of
    <span class="block-arg">LIST NAME</span>
    joined by
    <span class="block-arg">SEPARATOR</span>
  </div>
</div>

<!-- How to use -->
<div class="how-to" style="margin-bottom:32px">
  <h2>How to Load in Scratch</h2>
  <div class="step">
    <div class="step-num">1</div>
    <div>Go to <strong>turbowarp.org/editor</strong> (TurboWarp supports custom extensions)</div>
  </div>
  <div class="step">
    <div class="step-num">2</div>
    <div>Click the puzzle piece icon → <strong>Custom Extension</strong> → load the <code>.js</code> file</div>
  </div>
  <div class="step">
    <div class="step-num">3</div>
    <div>The <strong>List Range</strong> category appears in the block palette</div>
  </div>
  <div class="step">
    <div class="step-num">4</div>
    <div>In the <code>LIST</code> field, type the <strong>exact name</strong> of your Scratch list variable</div>
  </div>
  <div class="step">
    <div class="step-num">5</div>
    <div>In <code>SEPARATOR</code>, type anything: <code>, </code> <code> </code> <code>; </code> <code>: </code> <code> | </code> etc.</div>
  </div>
</div>

<!-- Interactive playground -->
<div class="playground">

  <!-- List editor -->
  <div class="card">
    <h3>🧪 Interactive Preview — Your List</h3>
    <div class="list-editor">
      <input type="text" id="newItem" placeholder="Add item to list…" />
      <button onclick="addItem()">Add</button>
    </div>
    <div class="list-items" id="listItems"></div>
  </div>

  <!-- Controls -->
  <div class="card">
    <h3>⚙️ Block Parameters</h3>
    <div class="controls">
      <div class="control-group">
        <label>FROM (index)</label>
        <input type="number" id="fromNum" value="1" min="1" />
      </div>
      <div class="control-group">
        <label>TO (index)</label>
        <input type="number" id="toNum" value="3" min="1" />
      </div>
    </div>

    <div class="control-group" style="margin-top:16px">
      <label>SEPARATOR — quick picks</label>
      <div class="sep-grid" id="sepGrid">
        <button class="sep-btn active" data-sep=", " onclick="pickSep(this)">, (comma space)</button>
        <button class="sep-btn" data-sep=" " onclick="pickSep(this)">· (space)</button>
        <button class="sep-btn" data-sep="; " onclick="pickSep(this)">; (semicolon)</button>
        <button class="sep-btn" data-sep=": " onclick="pickSep(this)">: (colon)</button>
        <button class="sep-btn" data-sep=" | " onclick="pickSep(this)">| (pipe)</button>
        <button class="sep-btn" data-sep=" → " onclick="pickSep(this)">→ (arrow)</button>
        <button class="sep-btn" data-sep="" onclick="pickSep(this)">(none)</button>
      </div>
      <div class="sep-custom">
        <label>Custom:</label>
        <input type="text" id="customSep" placeholder='e.g. " - "' style="width:120px" oninput="useCustomSep()" />
      </div>
    </div>
  </div>

  <!-- Run -->
  <button class="run-btn" onclick="runBlock()">▶ Run Block</button>

  <!-- Output -->
  <div class="card">
    <h3>📤 Result</h3>
    <div class="output-box" id="outputBox">—</div>
    <div class="output-count" id="outputCount"></div>
  </div>

</div>

<script>
  let items = ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve', 'Frank', 'Grace'];
  let separator = ', ';

  function renderList() {
    const el = document.getElementById('listItems');
    el.innerHTML = items.map((v, i) => `
      <div class="list-item">
        <span class="item-index">${i + 1}</span>
        <span class="item-val">${v}</span>
        <button class="btn-remove" onclick="removeItem(${i})">×</button>
      </div>
    `).join('');
  }

  function addItem() {
    const input = document.getElementById('newItem');
    const val = input.value.trim();
    if (!val) return;
    items.push(val);
    input.value = '';
    renderList();
  }

  document.getElementById('newItem').addEventListener('keydown', e => {
    if (e.key === 'Enter') addItem();
  });

  function removeItem(i) {
    items.splice(i, 1);
    renderList();
  }

  function pickSep(btn) {
    document.querySelectorAll('.sep-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    separator = btn.dataset.sep;
    document.getElementById('customSep').value = '';
  }

  function useCustomSep() {
    document.querySelectorAll('.sep-btn').forEach(b => b.classList.remove('active'));
    separator = document.getElementById('customSep').value;
  }

  function runBlock() {
    const from = parseInt(document.getElementById('fromNum').value) || 1;
    const to   = parseInt(document.getElementById('toNum').value)   || 1;
    const len  = items.length;

    if (len === 0) {
      document.getElementById('outputBox').textContent = '(list is empty)';
      document.getElementById('outputCount').textContent = '';
      return;
    }

    const start = Math.max(1, Math.min(from, len));
    const end   = Math.max(1, Math.min(to, len));

    let slice;
    if (start <= end) {
      slice = items.slice(start - 1, end);
    } else {
      slice = items.slice(end - 1, start).reverse();
    }

    const result = slice.join(separator);
    const out = document.getElementById('outputBox');
    out.textContent = result || '(empty result)';
    out.classList.remove('pulse');
    void out.offsetWidth;
    out.classList.add('pulse');

    const sepDisplay = separator === '' ? '(none)' : `"${separator}"`;
    document.getElementById('outputCount').textContent =
      `${slice.length} item(s) · separator: ${sepDisplay} · indices ${start}–${end}`;
  }

  renderList();
  runBlock();
</script>

</body>
</html>

```


<!-- 68 | Identifying file types by hex signatures | bash -->
```bash
xxd yourfile | head        # hex dump
file yourfile              # uses magic database automatically
hexdump -C yourfile | head
```


<!-- 69 | Identifying file types by hex signatures | python -->
```python
with open("yourfile", "rb") as f:
    header = f.read(16)
print(header.hex(" "))  # e.g. "89 50 4e 47 0d 0a 1a 0a"
```


<!-- 70 | Identifying file types by hex signatures | bash -->
```bash
xxd originalfile > dump.hex      # file → hex dump
xxd -r dump.hex > restored file  # hex dump → file back
```


<!-- 71 | Identifying file types by hex signatures | python -->
```python
hex_string = "89504e470d0a1a0a..."  # your full hex dump (spaces removed)
data = bytes.fromhex(hex_string)

with open("recovered.png", "wb") as f:
    f.write(data)
```


<!-- 72 | Identifying file types by hex signatures | bash -->
```bash
xxd -r -p hexdump.txt recovered.png
```


<!-- 73 | Cookie Run Kingdom guild officer tracker | py -->
```py
import json
import os
from datetime import datetime

DATA_PATH = "/storage/emulated/0/download/guild_data.json"
LEADER = "AndreiSmek"
START_SEASON = 29
START_PART = 1
PARTS_PER_SEASON = 4


def load_data():
    if os.path.exists(DATA_PATH):
        with open(DATA_PATH, "r") as f:
            return json.load(f)
    # Initialize fresh data
    return {
        "members": {},          # { username: { "total_damage": int, "parts_participated": int, "active": bool } }
        "history": [],          # [ { "season": int, "part": int, "damages": { username: int } } ]
        "current_season": START_SEASON,
        "current_part": START_PART,
        "officers": []
    }


def save_data(data):
    os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
    with open(DATA_PATH, "w") as f:
        json.dump(data, f, indent=2)
    print(f"\n✅ Data saved to {DATA_PATH}")


def get_active_members(data):
    return [name for name, info in data["members"].items() if info["active"]]


def print_members(data):
    active = get_active_members(data)
    print(f"\n📋 Current members ({len(active)}):")
    for name in sorted(active):
        role = "👑 Leader" if name == LEADER else "⚔️ Member"
        total = data["members"][name]["total_damage"]
        parts = data["members"][name]["parts_participated"]
        print(f"  {role}  {name}  |  Total DMG: {total:,}  |  Parts played: {parts}")


def handle_membership_changes(data):
    print("\n--- Membership Changes ---")
    while True:
        answer = input("Did any member LEAVE since the last session? (yes/no): ").strip().lower()
        if answer == "yes":
            name = input("  Enter the username who left: ").strip()
            if name == LEADER:
                print("  ❌ You can't remove the leader.")
            elif name in data["members"] and data["members"][name]["active"]:
                data["members"][name]["active"] = False
                print(f"  ✅ {name} marked as inactive.")
            else:
                print(f"  ⚠️ '{name}' not found or already inactive.")
        elif answer == "no":
            break
        else:
            print("  Please answer yes or no.")

    while True:
        answer = input("Did any new member JOIN since the last session? (yes/no): ").strip().lower()
        if answer == "yes":
            name = input("  Enter the new member's username: ").strip()
            if name in data["members"]:
                data["members"][name]["active"] = True
                print(f"  ✅ {name} re-activated.")
            else:
                data["members"][name] = {
                    "total_damage": 0,
                    "parts_participated": 0,
                    "active": True
                }
                print(f"  ✅ {name} added as a new member.")
        elif answer == "no":
            break
        else:
            print("  Please answer yes or no.")


def input_damage(data, season, part):
    active = get_active_members(data)
    print(f"\n--- Damage Input: Season {season} Part {part} ---")
    damages = {}

    for name in sorted(active):
        while True:
            try:
                dmg = input(f"  Damage for {name} (or press Enter to skip/0): ").strip()
                if dmg == "":
                    dmg = 0
                else:
                    dmg = int(dmg)
                damages[name] = dmg
                break
            except ValueError:
                print("  ❌ Please enter a valid number.")

    # Update totals
    for name, dmg in damages.items():
        data["members"][name]["total_damage"] += dmg
        if dmg > 0:
            data["members"][name]["parts_participated"] += 1

    # Save history entry
    data["history"].append({
        "season": season,
        "part": part,
        "timestamp": datetime.now().isoformat(),
        "damages": damages
    })

    print("\n📊 Damage recorded:")
    for name, dmg in sorted(damages.items(), key=lambda x: -x[1]):
        print(f"  {name}: {dmg:,}")

    return damages


def choose_officer(data):
    active = get_active_members(data)
    candidates = {
        name: data["members"][name]["total_damage"]
        for name in active
        if name != LEADER
    }

    if not candidates:
        print("\n⚠️ No candidates for officer (no non-leader members).")
        return

    best = max(candidates, key=candidates.get)
    print(f"\n🏆 OFFICER SUGGESTION: Based on total damage, '{best}' should be officer!")
    print(f"   Total damage: {candidates[best]:,}")

    # Show top 3
    top = sorted(candidates.items(), key=lambda x: -x[1])[:3]
    print("\n  Top 3 damage dealers:")
    for i, (name, dmg) in enumerate(top, 1):
        print(f"    {i}. {name} — {dmg:,}")

    data["officers"] = [best]


def suggest_kicks(data):
    active = get_active_members(data)
    candidates = {
        name: data["members"][name]
        for name in active
        if name != LEADER
    }

    if not candidates:
        print("\n⚠️ No members to evaluate for kicking.")
        return

    print("\n🚨 KICK SUGGESTIONS (Season 30+):")

    # Count how many season 30+ parts have been tracked
    s30_parts = [h for h in data["history"] if h["season"] >= 30]
    total_s30_parts = len(s30_parts)

    if total_s30_parts == 0:
        print("  No Season 30 data yet. Come back after recording at least one Season 30 part.")
        return

    # Calculate average damage per part from S30 onwards
    s30_damage = {}
    for entry in s30_parts:
        for name, dmg in entry["damages"].items():
            if name not in s30_damage:
                s30_damage[name] = {"total": 0, "parts": 0}
            s30_damage[name]["total"] += dmg
            if dmg > 0:
                s30_damage[name]["parts"] += 1

    scores = {}
    for name in candidates:
        d = s30_damage.get(name, {"total": 0, "parts": 0})
        avg = d["total"] / total_s30_parts if total_s30_parts > 0 else 0
        participation = (d["parts"] / total_s30_parts) * 100
        scores[name] = {"avg": avg, "participation": participation, "total": d["total"]}

    # Sort by average damage ascending (lowest = kick candidates)
    sorted_scores = sorted(scores.items(), key=lambda x: x[1]["avg"])

    print(f"  (Based on {total_s30_parts} recorded Season 30+ part(s))\n")
    print("  ⬇️  Lowest performers (consider kicking):")
    for name, s in sorted_scores[:3]:
        print(f"    {name} — Avg DMG/part: {s['avg']:,.0f} | Participation: {s['participation']:.0f}% | S30 Total: {s['total']:,}")

    print("\n  ⬆️  Top performers (keep / promote):")
    for name, s in sorted_scores[-3:][::-1]:
        print(f"    {name} — Avg DMG/part: {s['avg']:,.0f} | Participation: {s['participation']:.0f}% | S30 Total: {s['total']:,}")


def advance_season_part(data):
    season = data["current_season"]
    part = data["current_part"]

    if part < PARTS_PER_SEASON:
        data["current_part"] += 1
    else:
        data["current_season"] += 1
        data["current_part"] = 1

    print(f"\n⏭️  Advanced to Season {data['current_season']} Part {data['current_part']}")


def main():
    print("=" * 50)
    print("  🍪 Cookie Run Kingdom — Guild Damage Tracker")
    print("=" * 50)

    data = load_data()

    # Add leader if not present
    if LEADER not in data["members"]:
        data["members"][LEADER] = {
            "total_damage": 0,
            "parts_participated": 0,
            "active": True
        }

    season = data["current_season"]
    part = data["current_part"]

    print(f"\n📅 Current session: Season {season} Part {part}")
    print_members(data)

    # Ask about membership changes
    handle_membership_changes(data)
    print_members(data)

    # Ask if this part has ended
    while True:
        ended = input(f"\nHas Season {season} Part {part} ended? (yes/no): ").strip().lower()
        if ended == "yes":
            break
        elif ended == "no":
            print("\n⏸️  Part not ended yet. Come back when it's over!")
            save_data(data)
            return
        else:
            print("Please answer yes or no.")

    # Input damage
    input_damage(data, season, part)

    # Officer suggestion (always, except leader)
    choose_officer(data)

    # Kick suggestion only from Season 30 onwards
    if season >= 30 or (season == 29 and part == PARTS_PER_SEASON):
        # After S29 ends, we start suggesting kicks
        completed_seasons = [h for h in data["history"] if h["season"] >= 30]
        if season >= 30:
            suggest_kicks(data)

    # Advance to next part/season
    advance_season_part(data)

    save_data(data)
    print("\n✨ All done! Run the script again for the next part.")
    print("=" * 50)


if __name__ == "__main__":
    main()

```


<!-- 74 | Test energie cinetică și potențială | python -->
```python
<!DOCTYPE html>
<html lang="ro">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Test Energie – Fizică</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0a0e1a;
    --surface: #111827;
    --border: #1e2d45;
    --accent-kin: #00d4ff;
    --accent-grav: #a78bfa;
    --accent-ela: #34d399;
    --text: #e2e8f0;
    --muted: #64748b;
    --correct: #22c55e;
    --wrong: #ef4444;
  }

  * { margin: 0; padding: 0; box-sizing: border-box; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Syne', sans-serif;
    min-height: 100vh;
    overflow-x: hidden;
  }

  /* Animated grid background */
  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background-image:
      linear-gradient(rgba(0,212,255,0.04) 1px, transparent 1px),
      linear-gradient(90deg, rgba(0,212,255,0.04) 1px, transparent 1px);
    background-size: 40px 40px;
    pointer-events: none;
    z-index: 0;
  }

  .container {
    position: relative;
    z-index: 1;
    max-width: 780px;
    margin: 0 auto;
    padding: 2rem 1.2rem 4rem;
  }

  /* Header */
  header {
    text-align: center;
    margin-bottom: 2.5rem;
    animation: fadeDown 0.7s ease both;
  }

  header h1 {
    font-size: clamp(1.8rem, 5vw, 2.8rem);
    font-weight: 800;
    letter-spacing: -1px;
    line-height: 1.1;
    background: linear-gradient(135deg, var(--accent-kin) 0%, var(--accent-grav) 50%, var(--accent-ela) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  .subtitle {
    margin-top: 0.5rem;
    color: var(--muted);
    font-family: 'Space Mono', monospace;
    font-size: 0.78rem;
    letter-spacing: 2px;
    text-transform: uppercase;
  }

  .legend {
    display: flex;
    gap: 1rem;
    justify-content: center;
    margin-top: 1.2rem;
    flex-wrap: wrap;
  }

  .legend span {
    font-size: 0.72rem;
    font-family: 'Space Mono', monospace;
    padding: 3px 10px;
    border-radius: 20px;
    letter-spacing: 1px;
  }

  .tag-kin { background: rgba(0,212,255,0.12); color: var(--accent-kin); border: 1px solid rgba(0,212,255,0.3); }
  .tag-grav { background: rgba(167,139,250,0.12); color: var(--accent-grav); border: 1px solid rgba(167,139,250,0.3); }
  .tag-ela { background: rgba(52,211,153,0.12); color: var(--accent-ela); border: 1px solid rgba(52,211,153,0.3); }

  /* Progress bar */
  .progress-wrap {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    height: 6px;
    margin-bottom: 2rem;
    overflow: hidden;
  }

  .progress-bar {
    height: 100%;
    background: linear-gradient(90deg, var(--accent-kin), var(--accent-grav));
    border-radius: 8px;
    transition: width 0.4s ease;
    width: 0%;
  }

  .progress-label {
    font-family: 'Space Mono', monospace;
    font-size: 0.7rem;
    color: var(--muted);
    text-align: right;
    margin-bottom: 0.4rem;
  }

  /* Question card */
  .question-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 1.8rem;
    margin-bottom: 1.2rem;
    animation: slideIn 0.4s ease both;
    position: relative;
    overflow: hidden;
  }

  .question-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0;
    width: 4px;
    height: 100%;
    border-radius: 4px 0 0 4px;
  }

  .question-card.kin::before { background: var(--accent-kin); }
  .question-card.grav::before { background: var(--accent-grav); }
  .question-card.ela::before { background: var(--accent-ela); }

  .q-meta {
    display: flex;
    align-items: center;
    gap: 0.6rem;
    margin-bottom: 0.9rem;
  }

  .q-num {
    font-family: 'Space Mono', monospace;
    font-size: 0.7rem;
    color: var(--muted);
  }

  .q-tag {
    font-size: 0.65rem;
    font-family: 'Space Mono', monospace;
    padding: 2px 8px;
    border-radius: 20px;
    letter-spacing: 1px;
    text-transform: uppercase;
  }

  .q-text {
    font-size: 1rem;
    line-height: 1.6;
    font-weight: 700;
    color: var(--text);
  }

  .options {
    display: flex;
    flex-direction: column;
    gap: 0.6rem;
    margin-top: 1.1rem;
  }

  .option {
    display: flex;
    align-items: center;
    gap: 0.8rem;
    padding: 0.75rem 1rem;
    border-radius: 10px;
    border: 1px solid var(--border);
    background: rgba(255,255,255,0.02);
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 0.92rem;
    font-weight: 400;
  }

  .option:hover:not(.disabled) {
    border-color: var(--accent-kin);
    background: rgba(0,212,255,0.05);
    transform: translateX(4px);
  }

  .option input[type="radio"] { display: none; }

  .radio-dot {
    width: 16px; height: 16px;
    border-radius: 50%;
    border: 2px solid var(--muted);
    flex-shrink: 0;
    transition: all 0.2s;
    display: flex; align-items: center; justify-content: center;
  }

  .option.selected .radio-dot {
    border-color: var(--accent-kin);
    background: var(--accent-kin);
  }

  .option.selected .radio-dot::after {
    content: '';
    width: 6px; height: 6px;
    border-radius: 50%;
    background: var(--bg);
  }

  .option.correct {
    border-color: var(--correct);
    background: rgba(34,197,94,0.1);
  }

  .option.wrong {
    border-color: var(--wrong);
    background: rgba(239,68,68,0.1);
  }

  .option.disabled { cursor: default; }

  .feedback {
    margin-top: 0.8rem;
    font-size: 0.82rem;
    font-family: 'Space Mono', monospace;
    padding: 0.6rem 0.9rem;
    border-radius: 8px;
    display: none;
    line-height: 1.5;
  }

  .feedback.show { display: block; animation: fadeIn 0.3s ease; }
  .feedback.ok { background: rgba(34,197,94,0.1); color: var(--correct); border: 1px solid rgba(34,197,94,0.25); }
  .feedback.err { background: rgba(239,68,68,0.1); color: var(--wrong); border: 1px solid rgba(239,68,68,0.25); }

  /* Submit */
  .submit-wrap {
    text-align: center;
    margin-top: 2.5rem;
  }

  .btn-submit {
    background: linear-gradient(135deg, var(--accent-kin), var(--accent-grav));
    color: var(--bg);
    border: none;
    padding: 1rem 3rem;
    border-radius: 50px;
    font-family: 'Syne', sans-serif;
    font-size: 1rem;
    font-weight: 800;
    cursor: pointer;
    letter-spacing: 1px;
    transition: transform 0.2s, box-shadow 0.2s;
    box-shadow: 0 0 30px rgba(0,212,255,0.2);
  }

  .btn-submit:hover { transform: scale(1.04); box-shadow: 0 0 40px rgba(0,212,255,0.35); }
  .btn-submit:active { transform: scale(0.98); }

  /* Results */
  .results {
    display: none;
    text-align: center;
    padding: 3rem 1rem;
    animation: fadeIn 0.6s ease;
  }

  .results.show { display: block; }

  .score-circle {
    width: 140px; height: 140px;
    border-radius: 50%;
    margin: 0 auto 1.5rem;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    border: 3px solid var(--accent-grav);
    box-shadow: 0 0 50px rgba(167,139,250,0.3);
    background: var(--surface);
  }

  .score-num {
    font-size: 2.4rem;
    font-weight: 800;
    color: var(--accent-grav);
    line-height: 1;
  }

  .score-sub { font-size: 0.7rem; color: var(--muted); font-family: 'Space Mono', monospace; }

  .score-msg {
    font-size: 1.3rem;
    font-weight: 800;
    margin-bottom: 0.5rem;
  }

  .score-detail {
    color: var(--muted);
    font-family: 'Space Mono', monospace;
    font-size: 0.8rem;
    margin-bottom: 2rem;
  }

  .btn-retry {
    background: transparent;
    color: var(--accent-kin);
    border: 1px solid var(--accent-kin);
    padding: 0.7rem 2rem;
    border-radius: 50px;
    font-family: 'Syne', sans-serif;
    font-size: 0.9rem;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s;
  }

  .btn-retry:hover { background: rgba(0,212,255,0.1); }

  @keyframes fadeDown { from { opacity:0; transform:translateY(-20px); } to { opacity:1; transform:translateY(0); } }
  @keyframes slideIn { from { opacity:0; transform:translateX(-12px); } to { opacity:1; transform:translateX(0); } }
  @keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
</style>
</head>
<body>
<div class="container">
  <header>
    <h1>Test de Fizică</h1>
    <p class="subtitle">Forme de energie mecanică — clasa a VII-a</p>
    <div class="legend">
      <span class="tag-kin">Ec – Cinetică</span>
      <span class="tag-grav">Ep – Gravitațională</span>
      <span class="tag-ela">Eel – Elastică</span>
    </div>
  </header>

  <div id="quiz-section">
    <div class="progress-label" id="progress-label">Întrebarea 0 / 20</div>
    <div class="progress-wrap"><div class="progress-bar" id="progress-bar"></div></div>
    <div id="questions-container"></div>

    <div class="submit-wrap">
      <button class="btn-submit" onclick="submitQuiz()">Verifică răspunsurile</button>
    </div>
  </div>

  <div class="results" id="results">
    <div class="score-circle">
      <div class="score-num" id="score-num">0</div>
      <div class="score-sub">/ 20</div>
    </div>
    <div class="score-msg" id="score-msg"></div>
    <div class="score-detail" id="score-detail"></div>
    <button class="btn-retry" onclick="retryQuiz()">↺ Încearcă din nou</button>
  </div>
</div>

<script>
const questions = [
  // CINETICĂ (7)
  {
    type: 'kin',
    tag: 'Ec – Cinetică',
    text: '1. Formula energiei cinetice a unui corp este:',
    options: ['Ec = mgh', 'Ec = ½mv²', 'Ec = kx²/2', 'Ec = mv'],
    answer: 1,
    explanation: 'Energia cinetică se calculează cu Ec = ½mv², unde m este masa și v este viteza corpului.'
  },
  {
    type: 'kin',
    tag: 'Ec – Cinetică',
    text: '2. Unitatea de măsură a energiei cinetice în SI este:',
    options: ['Newton (N)', 'Watt (W)', 'Joule (J)', 'Pascal (Pa)'],
    answer: 2,
    explanation: 'Energia se măsoară în Joule (J) în Sistemul Internațional.'
  },
  {
    type: 'kin',
    tag: 'Ec – Cinetică',
    text: '3. Un corp cu masa de 2 kg se mișcă cu viteza de 3 m/s. Energia sa cinetică este:',
    options: ['6 J', '9 J', '3 J', '12 J'],
    answer: 1,
    explanation: 'Ec = ½ × 2 × 3² = ½ × 2 × 9 = 9 J'
  },
  {
    type: 'kin',
    tag: 'Ec – Cinetică',
    text: '4. Dacă viteza unui corp se dublează, energia sa cinetică:',
    options: ['Se dublează', 'Rămâne aceeași', 'Se triplează', 'Se înmulțește cu 4'],
    answer: 3,
    explanation: 'Deoarece Ec = ½mv², dacă v devine 2v, atunci Ec devine ½m(2v)² = 4 × ½mv². Ec se înmulțește cu 4.'
  },
  {
    type: 'kin',
    tag: 'Ec – Cinetică',
    text: '5. Energia cinetică a unui corp în repaus este:',
    options: ['Maximă', 'Zero', 'Negativă', 'Egală cu energia potențială'],
    answer: 1,
    explanation: 'Dacă v = 0, atunci Ec = ½m × 0² = 0 J.'
  },
  {
    type: 'kin',
    tag: 'Ec – Cinetică',
    text: '6. Care dintre următorii factori NU influențează energia cinetică?',
    options: ['Masa corpului', 'Viteza corpului', 'Înălțimea corpului față de sol', 'Pătratul vitezei'],
    answer: 2,
    explanation: 'Ec = ½mv² depinde de masă și viteză, nu de înălțime (aceasta influențează energia potențială gravitațională).'
  },
  {
    type: 'kin',
    tag: 'Ec – Cinetică',
    text: '7. O minge de 0,5 kg are energia cinetică de 16 J. Care este viteza ei?',
    options: ['4 m/s', '8 m/s', '6 m/s', '2 m/s'],
    answer: 1,
    explanation: 'Ec = ½mv² → 16 = ½ × 0,5 × v² → v² = 64 → v = 8 m/s'
  },

  // POTENȚIALĂ GRAVITAȚIONALĂ (7)
  {
    type: 'grav',
    tag: 'Ep – Gravitațională',
    text: '8. Formula energiei potențiale gravitaționale este:',
    options: ['Ep = ½mv²', 'Ep = mgh', 'Ep = kx²/2', 'Ep = F × t'],
    answer: 1,
    explanation: 'Energia potențială gravitațională: Ep = mgh, unde m – masă, g – accelerația gravitațională, h – înălțimea.'
  },
  {
    type: 'grav',
    tag: 'Ep – Gravitațională',
    text: '9. Valoarea accelerației gravitaționale pe Pământ folosită la calcule este aproximativ:',
    options: ['5 m/s²', '10 m/s²', '15 m/s²', '20 m/s²'],
    answer: 1,
    explanation: 'g ≈ 10 m/s² (valoarea aproximativă folosită în exerciții de fizică la gimnaziu).'
  },
  {
    type: 'grav',
    tag: 'Ep – Gravitațională',
    text: '10. Un corp cu masa de 3 kg se află la înălțimea de 5 m față de sol. Energia sa potențială gravitațională este:',
    options: ['15 J', '30 J', '150 J', '300 J'],
    answer: 2,
    explanation: 'Ep = mgh = 3 × 10 × 5 = 150 J'
  },
  {
    type: 'grav',
    tag: 'Ep – Gravitațională',
    text: '11. Energia potențială gravitațională a unui corp la nivelul solului (h = 0) este:',
    options: ['Maximă', 'Zero', 'Negativă', 'Egală cu energia cinetică'],
    answer: 1,
    explanation: 'Ep = mg × 0 = 0 J. La nivelul de referință ales, energia potențială gravitațională este zero.'
  },
  {
    type: 'grav',
    tag: 'Ep – Gravitațională',
    text: '12. Dacă înălțimea unui corp față de sol se triplează, energia potențială gravitațională:',
    options: ['Rămâne aceeași', 'Se înmulțește cu 9', 'Se triplează', 'Se înjumătățește'],
    answer: 2,
    explanation: 'Ep = mgh; dacă h devine 3h, atunci Ep devine mg × 3h = 3 × mgh. Energia se triplează.'
  },
  {
    type: 'grav',
    tag: 'Ep – Gravitațională',
    text: '13. Un corp cade liber de la înălțimea h. Pe parcursul căderii, energia potențială gravitațională:',
    options: ['Crește', 'Rămâne constantă', 'Scade', 'Devine negativă'],
    answer: 2,
    explanation: 'Pe măsură ce corpul coboară, h scade, deci Ep = mgh scade. Energia potențială se transformă în energie cinetică.'
  },
  {
    type: 'grav',
    tag: 'Ep – Gravitațională',
    text: '14. Care este masa unui corp care, la înălțimea de 4 m, are energia potențială de 200 J? (g = 10 m/s²)',
    options: ['2 kg', '5 kg', '8 kg', '10 kg'],
    answer: 1,
    explanation: 'Ep = mgh → 200 = m × 10 × 4 → m = 200/40 = 5 kg'
  },

  // ELASTICĂ (6)
  {
    type: 'ela',
    tag: 'Eel – Elastică',
    text: '15. Formula energiei potențiale elastice a unui resort este:',
    options: ['Eel = kx', 'Eel = ½kx²', 'Eel = k/x', 'Eel = kx²'],
    answer: 1,
    explanation: 'Energia potențială elastică: Eel = ½kx², unde k este constanta elastică și x este deformarea.'
  },
  {
    type: 'ela',
    tag: 'Eel – Elastică',
    text: '16. Un resort cu constanta elastică k = 200 N/m este comprimat cu x = 0,1 m. Energia elastică stocată este:',
    options: ['10 J', '1 J', '20 J', '2 J'],
    answer: 1,
    explanation: 'Eel = ½ × 200 × (0,1)² = ½ × 200 × 0,01 = 1 J'
  },
  {
    type: 'ela',
    tag: 'Eel – Elastică',
    text: '17. Energia potențială elastică a unui resort nedeformat (x = 0) este:',
    options: ['Maximă', 'Egală cu k', 'Zero', 'Nedeterminată'],
    answer: 2,
    explanation: 'Eel = ½k × 0² = 0 J. Un resort nedeformat nu stochează energie elastică.'
  },
  {
    type: 'ela',
    tag: 'Eel – Elastică',
    text: '18. Dacă deformarea unui resort se dublează, energia elastică stocată:',
    options: ['Se dublează', 'Se înmulțește cu 4', 'Rămâne aceeași', 'Se înjumătățește'],
    answer: 1,
    explanation: 'Eel = ½kx². Dacă x devine 2x: Eel = ½k(2x)² = 4 × ½kx². Energia se înmulțește cu 4.'
  },
  {
    type: 'ela',
    tag: 'Eel – Elastică',
    text: '19. Ce reprezintă constanta elastică „k" a unui resort?',
    options: [
      'Masa resortului',
      'Deformarea resortului',
      'Rigiditatea resortului – forța necesară pentru a-l deforma cu 1 m',
      'Energia stocată în resort'
    ],
    answer: 2,
    explanation: 'Constanta elastică k (în N/m) caracterizează rigiditatea resortului și reprezintă forța necesară pentru a-l deforma cu 1 metru.'
  },
  {
    type: 'ela',
    tag: 'Eel – Elastică',
    text: '20. Un arc elastic stochează 50 J de energie când este întins cu 0,5 m. Care este constanta sa elastică?',
    options: ['100 N/m', '200 N/m', '400 N/m', '50 N/m'],
    answer: 2,
    explanation: 'Eel = ½kx² → 50 = ½ × k × (0,5)² → 50 = k × 0,125 → k = 400 N/m'
  }
];

let answered = new Array(20).fill(false);

function build() {
  const container = document.getElementById('questions-container');
  container.innerHTML = '';
  answered = new Array(20).fill(false);

  questions.forEach((q, i) => {
    const card = document.createElement('div');
    card.className = `question-card ${q.type}`;
    card.style.animationDelay = `${i * 0.04}s`;

    const optionsHTML = q.options.map((opt, oi) => `
      <label class="option" id="opt-${i}-${oi}" onclick="selectOption(${i}, ${oi})">
        <input type="radio" name="q${i}" value="${oi}">
        <div class="radio-dot"></div>
        <span>${opt}</span>
      </label>
    `).join('');

    card.innerHTML = `
      <div class="q-meta">
        <span class="q-num">Q${i+1}</span>
        <span class="q-tag tag-${q.type}">${q.tag}</span>
      </div>
      <div class="q-text">${q.text}</div>
      <div class="options">${optionsHTML}</div>
      <div class="feedback" id="fb-${i}"></div>
    `;

    container.appendChild(card);
  });

  updateProgress();
}

function selectOption(qIdx, optIdx) {
  if (answered[qIdx]) return;

  // Clear previous selection
  questions[qIdx].options.forEach((_, oi) => {
    document.getElementById(`opt-${qIdx}-${oi}`).classList.remove('selected');
  });

  document.getElementById(`opt-${qIdx}-${optIdx}`).classList.add('selected');

  // Track selection
  questions[qIdx].selected = optIdx;
  answered[qIdx] = true;

  const answered_count = answered.filter(Boolean).length;
  updateProgress(answered_count);
}

function updateProgress(count) {
  const n = count !== undefined ? count : answered.filter(Boolean).length;
  document.getElementById('progress-label').textContent = `Întrebarea ${n} / 20`;
  document.getElementById('progress-bar').style.width = `${(n/20)*100}%`;
}

function submitQuiz() {
  let score = 0;

  questions.forEach((q, i) => {
    const sel = q.selected;
    const fb = document.getElementById(`fb-${i}`);

    questions[i].options.forEach((_, oi) => {
      const el = document.getElementById(`opt-${i}-${oi}`);
      el.classList.add('disabled');
      el.style.pointerEvents = 'none';
    });

    if (sel === undefined) {
      // Not answered
      const correctEl = document.getElementById(`opt-${i}-${q.answer}`);
      correctEl.classList.add('correct');
      fb.textContent = `⚠ Neselectat. Răspuns corect: ${q.options[q.answer]}. ${q.explanation}`;
      fb.className = 'feedback show err';
    } else if (sel === q.answer) {
      score++;
      document.getElementById(`opt-${i}-${sel}`).classList.add('correct');
      fb.textContent = `✓ Corect! ${q.explanation}`;
      fb.className = 'feedback show ok';
    } else {
      document.getElementById(`opt-${i}-${sel}`).classList.add('wrong');
      document.getElementById(`opt-${i}-${q.answer}`).classList.add('correct');
      fb.textContent = `✗ Greșit. Răspuns corect: ${q.options[q.answer]}. ${q.explanation}`;
      fb.className = 'feedback show err';
    }
  });

  // Show results
  document.getElementById('score-num').textContent = score;
  const pct = Math.round((score/20)*100);
  let msg, detail;
  if (score === 20) { msg = '🏆 Perfect! Excelent!'; detail = '100% — Stăpânești materia perfect!'; }
  else if (score >= 17) { msg = '⭐ Foarte bine!'; detail = `${pct}% — Rezultat excelent!`; }
  else if (score >= 14) { msg = '👍 Bine!'; detail = `${pct}% — Mai studiază puțin și vei ajunge la nota 10!`; }
  else if (score >= 10) { msg = '📖 Satisfăcător'; detail = `${pct}% — Mai ai nevoie de puțin studiu.`; }
  else { msg = '💪 Necesită studiu'; detail = `${pct}% — Recitește formulele și încearcă din nou!`; }

  document.getElementById('score-msg').textContent = msg;
  document.getElementById('score-detail').textContent = detail;

  // Scroll to results
  setTimeout(() => {
    document.getElementById('results').classList.add('show');
    document.getElementById('results').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 300);
}

function retryQuiz() {
  document.getElementById('results').classList.remove('show');
  questions.forEach(q => delete q.selected);
  build();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

build();
</script>
</body>
</html>

```


<!-- 75 | Numbers beyond 10^4094 | python -->
```python
mant = float(d / Decimal(10)**exp)
```


<!-- 76 | Numbers beyond 10^4094 | python -->
```python
# line 84 - replace this:
mant = float(d / Decimal(10)**exp)

# with this:
mant = d / Decimal(10)**exp
sci = f"{float(mant):.6g} x 10^{exp}"
```


<!-- 77 | Numbers beyond 10^4094 | python -->
```python
# --- scientific ---
mant_d = d / Decimal(10)**exp          # stays in Decimal, no overflow
sci = f"{float(mant_d):.6g} x 10^{exp}"
```


<!-- 78 | Numbers beyond 10^4094 | python -->
```python
scale = Decimal(10) ** (3*N+3)
coeff = float(d / scale)   # d/scale is also a small mantissa-like number — safe
```


<!-- 79 | Exercițiul 2 și rezultatul non-întreg | txt -->
```txt
x + y = 29
17x + 12y = 490
```


<!-- 80 | Exercițiul 2 și rezultatul non-întreg | txt -->
```txt
17x + 12(29 - x) = 490
17x + 348 - 12x = 490
5x = 490 - 348
5x = 142
x = 142 / 5 = 28,4 ❌
```


<!-- 81 | Exercițiul 2 și rezultatul non-întreg | txt -->
```txt
5x = 488 - 348
5x = 140
x = 28  ✅
y = 29 - 28 = 1
```


<!-- 82 | Exercițiul 2 și rezultatul non-întreg | txt -->
```txt
x + y = 35
17x + 12y = 490
```


<!-- 83 | Exercițiul 2 și rezultatul non-întreg | txt -->
```txt
17x + 12(35 - x) = 490
17x + 420 - 12x = 490
5x = 70
x = 14  ✅
y = 35 - 14 = 21  ✅
```


<!-- 84 | Python code for naming numbers with SI prefixes | bash -->
```bash
# Interactive mode (type numbers one by one)
python number_namer.py

# Single number
python number_namer.py 1e27

# Multiple numbers at once
python number_namer.py 1000 1e9 2097152 9.99e-7
```


<!-- 85 | Python code for naming numbers with SI prefixes | txt -->
```txt
  Input        : 1e27
  Scientific   : 1 × 10^27
  -illion name : 1 octillion
  SI prefix    : 1 R  (Ronna-)
  Binary prefix: 827.181 Yi  (Yobi-)
```


<!-- 86 | Python code for naming numbers with SI prefixes | py -->
```py
"""
number_namer.py
===============
Name any number using standard English -illion names (short scale),
SI / binary prefixes, and a plain English description.

Usage
-----
    python number_namer.py                  # interactive mode
    python number_namer.py 1e27             # single number from CLI
    python number_namer.py 1500000 1e9 2e60 # multiple numbers from CLI
"""

import sys
import math
from decimal import Decimal

# ---------------------------------------------------------------------------
# SI metric prefixes  (symbol, name, exponent of 10)
# ---------------------------------------------------------------------------
SI_PREFIXES = [
    (1e30,  "Q",  "Quetta"),
    (1e27,  "R",  "Ronna"),
    (1e24,  "Y",  "Yotta"),
    (1e21,  "Z",  "Zetta"),
    (1e18,  "E",  "Exa"),
    (1e15,  "P",  "Peta"),
    (1e12,  "T",  "Tera"),
    (1e9,   "G",  "Giga"),
    (1e6,   "M",  "Mega"),
    (1e3,   "k",  "kilo"),
    (1e2,   "h",  "hecto"),
    (1e1,   "da", "deca"),
    (1e-1,  "d",  "deci"),
    (1e-2,  "c",  "centi"),
    (1e-3,  "m",  "milli"),
    (1e-6,  "µ",  "micro"),
    (1e-9,  "n",  "nano"),
    (1e-12, "p",  "pico"),
    (1e-15, "f",  "femto"),
    (1e-18, "a",  "atto"),
    (1e-21, "z",  "zepto"),
    (1e-24, "y",  "yocto"),
    (1e-27, "r",  "ronto"),
    (1e-30, "q",  "quecto"),
]

# ---------------------------------------------------------------------------
# Binary (IEC) prefixes  (value, symbol, name)
# ---------------------------------------------------------------------------
BINARY_PREFIXES = [
    (2**80, "Yi", "Yobi"),
    (2**70, "Zi", "Zebi"),
    (2**60, "Ei", "Exbi"),
    (2**50, "Pi", "Pebi"),
    (2**40, "Ti", "Tebi"),
    (2**30, "Gi", "Gibi"),
    (2**20, "Mi", "Mebi"),
    (2**10, "Ki", "Kibi"),
]

# ---------------------------------------------------------------------------
# Standard -illion names (short scale, N=1…)
# Name for 10^(3N+3)
# ---------------------------------------------------------------------------
_ONES = [
    "", "un", "duo", "tre", "quattuor", "quin", "se", "septen", "octo", "novem"
]
_TENS = [
    "", "dec", "vigint", "trigint", "quadragint", "quinquagint",
    "sexagint", "septuagint", "octogint", "nonagint",
]
_HUNDREDS = [
    "", "cent", "ducent", "trecent", "quadringent", "quingent",
    "sescent", "septingent", "octingent", "nongent",
]

# Hard-coded names for N = 1..9 (Chuquet names)
_NAMED = {
    0:   "thousand",        # 10^3
    1:   "million",         # 10^6
    2:   "billion",         # 10^9
    3:   "trillion",        # 10^12
    4:   "quadrillion",     # 10^15
    5:   "quintillion",     # 10^18
    6:   "sextillion",      # 10^21
    7:   "septillion",      # 10^24
    8:   "octillion",       # 10^27
    9:   "nonillion",       # 10^30
    10:  "decillion",
    11:  "undecillion",
    12:  "duodecillion",
    13:  "tredecillion",
    14:  "quattuordecillion",
    15:  "quindecillion",
    16:  "sexdecillion",
    17:  "septendecillion",
    18:  "octodecillion",
    19:  "novemdecillion",
    20:  "vigintillion",
    100: "centillion",
    1000: "millillion",
}

# Special small names
_SMALL = {
    10:  "ten",
    100: "hundred",
    1_000: "thousand",
    10_000: "myriad",
    1_000_000: "million",
}


def _illion_name(n: int) -> str:
    """
    Return the -illion name for the number 10^(3n+3), n >= 1.
    For n <= 20 and a few specials, uses the standard table.
    For larger n, constructs the Latin-prefix name.
    """
    if n in _NAMED:
        return _NAMED[n]
    if n > 1000:
        return f"10^{3*n+3} (unnamed)"

    # Build Latin prefix for n up to 999
    h = n // 100
    t = (n % 100) // 10
    o = n % 10
    prefix = _HUNDREDS[h] + _TENS[t] + _ONES[o]
    # Clean up double-vowel collisions at joins
    if prefix.endswith("i") and "illion".startswith("i"):
        prefix = prefix[:-1]
    return prefix + "illion"


# ---------------------------------------------------------------------------
# Core naming function
# ---------------------------------------------------------------------------

def name_number(value) -> dict:
    """
    Given a numeric value (int, float, or string), return a dict with:
      - 'input'        : original string
      - 'scientific'   : e.g. "1.50 × 10^6"
      - 'illion_name'  : e.g. "million"
      - 'si_prefix'    : e.g. "1.50 M (Mega)"
      - 'binary_prefix': e.g. "1.43 Mi (Mebi)"  [if applicable]
      - 'description'  : human-readable summary
    """
    original = str(value)
    try:
        num = float(value)
    except (ValueError, TypeError):
        return {"error": f"Cannot parse '{value}' as a number."}

    negative = num < 0
    abs_num = abs(num)
    result = {
        "input": original,
        "negative": negative,
        "abs_value": abs_num,
    }

    # --- Scientific notation ---
    if abs_num == 0:
        result["scientific"] = "0"
        result["illion_name"] = "zero"
        result["si_prefix"] = "0"
        result["binary_prefix"] = None
        result["description"] = "Zero"
        return result

    exp = math.floor(math.log10(abs_num))
    mantissa = abs_num / (10 ** exp)
    result["scientific"] = f"{mantissa:.6g} × 10^{exp}"

    # --- Standard -illion name ---
    # 10^(3N+3) => N = (exp - 3) / 3
    if exp >= 3:
        N = (exp - 3) // 3  # integer part
        illion = _illion_name(N)
        scale = 10 ** (3 * N + 3)
        coeff = abs_num / scale
        result["illion_name"] = f"{coeff:.6g} {illion}"
    elif exp >= 0:
        small_keys = sorted(_SMALL.keys())
        best = 1
        for k in small_keys:
            if abs_num >= k:
                best = k
        result["illion_name"] = f"{abs_num/best:.6g} {_SMALL.get(best, '')}"
    else:
        result["illion_name"] = None  # sub-one

    # --- SI prefix ---
    si_str = None
    for threshold, symbol, name in SI_PREFIXES:
        if abs_num >= threshold * 0.999:
            si_val = abs_num / threshold
            si_str = f"{si_val:.6g} {symbol}  ({name}-)"
            break
    result["si_prefix"] = si_str or f"{abs_num:.6g} (no SI prefix)"

    # --- Binary prefix (only if integer-like and >= 1024) ---
    bin_str = None
    if abs_num >= 1024 and abs_num == int(abs_num):
        for threshold, symbol, name in BINARY_PREFIXES:
            if abs_num >= threshold:
                bin_val = abs_num / threshold
                bin_str = f"{bin_val:.6g} {symbol}i  ({name}-)"
                break
    result["binary_prefix"] = bin_str

    # --- Human description ---
    sign = "negative " if negative else ""
    parts = [f"{sign}{result['scientific']}"]
    if result["illion_name"]:
        parts.append(f"≈ {sign}{result['illion_name']}")
    parts.append(f"SI: {sign}{result['si_prefix']}")
    if bin_str:
        parts.append(f"Binary: {sign}{bin_str}")
    result["description"] = " | ".join(parts)

    return result


# ---------------------------------------------------------------------------
# Pretty printer
# ---------------------------------------------------------------------------

def print_result(r: dict) -> None:
    if "error" in r:
        print(f"  ✗  {r['error']}")
        return
    sign = "−" if r["negative"] else ""
    print(f"  Input        : {r['input']}")
    print(f"  Scientific   : {sign}{r['scientific']}")
    if r.get("illion_name"):
        print(f"  -illion name : {sign}{r['illion_name']}")
    print(f"  SI prefix    : {sign}{r['si_prefix']}")
    if r.get("binary_prefix"):
        print(f"  Binary prefix: {sign}{r['binary_prefix']}")


# ---------------------------------------------------------------------------
# Demos shown at startup
# ---------------------------------------------------------------------------

DEMO_VALUES = [
    1, 10, 100, 1_000, 1_000_000, 1e9, 1e12, 1e15, 1e18, 1e21,
    1e24, 1e27, 1e30, 1e33, 1e63, 1e303,
    1024, 2**20, 2**30, 2**40, 2**50, 2**60,
    1500, 2.5e6, 9.99e-7,
]

BANNER = r"""
╔══════════════════════════════════════════════════════╗
║         N U M B E R   N A M E R                      ║
║  SI prefixes · -illion names · Binary (IEC) prefixes ║
╚══════════════════════════════════════════════════════╝
"""


def run_demo() -> None:
    print(BANNER)
    print("=" * 58)
    print("  DEMO — standard reference values")
    print("=" * 58)
    for v in DEMO_VALUES:
        print()
        print_result(name_number(v))
    print()


def interactive_mode() -> None:
    print(BANNER)
    print("Type a number and press Enter.  Type 'quit' to exit.\n")
    while True:
        try:
            raw = input("Number > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break
        if not raw:
            continue
        if raw.lower() in ("quit", "exit", "q"):
            print("Goodbye!")
            break
        print()
        print_result(name_number(raw))
        print()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    args = sys.argv[1:]
    if args:
        print(BANNER)
        for arg in args:
            print()
            print_result(name_number(arg))
        print()
    else:
        # No arguments: show demo then enter interactive mode
        run_demo()
        interactive_mode()

```


<!-- 87 | Python code for naming numbers with SI prefixes | txt -->
```txt
Scientific   : 1.35294 × 10^2000
-illion name : 135.294 sescentsexagintquinillion
SI prefix    : (>9.01e+15) Q  (Quetta-)
Binary prefix: >9.0072e+15 Yi  (Yobi-)
```


<!-- 88 | Python code for naming numbers with SI prefixes | py -->
```py
"""
number_namer.py
===============
Name any number using standard English -illion names (short scale),
SI / binary prefixes, and a plain English description.

Supports arbitrarily large integers (no OverflowError).

Usage
-----
    python number_namer.py                  # interactive mode
    python number_namer.py 1e27             # single number from CLI
    python number_namer.py 1500000 1e9 2e60 # multiple numbers from CLI
"""

import sys
import math
from decimal import Decimal, getcontext, InvalidOperation

# Enough precision for very large numbers typed as integers
getcontext().prec = 50

# ---------------------------------------------------------------------------
# SI metric prefixes  (exponent of 10, symbol, full name)
# ---------------------------------------------------------------------------
SI_PREFIXES = [
    (30,  "Q",  "Quetta"),
    (27,  "R",  "Ronna"),
    (24,  "Y",  "Yotta"),
    (21,  "Z",  "Zetta"),
    (18,  "E",  "Exa"),
    (15,  "P",  "Peta"),
    (12,  "T",  "Tera"),
    (9,   "G",  "Giga"),
    (6,   "M",  "Mega"),
    (3,   "k",  "kilo"),
    (2,   "h",  "hecto"),
    (1,   "da", "deca"),
    (-1,  "d",  "deci"),
    (-2,  "c",  "centi"),
    (-3,  "m",  "milli"),
    (-6,  "µ",  "micro"),
    (-9,  "n",  "nano"),
    (-12, "p",  "pico"),
    (-15, "f",  "femto"),
    (-18, "a",  "atto"),
    (-21, "z",  "zepto"),
    (-24, "y",  "yocto"),
    (-27, "r",  "ronto"),
    (-30, "q",  "quecto"),
]

# ---------------------------------------------------------------------------
# Binary (IEC) prefixes  (bit-shift, symbol, name)
# ---------------------------------------------------------------------------
BINARY_PREFIXES = [
    (80, "Yi", "Yobi"),
    (70, "Zi", "Zebi"),
    (60, "Ei", "Exbi"),
    (50, "Pi", "Pebi"),
    (40, "Ti", "Tebi"),
    (30, "Gi", "Gibi"),
    (20, "Mi", "Mebi"),
    (10, "Ki", "Kibi"),
]

# ---------------------------------------------------------------------------
# Standard -illion names (short scale)   10^(3N+3)
# ---------------------------------------------------------------------------
_ONES = [
    "", "un", "duo", "tre", "quattuor", "quin", "se", "septen", "octo", "novem"
]
_TENS = [
    "", "dec", "vigint", "trigint", "quadragint", "quinquagint",
    "sexagint", "septuagint", "octogint", "nonagint",
]
_HUNDREDS = [
    "", "cent", "ducent", "trecent", "quadringent", "quingent",
    "sescent", "septingent", "octingent", "nongent",
]

_NAMED = {
    0:    "thousand",
    1:    "million",
    2:    "billion",
    3:    "trillion",
    4:    "quadrillion",
    5:    "quintillion",
    6:    "sextillion",
    7:    "septillion",
    8:    "octillion",
    9:    "nonillion",
    10:   "decillion",
    11:   "undecillion",
    12:   "duodecillion",
    13:   "tredecillion",
    14:   "quattuordecillion",
    15:   "quindecillion",
    16:   "sexdecillion",
    17:   "septendecillion",
    18:   "octodecillion",
    19:   "novemdecillion",
    20:   "vigintillion",
    100:  "centillion",
    1000: "millillion",
}

_SMALL = {
    10:        "ten",
    100:       "hundred",
    1_000:     "thousand",
    10_000:    "myriad",
    1_000_000: "million",
}


def _illion_name(n: int) -> str:
    """Name for 10^(3n+3)."""
    if n in _NAMED:
        return _NAMED[n]
    if n > 1_000_000:
        return f"(10^{3*n+3})"
    h, rem = divmod(n, 100)
    t, o = divmod(rem, 10)
    h = min(h, len(_HUNDREDS) - 1)
    t = min(t, len(_TENS) - 1)
    o = min(o, len(_ONES) - 1)
    prefix = _HUNDREDS[h] + _TENS[t] + _ONES[o]
    if prefix.endswith("i"):
        prefix = prefix[:-1]
    return prefix + "illion"


# ---------------------------------------------------------------------------
# Parse input → (Decimal, is_negative, num_digits_if_integer)
# ---------------------------------------------------------------------------

def _parse(raw: str):
    """
    Return (Decimal_abs_value, is_negative) or raise ValueError.
    Handles plain integers of any length, floats, and scientific notation.
    """
    raw = raw.strip().replace(",", "").replace("_", "")
    negative = raw.startswith("-")
    if negative:
        raw = raw[1:]
    d = Decimal(raw)          # raises InvalidOperation if unparseable
    if d < 0:                 # handle "- -3" edge case
        negative = not negative
        d = -d
    return d, negative


# ---------------------------------------------------------------------------
# Core naming function
# ---------------------------------------------------------------------------

def name_number(value) -> dict:
    """
    Given any number (int, float, Decimal, or string of any size),
    return a dict describing it with -illion name, SI prefix, and binary prefix.
    """
    original = str(value)
    try:
        abs_d, negative = _parse(original)
    except (InvalidOperation, ValueError):
        return {"error": f"Cannot parse '{original}' as a number."}

    result = {"input": original, "negative": negative}

    # ---- Zero ----
    if abs_d == 0:
        result.update(scientific="0", illion_name="zero",
                      si_prefix="0", binary_prefix=None)
        return result

    # ---- Exponent (base-10) ----
    # Use math.log10 on float approximation just to get the exponent integer;
    # all heavy arithmetic stays in Python int / Decimal.
    try:
        float_approx = float(abs_d)
        if math.isinf(float_approx):
            raise OverflowError
        exp = math.floor(math.log10(float_approx))
    except OverflowError:
        # Number is too big for float — count decimal digits of the integer part
        s = str(abs_d).split(".")[0].lstrip("0") or "0"
        exp = len(s) - 1

    # ---- Scientific notation ----
    pow10 = Decimal(10) ** exp
    mantissa = abs_d / pow10
    result["scientific"] = f"{float(mantissa):.6g} × 10^{exp}"

    # ---- -illion name ----
    if exp >= 3:
        N = (exp - 3) // 3
        illion = _illion_name(N)
        scale = Decimal(10) ** (3 * N + 3)
        coeff = float(abs_d / scale)
        result["illion_name"] = f"{coeff:.6g} {illion}"
    elif exp >= 0:
        best_key, best_val = 1, ""
        for k, v in _SMALL.items():
            if abs_d >= k:
                best_key, best_val = k, v
        result["illion_name"] = f"{float(abs_d / best_key):.6g} {best_val}".strip()
    else:
        result["illion_name"] = None

    # ---- SI prefix ----
    si_str = None
    for si_exp, symbol, name in SI_PREFIXES:
        threshold = Decimal(10) ** si_exp
        if abs_d >= threshold * Decimal("0.9999"):
            si_val = float(abs_d / threshold)
            si_str = f"{si_val:.6g} {symbol}  ({name}-)"
            break
    result["si_prefix"] = si_str or f"{float(abs_d):.6g} (no SI prefix)"

    # ---- Binary prefix (integer-like values only) ----
    bin_str = None
    # Check if integer (no fractional part)
    if abs_d == abs_d.to_integral_value() and abs_d >= 1024:
        abs_int = int(abs_d)
        for bits, symbol, name in BINARY_PREFIXES:
            threshold = 1 << bits
            if abs_int >= threshold:
                bin_val = abs_int / threshold   # plain Python float division
                bin_str = f"{bin_val:.6g} {symbol}  ({name}-)"
                break
    result["binary_prefix"] = bin_str

    return result


# ---------------------------------------------------------------------------
# Pretty printer
# ---------------------------------------------------------------------------

def print_result(r: dict) -> None:
    if "error" in r:
        print(f"  ✗  {r['error']}")
        return
    sign = "−" if r["negative"] else ""
    print(f"  Input        : {r['input']}")
    print(f"  Scientific   : {sign}{r['scientific']}")
    if r.get("illion_name"):
        print(f"  -illion name : {sign}{r['illion_name']}")
    print(f"  SI prefix    : {sign}{r['si_prefix']}")
    if r.get("binary_prefix"):
        print(f"  Binary prefix: {sign}{r['binary_prefix']}")


# ---------------------------------------------------------------------------
# Demo values
# ---------------------------------------------------------------------------

DEMO_VALUES = [
    "1", "10", "100", "1000", "1000000", "1e9", "1e12", "1e15",
    "1e18", "1e21", "1e24", "1e27", "1e30", "1e33", "1e63", "1e303",
    "1024", str(2**20), str(2**30), str(2**40), str(2**60),
    "1500", "2500000", "9.99e-7", "-5e18",
    # The giant integer from the bug report (first 30 digits shown here as a sample)
    "135293998974450669831097447094008241625229803915065243997108453987412246648154249379985562142243444811233696124088346544538005729520610159132349504800664129850686366510504673653556594817440697196820990532678455074539743470901039799951540310054578318165695258394453716009938076825925956706110946131836496405052970629865060314448410450926853664778064743913582433176682489684329978596741053991265777275550231439364289153408800458999804874414751593730422609508749879359062955389798814326689448714697866121701415912539169276125898332506337025206505537572785682452483328983977926616957471251009381561501883485995242901197637704972834773323458218964136085074860820564925140103945902839915625199678745975765121847726077624171696203950175882442696635730532164956907169030135670802173589899667459535057805410603700033371185504829332383433991152571325063148251599563848952131020423262066937760951945171538882879118743698545434594801427929622460351469550349591641862161895697819668448277796324125628777673894249937335434419681666816809614129505108681176155300817113498660462210895442192494321936192592010313872338491325904309169345454635583887744120176991014702013877043318614084929811782335302045478417380098263831501548609785140900962363308981988798263321094844738107113144116333568717422035791419792206557689557469134595098750998089748896612051946243880865899361678278662794711054665713976127938794717527954576692993069356724141180029714470822435711712056652760403322294814164047003260000708763035762759705336536530811632489041985287173120419771015162483144309121073074336357881674278662019967556301422456258564829877599459549594053967633555304647362542300484720974228061599879550052963772704847473269129091549195053342420361746765110085888818755696685698554347168649063390864316322182768471332757002528174899200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
]

BANNER = r"""
╔══════════════════════════════════════════════════════╗
║         N U M B E R   N A M E R                      ║
║  SI prefixes · -illion names · Binary (IEC) prefixes ║
╚══════════════════════════════════════════════════════╝
"""


def run_demo() -> None:
    print(BANNER)
    print("=" * 58)
    print("  DEMO — standard reference values")
    print("=" * 58)
    for v in DEMO_VALUES:
        print()
        print_result(name_number(v))
    print()


def interactive_mode() -> None:
    print(BANNER)
    print("Type a number and press Enter.  Type 'quit' to exit.\n")
    while True:
        try:
            raw = input("Number > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break
        if not raw:
            continue
        if raw.lower() in ("quit", "exit", "q"):
            print("Goodbye!")
            break
        print()
        print_result(name_number(raw))
        print()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    args = sys.argv[1:]
    if args:
        print(BANNER)
        for arg in args:
            print()
            print_result(name_number(arg))
        print()
    else:
        run_demo()
        interactive_mode()

```


<!-- 89 | Python code for naming numbers with SI prefixes | python -->
```python
# DELETE these lines:
_BIG_INT = (
    "13529399897445066983..."
    ...
)

# And in DEMO_VALUES, remove the last line:
    _BIG_INT,   # <-- delete this line
```


<!-- 90 | Python code for naming numbers with SI prefixes | python -->
```python
bin_val = abs_int / threshold   # float division
```


<!-- 91 | Python code for naming numbers with SI prefixes | python -->
```python
whole = abs_int >> bits
remainder = abs_int - (whole << bits)
frac = remainder / threshold
bin_val = float(whole) + frac
```


<!-- 92 | Roblox game stats checker script | bash -->
```bash
pip install requests
python roblox_stats.py
```


<!-- 93 | Roblox game stats checker script | py -->
```py
"""
Roblox Game Stats Checker
Fetches public stats for a Roblox game using the Roblox API.
"""

import requests

# ── Config ────────────────────────────────────────────────────────────────────
PLACE_ID = 4943297844          # from the URL
UNIVERSE_API = "https://games.roblox.com/v1/games"
THUMBNAIL_API = "https://thumbnails.roblox.com/v1/games/icons"
# ─────────────────────────────────────────────────────────────────────────────


def get_universe_id(place_id: int) -> int | None:
    """Convert a Place ID to its Universe ID."""
    url = f"https://apis.roblox.com/universes/v1/places/{place_id}/universe"
    r = requests.get(url, timeout=10)
    if r.status_code == 200:
        return r.json().get("universeId")
    print(f"[!] Could not resolve Universe ID (status {r.status_code})")
    return None


def get_game_stats(universe_id: int) -> dict | None:
    """Fetch game details from the Roblox Games API."""
    r = requests.get(UNIVERSE_API, params={"universeIds": universe_id}, timeout=10)
    if r.status_code == 200:
        data = r.json().get("data", [])
        return data[0] if data else None
    print(f"[!] Could not fetch game stats (status {r.status_code})")
    return None


def get_active_servers(universe_id: int) -> dict | None:
    """Fetch active server / player counts."""
    url = f"https://games.roblox.com/v1/games/{universe_id}/servers/Public"
    r = requests.get(url, params={"limit": 10}, timeout=10)
    if r.status_code == 200:
        return r.json()
    return None


def format_number(n: int) -> str:
    """Pretty-format large numbers (e.g. 1234567 → 1,234,567)."""
    return f"{n:,}"


def print_stats(place_id: int) -> None:
    print("\n🎮 Roblox Game Stats Checker")
    print("=" * 40)

    # Step 1 – resolve universe ID
    universe_id = get_universe_id(place_id)
    if not universe_id:
        return
    print(f"Place ID   : {place_id}")
    print(f"Universe ID: {universe_id}")

    # Step 2 – game details
    game = get_game_stats(universe_id)
    if not game:
        print("[!] No game data returned.")
        return

    print("\n📋 Game Info")
    print("-" * 40)
    print(f"  Name        : {game.get('name', 'N/A')}")
    print(f"  Description : {(game.get('description') or 'N/A')[:80]}")
    print(f"  Creator     : {game.get('creator', {}).get('name', 'N/A')}")
    print(f"  Genre       : {game.get('genre', 'N/A')}")
    print(f"  Max players : {game.get('maxPlayers', 'N/A')}")

    print("\n📊 Engagement Stats")
    print("-" * 40)
    visits      = game.get("visits", 0)
    playing     = game.get("playing", 0)
    favourites  = game.get("favoritedCount", 0)
    likes       = game.get("likeCount", 0)
    dislikes    = game.get("dislikeCount", 0)
    total_votes = likes + dislikes
    ratio       = f"{likes / total_votes * 100:.1f}%" if total_votes else "N/A"

    print(f"  Total visits   : {format_number(visits)}")
    print(f"  Currently playing: {format_number(playing)}")
    print(f"  Favourites     : {format_number(favourites)}")
    print(f"  👍 Likes       : {format_number(likes)}")
    print(f"  👎 Dislikes    : {format_number(dislikes)}")
    print(f"  Like ratio     : {ratio}")

    # Step 3 – live server info
    servers_data = get_active_servers(universe_id)
    if servers_data:
        servers = servers_data.get("data", [])
        print(f"\n🖥️  Live Servers: {len(servers)} public server(s) listed")
        for i, s in enumerate(servers[:5], 1):
            players  = s.get("playing", 0)
            capacity = s.get("maxPlayers", "?")
            ping     = s.get("ping", "?")
            fps      = s.get("fps", "?")
            print(f"  Server {i}: {players}/{capacity} players | ping {ping} ms | {fps} FPS")
    else:
        print("\n🖥️  No public server data available (game may be offline).")

    print("\n" + "=" * 40)
    print("✅ Done!")


if __name__ == "__main__":
    print_stats(PLACE_ID)

```


<!-- 94 | Python script for club search | bash -->
```bash
python search_clubs.py --token YOUR_TOKEN_HERE
```


<!-- 95 | Python script for club search | bash -->
```bash
python search_clubs.py --token YOUR_TOKEN_HERE --query "friendly"
```


<!-- 96 | Python script for club search | py -->
```py
"""
Brawl Stars Club Finder
-----------------------
Searches for clubs that are:
  - Open (anyone can join)
  - Family friendly
  - Require <= 50,000 trophies

Usage:
  1. Get your API token from https://developer.brawlstars.com
  2. Run: python search_clubs.py --token YOUR_TOKEN_HERE
     Or set the env variable: BS_API_TOKEN=your_token python search_clubs.py
"""

import argparse
import os
import sys
import time

try:
    import requests
except ImportError:
    print("Missing dependency. Run: pip install requests")
    sys.exit(1)

BASE_URL = "https://api.brawlstars.com/v1"

# ── Filters ────────────────────────────────────────────────────────────────────
MY_TROPHIES        = 50_000
REQUIRED_TYPE      = "open"          # open | inviteOnly | closed
REQUIRED_BADGE     = "family"        # clubs with "family" badge / badge name containing this
MAX_TROPHY_REQ     = MY_TROPHIES     # club's required trophies must be ≤ this
# ──────────────────────────────────────────────────────────────────────────────


def get_headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def search_clubs(token: str, name_query: str = "", limit: int = 200) -> list:
    """Fetch clubs from the API with optional name filter."""
    params = {"limit": min(limit, 200)}
    if name_query:
        params["name"] = name_query

    url = f"{BASE_URL}/clubs"
    resp = requests.get(url, headers=get_headers(token), params=params, timeout=10)

    if resp.status_code == 403:
        print("❌  Access denied. Check your API token and allowed IPs.")
        sys.exit(1)
    if resp.status_code != 200:
        print(f"❌  API error {resp.status_code}: {resp.text}")
        sys.exit(1)

    return resp.json().get("items", [])


def get_club_detail(token: str, club_tag: str) -> dict | None:
    """Fetch full club details by tag."""
    encoded_tag = club_tag.replace("#", "%23")
    url = f"{BASE_URL}/clubs/{encoded_tag}"
    resp = requests.get(url, headers=get_headers(token), timeout=10)
    if resp.status_code == 200:
        return resp.json()
    return None


def is_family_friendly(club: dict) -> bool:
    """Return True if the club badge or description signals family-friendly."""
    badge = (club.get("badgeId") or "")
    name  = (club.get("name") or "").lower()
    desc  = (club.get("description") or "").lower()

    family_keywords = ["family", "friendly", "fun", "casual", "kids", "safe", "clean"]
    return any(kw in desc or kw in name for kw in family_keywords)


def passes_filters(club: dict) -> bool:
    """Apply all search filters to a club dict."""
    # Must be open
    if club.get("type", "").lower() != REQUIRED_TYPE:
        return False

    # Trophy requirement must not exceed our trophies
    trophy_req = club.get("requiredTrophies", 0)
    if trophy_req > MAX_TROPHY_REQ:
        return False

    # Family-friendly check
    if not is_family_friendly(club):
        return False

    return True


def format_club(club: dict) -> str:
    tag        = club.get("tag", "N/A")
    name       = club.get("name", "Unknown")
    members    = club.get("members", [])
    member_cnt = len(members) if isinstance(members, list) else club.get("memberCount", "?")
    trophies   = club.get("trophies", "?")
    req        = club.get("requiredTrophies", 0)
    desc       = (club.get("description") or "—")[:80]

    return (
        f"  🏆 {name} [{tag}]\n"
        f"     Members : {member_cnt}/30\n"
        f"     Trophies: {trophies:,} club | {req:,} required to join\n"
        f"     Desc    : {desc}\n"
    )


def main():
    parser = argparse.ArgumentParser(description="Brawl Stars Open & Family-Friendly Club Finder")
    parser.add_argument("--token", default=os.getenv("BS_API_TOKEN"), help="Brawl Stars API token")
    parser.add_argument("--query", default="", help="Optional club name keyword to search for")
    parser.add_argument("--limit", type=int, default=200, help="How many clubs to fetch (max 200)")
    parser.add_argument("--details", action="store_true", help="Fetch full details for each match (slower)")
    args = parser.parse_args()

    if not args.token:
        print("❌  No API token provided.\n"
              "    Use --token YOUR_TOKEN or set BS_API_TOKEN environment variable.\n"
              "    Get a token at: https://developer.brawlstars.com")
        sys.exit(1)

    print(f"\n🔍 Searching Brawl Stars clubs...")
    print(f"   Trophy requirement : ≤ {MAX_TROPHY_REQ:,}")
    print(f"   Club type          : {REQUIRED_TYPE}")
    print(f"   Filter             : family-friendly keywords\n")

    clubs = search_clubs(args.token, name_query=args.query, limit=args.limit)
    print(f"   Fetched {len(clubs)} clubs from API.\n")

    matches = []
    for club in clubs:
        if args.details:
            detail = get_club_detail(args.token, club["tag"])
            if detail:
                club = detail
            time.sleep(0.05)  # be polite to the API

        if passes_filters(club):
            matches.append(club)

    if not matches:
        print("😕  No clubs matched your filters. Try broadening the search or use --query with different keywords.")
        return

    print(f"✅  Found {len(matches)} matching club(s):\n")
    for club in matches:
        print(format_club(club))

    print(f"\nTip: Copy a tag and visit https://brawlify.com/stats/club/ to view the full club page.")


if __name__ == "__main__":
    main()

```


<!-- 97 | Python script to extract blocks from .mca files | txt -->
```txt
pip install anvil-parser
python read_mca.py                   # scans current directory
python read_mca.py /path/to/region   # or a specific folder
```


<!-- 98 | Python script to extract blocks from .mca files | py -->
```py
"""
read_mca.py — Scan for .mca files and list every block inside them.

Requirements:
    pip install anvil-parser

Usage:
    python read_mca.py                  # searches current directory
    python read_mca.py /path/to/region  # searches a specific directory
"""

import sys
import os
import glob

try:
    import anvil
except ImportError:
    sys.exit(
        "Missing dependency. Install it with:\n"
        "    pip install anvil-parser\n"
    )


def find_mca_files(search_dir: str) -> list[str]:
    """Recursively find all .mca files under search_dir."""
    pattern = os.path.join(search_dir, "**", "*.mca")
    return sorted(glob.glob(pattern, recursive=True))


def iter_blocks(region: anvil.Region):
    """
    Yield (chunk_x, chunk_z, x, y, z, block_name) for every non-air block
    in every chunk of the region.

    Minecraft regions contain up to 32×32 chunks.
    Each chunk spans 16×16 blocks in XZ and up to 384 blocks in Y
    (Y = -64 to 319 for 1.18+; older worlds use 0–255).
    """
    for chunk_x in range(32):
        for chunk_z in range(32):
            try:
                chunk = region.get_chunk(chunk_x, chunk_z)
            except Exception:
                # Chunk not generated yet — skip silently
                continue

            # Detect Y range from the chunk's section data
            try:
                sections = chunk.data["Level"]["Sections"].value  # 1.17-
            except (KeyError, AttributeError):
                try:
                    sections = chunk.data["sections"].value        # 1.18+
                except (KeyError, AttributeError):
                    sections = []

            if not sections:
                continue

            # Determine Y bounds from section Y-indices
            y_indices = []
            for section in sections:
                try:
                    y_indices.append(section["Y"].value)
                except (KeyError, AttributeError):
                    pass

            if not y_indices:
                continue

            y_min = min(y_indices) * 16
            y_max = (max(y_indices) + 1) * 16

            for y in range(y_min, y_max):
                for z in range(16):
                    for x in range(16):
                        try:
                            block = chunk.get_block(x, y, z)
                            if block is None:
                                continue
                            name = block.id          # e.g. "minecraft:stone"
                            if name in (None, "minecraft:air",
                                        "minecraft:cave_air",
                                        "minecraft:void_air"):
                                continue
                            yield chunk_x, chunk_z, x, y, z, name
                        except Exception:
                            # Malformed block data — skip
                            continue


def process_file(mca_path: str) -> None:
    print(f"\n{'='*60}")
    print(f"File: {mca_path}")
    print(f"{'='*60}")

    try:
        region = anvil.Region.from_file(mca_path)
    except Exception as e:
        print(f"  ERROR opening file: {e}")
        return

    block_count = 0
    type_counts: dict[str, int] = {}

    for chunk_x, chunk_z, x, y, z, name in iter_blocks(region):
        block_count += 1
        type_counts[name] = type_counts.get(name, 0) + 1

        # Print individual block entries (can be millions — cap at 10 000)
        if block_count <= 10_000:
            print(f"  chunk({chunk_x:2d},{chunk_z:2d})  "
                  f"pos({x:2d},{y:4d},{z:2d})  {name}")

    if block_count > 10_000:
        print(f"\n  ... output truncated after 10 000 blocks ...")

    print(f"\n  --- Summary ---")
    print(f"  Total non-air blocks : {block_count:,}")
    print(f"  Unique block types   : {len(type_counts):,}")
    if type_counts:
        print("  Top 20 block types:")
        for name, count in sorted(type_counts.items(),
                                  key=lambda kv: kv[1], reverse=True)[:20]:
            print(f"    {count:>10,}  {name}")


def main() -> None:
    search_dir = sys.argv[1] if len(sys.argv) > 1 else "."
    search_dir = os.path.abspath(search_dir)

    print(f"Searching for .mca files in: {search_dir}")
    files = find_mca_files(search_dir)

    if not files:
        print("No .mca files found.")
        return

    print(f"Found {len(files)} .mca file(s).")
    for path in files:
        process_file(path)

    print("\nDone.")


if __name__ == "__main__":
    main()

```


<!-- 99 | Python script to extract blocks from .mca files | txt -->
```txt
pip install nbt
python read_mca_raw.py "/storage/emulated/0/Download/New Folder/Minecraft unknown world"
```


<!-- 100 | Python script to extract blocks from .mca files | py -->
```py
"""
read_mca_raw.py — Parse .mca files directly from binary (no anvil-parser).
Works with Java Edition region files (both old and modern formats).

Requirements:
    pip install nbt

Usage:
    python read_mca_raw.py                   # searches current directory
    python read_mca_raw.py /path/to/region   # specific folder
    python read_mca_raw.py file.mca          # single file
"""

import sys
import os
import glob
import struct
import zlib
import gzip
import io

try:
    import nbt
    from nbt import nbt as nbtlib
except ImportError:
    sys.exit("Missing dependency. Install it with:\n    pip install nbt\n")


# ──────────────────────────────────────────────
# Region file reader (raw binary, no anvil-parser)
# ──────────────────────────────────────────────

SECTOR = 4096  # bytes per sector in .mca files

def read_chunk_nbt(data: bytes):
    """Decompress and parse NBT from raw chunk bytes."""
    if len(data) < 5:
        return None
    length = struct.unpack(">I", data[0:4])[0]
    compression = data[4]
    payload = data[5:5 + length - 1]

    if compression == 2:          # zlib (most common)
        raw = zlib.decompress(payload)
    elif compression == 1:        # gzip
        raw = gzip.decompress(payload)
    elif compression == 3:        # uncompressed
        raw = payload
    else:
        return None               # unknown compression

    return nbtlib.NBTFile(buffer=io.BytesIO(raw))


def get_block_from_section_116_plus(section, x, y_in_section, z):
    """
    Read a block from a 1.16+ palette-based section.
    Returns block name string or None.
    """
    try:
        palette = section["block_states"]["palette"]
    except KeyError:
        try:
            palette = section["Palette"]
        except KeyError:
            return None

    if len(palette) == 0:
        return None

    if len(palette) == 1:
        # Only one block type — no bit-packed array needed
        block = palette[0]
        name = str(block["Name"])
        return name

    # Read the packed long array
    try:
        states = section["block_states"]["data"]
    except KeyError:
        try:
            states = section["BlockStates"]
        except KeyError:
            return None

    palette_size = len(palette)
    bits = max(4, (palette_size - 1).bit_length())

    # Block index within section (0–4095)
    block_index = (y_in_section * 16 + z) * 16 + x

    # Two packing formats: pre-1.16 (values span longs) and 1.16+ (values don't)
    values_per_long = 64 // bits

    long_index = block_index // values_per_long
    bit_offset = (block_index % values_per_long) * bits

    if long_index >= len(states):
        return None

    long_val = states[long_index].value
    # Convert signed to unsigned
    if long_val < 0:
        long_val += (1 << 64)

    mask = (1 << bits) - 1
    palette_idx = (long_val >> bit_offset) & mask

    if palette_idx >= len(palette):
        return None

    return str(palette[palette_idx]["Name"])


def iter_blocks_raw(mca_path: str):
    """
    Read every non-air block from an .mca file.
    Yields (chunk_x, chunk_z, x, y, z, block_name).
    """
    with open(mca_path, "rb") as f:
        header = f.read(SECTOR * 2)

    if len(header) < SECTOR:
        return

    file_size = os.path.getsize(mca_path)

    for chunk_z in range(32):
        for chunk_x in range(32):
            offset_entry = (chunk_x + chunk_z * 32) * 4
            offset_raw = struct.unpack(">I", header[offset_entry:offset_entry + 4])[0]
            offset_sectors = offset_raw >> 8
            size_sectors = offset_raw & 0xFF

            if offset_sectors == 0 or size_sectors == 0:
                continue  # chunk not generated

            byte_offset = offset_sectors * SECTOR
            byte_length = size_sectors * SECTOR

            if byte_offset + byte_length > file_size:
                continue

            with open(mca_path, "rb") as f:
                f.seek(byte_offset)
                chunk_data = f.read(byte_length)

            nbt_data = read_chunk_nbt(chunk_data)
            if nbt_data is None:
                continue

            # Locate sections (differs between old/new format)
            try:
                # 1.18+ format: top-level sections
                sections = nbt_data["sections"]
            except KeyError:
                try:
                    sections = nbt_data["Level"]["Sections"]
                except KeyError:
                    continue

            for section in sections:
                try:
                    section_y = section["Y"].value
                except (KeyError, AttributeError):
                    continue

                y_base = section_y * 16

                for y_local in range(16):
                    for z_local in range(16):
                        for x_local in range(16):
                            name = get_block_from_section_116_plus(
                                section, x_local, y_local, z_local
                            )
                            if name is None:
                                continue
                            if name in ("minecraft:air",
                                        "minecraft:cave_air",
                                        "minecraft:void_air"):
                                continue
                            yield chunk_x, chunk_z, x_local, y_base + y_local, z_local, name


# ──────────────────────────────────────────────
# File processing
# ──────────────────────────────────────────────

def process_file(mca_path: str, verbose: bool = True) -> dict:
    print(f"\n{'='*60}")
    print(f"File: {mca_path}")
    print(f"Size: {os.path.getsize(mca_path):,} bytes")
    print(f"{'='*60}")

    block_count = 0
    type_counts: dict[str, int] = {}
    printed = 0

    try:
        for chunk_x, chunk_z, x, y, z, name in iter_blocks_raw(mca_path):
            block_count += 1
            type_counts[name] = type_counts.get(name, 0) + 1

            if verbose and printed < 10_000:
                print(f"  chunk({chunk_x:2d},{chunk_z:2d})  "
                      f"pos({x:2d},{y:4d},{z:2d})  {name}")
                printed += 1

    except Exception as e:
        print(f"  ERROR while reading: {e}")

    if verbose and block_count > 10_000:
        print(f"\n  ... output truncated after 10,000 lines ...")

    print(f"\n  --- Summary ---")
    print(f"  Total non-air blocks : {block_count:,}")
    print(f"  Unique block types   : {len(type_counts):,}")

    if type_counts:
        print("  Top 20 block types:")
        for name, count in sorted(type_counts.items(),
                                  key=lambda kv: kv[1], reverse=True)[:20]:
            print(f"    {count:>12,}  {name}")

    return type_counts


def find_mca_files(path: str) -> list[str]:
    if os.path.isfile(path) and path.endswith(".mca"):
        return [path]
    pattern = os.path.join(path, "**", "*.mca")
    return sorted(glob.glob(pattern, recursive=True))


def main():
    target = sys.argv[1] if len(sys.argv) > 1 else "."
    target = os.path.abspath(target)

    print(f"Searching: {target}")
    files = find_mca_files(target)

    if not files:
        print("No .mca files found.")
        return

    print(f"Found {len(files)} .mca file(s).")

    grand_total = 0
    grand_types: dict[str, int] = {}

    for path in files:
        counts = process_file(path, verbose=True)
        for name, n in counts.items():
            grand_total += n
            grand_types[name] = grand_types.get(name, 0) + n

    print(f"\n{'#'*60}")
    print(f"GRAND TOTAL across all files")
    print(f"{'#'*60}")
    print(f"  Total non-air blocks : {grand_total:,}")
    print(f"  Unique block types   : {len(grand_types):,}")
    if grand_types:
        print("  Top 30 block types (all files combined):")
        for name, count in sorted(grand_types.items(),
                                  key=lambda kv: kv[1], reverse=True)[:30]:
            print(f"    {count:>12,}  {name}")

    print("\nDone.")


if __name__ == "__main__":
    main()

```


<!-- 101 | Python script to extract blocks from .mca files | txt -->
```txt
python diagnose_mca.py "/storage/emulated/0/Download/New Folder/Minecraft unknown world/DIM-1/r.1259.2517.mca"
```


<!-- 102 | Python script to extract blocks from .mca files | py -->
```py
"""
diagnose_mca.py — Peek inside an .mca file and identify the chunk format.

Usage:
    python diagnose_mca.py path/to/file.mca
"""
import sys, struct, zlib, gzip, io

try:
    from nbt import nbt as nbtlib
except ImportError:
    sys.exit("pip install nbt")

SECTOR = 4096

def read_chunk_raw(mca_path, chunk_x=0, chunk_z=0):
    """Find and return the raw (still compressed) bytes of a chunk."""
    with open(mca_path, "rb") as f:
        header = f.read(SECTOR * 2)
        file_size = f.seek(0, 2)

    # Scan all 1024 chunks to find the first one that actually exists
    for cz in range(32):
        for cx in range(32):
            entry = (cx + cz * 32) * 4
            raw = struct.unpack(">I", header[entry:entry+4])[0]
            offset_sectors = raw >> 8
            size_sectors   = raw & 0xFF
            if offset_sectors == 0 or size_sectors == 0:
                continue
            byte_offset = offset_sectors * SECTOR
            if byte_offset + SECTOR > file_size:
                continue
            with open(mca_path, "rb") as f:
                f.seek(byte_offset)
                data = f.read(size_sectors * SECTOR)
            print(f"  First populated chunk: ({cx}, {cz})")
            print(f"  Raw chunk size on disk: {len(data)} bytes")
            print(f"  First 5 bytes (hex): {data[:5].hex()}")
            return cx, cz, data
    return None, None, None

def decompress(data):
    if len(data) < 5:
        return None
    length = struct.unpack(">I", data[0:4])[0]
    comp   = data[4]
    payload = data[5:5+length-1]
    print(f"  Compression type byte: {comp}  ", end="")
    if comp == 2:
        print("(zlib)")
        return zlib.decompress(payload)
    elif comp == 1:
        print("(gzip)")
        return gzip.decompress(payload)
    elif comp == 3:
        print("(uncompressed)")
        return payload
    else:
        print(f"(UNKNOWN — {comp})")
        return None

def inspect_nbt(raw_bytes):
    nbt_file = nbtlib.NBTFile(buffer=io.BytesIO(raw_bytes))

    print("\n  Top-level NBT keys:", list(nbt_file.keys()))

    # Detect format by looking for known keys
    if "sections" in nbt_file:
        print("  Format: 1.18+ (sections at root level)")
        sections = nbt_file["sections"]
    elif "Level" in nbt_file:
        level = nbt_file["Level"]
        print("  Format: pre-1.18 (has 'Level' key)")
        print("  Level keys:", list(level.keys()))

        if "Sections" in level:
            sections = level["Sections"]
            print(f"  Number of sections: {len(sections)}")

            if len(sections) > 0:
                s = sections[0]
                print(f"  Section[0] keys: {list(s.keys())}")

                if "Palette" in s or "block_states" in s:
                    print("  Block format: MODERN palette (1.13+)")
                elif "Blocks" in s:
                    print("  Block format: LEGACY numeric IDs (pre-1.13)")
                    blocks_tag = s["Blocks"]
                    print(f"  Blocks array length: {len(blocks_tag)}")
                    sample = [b for b in bytes(blocks_tag.value[:20])]
                    print(f"  First 20 block IDs: {sample}")
                else:
                    print("  Block format: UNKNOWN - section keys don't match known formats")
        else:
            print("  No 'Sections' found in Level")

        # Print DataVersion if available
        if "DataVersion" in nbt_file:
            dv = nbt_file["DataVersion"].value
            print(f"\n  DataVersion: {dv}  ", end="")
            # Map common DataVersions to MC versions
            versions = {
                (0, 99):    "pre-1.9",
                (100, 175): "1.9–1.10",
                (176, 510): "1.11",
                (511, 819): "1.12",
                (820, 1343): "1.13",
                (1344, 1631): "1.14",
                (1632, 2129): "1.15",
                (2130, 2584): "1.16",
                (2585, 2724): "1.17",
                (2725, 2860): "1.18",
                (2861, 3105): "1.19",
                (3106, 3337): "1.20",
                (3338, 9999): "1.21+",
            }
            for (lo, hi), label in versions.items():
                if lo <= dv <= hi:
                    print(f"→ approx Minecraft {label}")
                    break
            else:
                print()
        elif "DataVersion" in nbt_file:
            pass
        else:
            print("\n  No DataVersion found → likely very old world (pre-1.9)")
    else:
        print("  Format: UNKNOWN — no 'Level' or 'sections' key")

def main():
    if len(sys.argv) < 2:
        sys.exit("Usage: python diagnose_mca.py path/to/file.mca")

    path = sys.argv[1]
    print(f"Diagnosing: {path}")

    cx, cz, raw = read_chunk_raw(path)
    if raw is None:
        print("No populated chunks found in this file (all offsets are zero).")
        return

    decompressed = decompress(raw)
    if decompressed is None:
        print("Could not decompress chunk data.")
        return

    print(f"  Decompressed size: {len(decompressed):,} bytes")
    inspect_nbt(decompressed)

if __name__ == "__main__":
    main()

```


<!-- 103 | Python script to extract blocks from .mca files | txt -->
```txt
/sdcard/Download/New Folder/...
```


<!-- 104 | Python script to extract blocks from .mca files | txt -->
```txt
/storage/self/primary/Download/...
```


<!-- 105 | Python script to extract blocks from .mca files | python -->
```python
if len(sys.argv) < 2:
    sys.exit("Usage: python diagnose_mca.py path/to/file.mca")

path = sys.argv[1]
```


<!-- 106 | Python script to extract blocks from .mca files | python -->
```python
path = "/storage/emulated/0/Download/New Folder/Minecraft unknown world/DIM-1/r.1259.2517.mca"
```


<!-- 107 | Python script to extract blocks from .mca files | py -->
```py
"""
read_mca_legacy.py — Read .mca files using pre-1.13 numeric block ID format.

Requirements:
    pip install nbt

Change SEARCH_DIR to your world folder path.
"""

import os, sys, glob, struct, zlib, gzip, io

try:
    from nbt import nbt as nbtlib
except ImportError:
    sys.exit("Missing dependency. Install with:\n    pip install nbt")

# ── CHANGE THIS to your world folder ──────────────────────
SEARCH_DIR = "/storage/emulated/0/Download/New Folder/Minecraft unknown world"
# ──────────────────────────────────────────────────────────

SECTOR = 4096

# Numeric block ID → name map (most common blocks)
BLOCK_NAMES = {
    0: "air", 1: "stone", 2: "grass", 3: "dirt", 4: "cobblestone",
    5: "planks", 6: "sapling", 7: "bedrock", 8: "flowing_water",
    9: "water", 10: "flowing_lava", 11: "lava", 12: "sand",
    13: "gravel", 14: "gold_ore", 15: "iron_ore", 16: "coal_ore",
    17: "log", 18: "leaves", 19: "sponge", 20: "glass",
    21: "lapis_ore", 22: "lapis_block", 24: "sandstone",
    25: "noteblock", 26: "bed", 27: "golden_rail", 28: "detector_rail",
    29: "sticky_piston", 30: "web", 31: "tallgrass", 32: "deadbush",
    33: "piston", 35: "wool", 37: "yellow_flower", 38: "red_flower",
    39: "brown_mushroom", 40: "red_mushroom", 41: "gold_block",
    42: "iron_block", 43: "double_stone_slab", 44: "stone_slab",
    45: "brick_block", 46: "tnt", 47: "bookshelf", 48: "mossy_cobblestone",
    49: "obsidian", 50: "torch", 51: "fire", 52: "mob_spawner",
    53: "oak_stairs", 54: "chest", 55: "redstone_wire", 56: "diamond_ore",
    57: "diamond_block", 58: "crafting_table", 59: "wheat",
    60: "farmland", 61: "furnace", 62: "lit_furnace", 63: "standing_sign",
    64: "wooden_door", 65: "ladder", 66: "rail", 67: "stone_stairs",
    68: "wall_sign", 69: "lever", 70: "stone_pressure_plate",
    71: "iron_door", 72: "wooden_pressure_plate", 73: "redstone_ore",
    74: "lit_redstone_ore", 78: "snow_layer", 79: "ice", 80: "snow",
    81: "cactus", 82: "clay", 83: "reeds", 85: "fence",
    86: "pumpkin", 87: "netherrack", 88: "soul_sand", 89: "glowstone",
    90: "portal", 91: "lit_pumpkin", 95: "stained_glass",
    97: "monster_egg", 98: "stonebrick", 99: "brown_mushroom_block",
    100: "red_mushroom_block", 101: "iron_bars", 102: "glass_pane",
    103: "melon_block", 106: "vine", 107: "fence_gate",
    108: "brick_stairs", 109: "stone_brick_stairs", 110: "mycelium",
    111: "waterlily", 112: "nether_brick", 113: "nether_brick_fence",
    114: "nether_brick_stairs", 115: "nether_wart", 116: "enchanting_table",
    117: "brewing_stand", 120: "end_portal_frame", 121: "end_stone",
    122: "dragon_egg", 123: "redstone_lamp", 125: "double_wooden_slab",
    126: "wooden_slab", 128: "sandstone_stairs", 129: "emerald_ore",
    130: "ender_chest", 132: "tripwire", 133: "emerald_block",
    134: "spruce_stairs", 135: "birch_stairs", 136: "jungle_stairs",
    137: "command_block", 138: "beacon", 139: "cobblestone_wall",
    141: "carrots", 142: "potatoes", 143: "wooden_button",
    145: "anvil", 146: "trapped_chest", 147: "light_weighted_pressure_plate",
    148: "heavy_weighted_pressure_plate", 151: "daylight_detector",
    152: "redstone_block", 153: "quartz_ore", 154: "hopper",
    155: "quartz_block", 156: "quartz_stairs", 157: "activator_rail",
    158: "dropper", 159: "stained_hardened_clay", 160: "stained_glass_pane",
    161: "leaves2", 162: "log2", 163: "acacia_stairs", 164: "dark_oak_stairs",
    165: "slime", 166: "barrier", 167: "iron_trapdoor", 168: "prismarine",
    169: "sea_lantern", 170: "hay_block", 171: "carpet",
    172: "hardened_clay", 173: "coal_block", 174: "packed_ice",
    175: "double_plant", 176: "standing_banner", 177: "wall_banner",
    178: "daylight_detector_inverted", 179: "red_sandstone",
    180: "red_sandstone_stairs", 182: "stone_slab2", 183: "spruce_fence_gate",
    184: "birch_fence_gate", 185: "jungle_fence_gate",
    186: "dark_oak_fence_gate", 187: "acacia_fence_gate",
    188: "spruce_fence", 189: "birch_fence", 190: "jungle_fence",
    191: "dark_oak_fence", 192: "acacia_fence", 193: "spruce_door",
    194: "birch_door", 195: "jungle_door", 196: "acacia_door",
    197: "dark_oak_door", 198: "end_rod", 199: "chorus_plant",
    200: "chorus_flower", 201: "purpur_block", 202: "purpur_pillar",
    203: "purpur_stairs", 205: "purpur_double_slab", 206: "purpur_slab",
    207: "beetroots", 208: "grass_path", 209: "end_gateway",
    210: "repeating_command_block", 211: "chain_command_block",
    212: "frosted_ice", 213: "magma", 214: "nether_wart_block",
    215: "red_nether_brick", 216: "bone_block", 218: "observer",
    219: "white_shulker_box", 220: "orange_shulker_box",
    255: "structure_block",
}

def block_name(block_id):
    return BLOCK_NAMES.get(block_id, f"unknown_block_{block_id}")

AIR_IDS = {0}  # only air is skipped

def read_chunk_nbt(mca_path, offset_sectors, size_sectors):
    byte_offset = offset_sectors * SECTOR
    with open(mca_path, "rb") as f:
        f.seek(byte_offset)
        data = f.read(size_sectors * SECTOR)

    if len(data) < 5:
        return None
    length = struct.unpack(">I", data[0:4])[0]
    comp   = data[4]
    payload = data[5:5 + length - 1]

    try:
        if comp == 2:
            raw = zlib.decompress(payload)
        elif comp == 1:
            raw = gzip.decompress(payload)
        elif comp == 3:
            raw = payload
        else:
            return None
    except Exception:
        return None

    try:
        return nbtlib.NBTFile(buffer=io.BytesIO(raw))
    except Exception:
        return None


def iter_blocks_legacy(mca_path):
    """
    Yield (chunk_x, chunk_z, x, y, z, block_name) for every non-air block
    using the pre-1.13 numeric ID format.
    """
    file_size = os.path.getsize(mca_path)

    with open(mca_path, "rb") as f:
        header = f.read(SECTOR * 2)

    for chunk_z in range(32):
        for chunk_x in range(32):
            entry = (chunk_x + chunk_z * 32) * 4
            raw_entry = struct.unpack(">I", header[entry:entry+4])[0]
            offset_sectors = raw_entry >> 8
            size_sectors   = raw_entry & 0xFF

            if offset_sectors == 0 or size_sectors == 0:
                continue
            if offset_sectors * SECTOR + size_sectors * SECTOR > file_size:
                continue

            nbt_data = read_chunk_nbt(mca_path, offset_sectors, size_sectors)
            if nbt_data is None:
                continue

            try:
                level = nbt_data["Level"]
                sections = level["Sections"]
            except KeyError:
                continue

            for section in sections:
                try:
                    section_y = section["Y"].value
                    blocks_tag = section["Blocks"]
                except KeyError:
                    continue

                blocks = bytes(blocks_tag.value)  # 4096 bytes, one per block

                # Data tag holds the 4-bit metadata (2 per byte, 2048 bytes)
                try:
                    data_tag = bytes(section["Data"].value)
                except KeyError:
                    data_tag = bytes(2048)

                y_base = section_y * 16

                for i, block_id in enumerate(blocks):
                    if block_id in AIR_IDS:
                        continue

                    # Decode index: blocks are stored YZX order
                    y_local = (i >> 8) & 0xF
                    z_local = (i >> 4) & 0xF
                    x_local =  i       & 0xF

                    # Get 4-bit metadata
                    meta_byte = data_tag[i >> 1]
                    if i & 1:
                        meta = (meta_byte >> 4) & 0xF
                    else:
                        meta = meta_byte & 0xF

                    name = block_name(block_id)
                    yield chunk_x, chunk_z, x_local, y_base + y_local, z_local, block_id, meta, name


def process_file(mca_path, verbose=True):
    print(f"\n{'='*60}")
    print(f"File: {os.path.basename(mca_path)}")
    print(f"Size: {os.path.getsize(mca_path):,} bytes")
    print(f"{'='*60}")

    block_count = 0
    type_counts = {}
    printed = 0

    try:
        for cx, cz, x, y, z, bid, meta, name in iter_blocks_legacy(mca_path):
            block_count += 1
            key = f"{name}" + (f":{meta}" if meta != 0 else "")
            type_counts[key] = type_counts.get(key, 0) + 1

            if verbose and printed < 5000:
                print(f"  chunk({cx:2d},{cz:2d})  pos({x:2d},{y:3d},{z:2d})"
                      f"  id={bid:3d}:{meta}  {name}")
                printed += 1
    except Exception as e:
        print(f"  ERROR: {e}")

    if verbose and block_count > 5000:
        print(f"\n  ... output truncated after 5,000 lines ...")

    print(f"\n  --- Summary ---")
    print(f"  Total non-air blocks : {block_count:,}")
    print(f"  Unique block types   : {len(type_counts):,}")
    if type_counts:
        print("  Top 20 block types:")
        for name, count in sorted(type_counts.items(),
                                  key=lambda kv: kv[1], reverse=True)[:20]:
            print(f"    {count:>12,}  {name}")

    return type_counts


def find_mca_files(search_dir):
    pattern = os.path.join(search_dir, "**", "*.mca")
    return sorted(glob.glob(pattern, recursive=True))


def main():
    print(f"Searching: {SEARCH_DIR}\n")
    files = find_mca_files(SEARCH_DIR)

    if not files:
        print("No .mca files found.")
        return

    print(f"Found {len(files)} .mca file(s).")

    grand_total = 0
    grand_types = {}

    for path in files:
        counts = process_file(path, verbose=True)
        for name, n in counts.items():
            grand_total += n
            grand_types[name] = grand_types.get(name, 0) + n

    print(f"\n{'#'*60}")
    print(f"GRAND TOTAL")
    print(f"{'#'*60}")
    print(f"  Total non-air blocks : {grand_total:,}")
    print(f"  Unique block types   : {len(grand_types):,}")
    if grand_types:
        print("  Top 30 block types (all files combined):")
        for name, count in sorted(grand_types.items(),
                                  key=lambda kv: kv[1], reverse=True)[:30]:
            print(f"    {count:>12,}  {name}")

    print("\nDone.")


if __name__ == "__main__":
    main()

```


<!-- 108 | Python script to extract blocks from .mca files | python -->
```python
INPUT_FILE = "/storage/emulated/0/Download/yourfile.txt"
OUTPUT_DIR = "/storage/emulated/0/Download/ByteWorld"
```


<!-- 109 | Python script to extract blocks from .mca files | py -->
```py
"""
bytes_to_minecraft.py — Convert any file's raw bytes into a Minecraft 1.12.2 world.

Each byte (0–255) maps directly to a block ID.
Bytes are arranged as a 3D cube: X fills first, then Z (new row), then Y (new layer).
Byte 0 = air = left empty.

Requirements:
    pip install nbt

HOW TO USE:
1. Set INPUT_FILE to any file you want to convert.
2. Set OUTPUT_DIR to a new folder — this becomes your Minecraft world folder.
3. Run the script, then copy OUTPUT_DIR into your Minecraft saves folder.
"""

import os, sys, math, struct, zlib, io
from nbt import nbt as nbtlib

# ── SETTINGS ──────────────────────────────────────────────────────────────────

INPUT_FILE = "/storage/emulated/0/Download/yourfile.txt"   # ← change this
OUTPUT_DIR = "/storage/emulated/0/Download/ByteWorld"      # ← change this

# Cube side length — auto-calculated from file size, or set manually (max 256)
# e.g. FORCE_SIDE = 64 means a 64x64x64 cube (262144 bytes used)
FORCE_SIDE = None   # None = auto

# ── BLOCK ID → NAME (for reference) ──────────────────────────────────────────

BLOCK_NAMES = {
    0:"air",1:"stone",2:"grass",3:"dirt",4:"cobblestone",5:"planks",
    6:"sapling",7:"bedrock",8:"flowing_water",9:"water",10:"flowing_lava",
    11:"lava",12:"sand",13:"gravel",14:"gold_ore",15:"iron_ore",
    16:"coal_ore",17:"log",18:"leaves",19:"sponge",20:"glass",
    21:"lapis_ore",22:"lapis_block",24:"sandstone",25:"noteblock",
    30:"web",31:"tallgrass",35:"wool",37:"yellow_flower",38:"red_flower",
    39:"brown_mushroom",40:"red_mushroom",41:"gold_block",42:"iron_block",
    43:"double_stone_slab",44:"stone_slab",45:"brick_block",46:"tnt",
    47:"bookshelf",48:"mossy_cobblestone",49:"obsidian",50:"torch",
    51:"fire",56:"diamond_ore",57:"diamond_block",73:"redstone_ore",
    74:"lit_redstone_ore",78:"snow_layer",79:"ice",80:"snow",
    81:"cactus",82:"clay",87:"netherrack",88:"soul_sand",89:"glowstone",
    98:"stonebrick",103:"melon_block",110:"mycelium",112:"nether_brick",
    121:"end_stone",129:"emerald_ore",133:"emerald_block",
    138:"beacon",152:"redstone_block",153:"quartz_ore",155:"quartz_block",
    159:"stained_hardened_clay",168:"prismarine",169:"sea_lantern",
    170:"hay_block",172:"hardened_clay",173:"coal_block",174:"packed_ice",
    201:"purpur_block",213:"magma",214:"nether_wart_block",
    215:"red_nether_brick",216:"bone_block",
}

# ── CORE LOGIC ────────────────────────────────────────────────────────────────

SECTOR = 4096

def make_level_dat(world_name, output_dir):
    """Create a minimal level.dat so Minecraft recognises the world."""
    root = nbtlib.NBTFile()
    data = nbtlib.TAG_Compound()
    data.name = "Data"
    data["LevelName"]    = nbtlib.TAG_String(world_name)
    data["version"]      = nbtlib.TAG_Int(19133)        # Anvil format
    data["DataVersion"]  = nbtlib.TAG_Int(1343)         # 1.12.2
    data["GameType"]     = nbtlib.TAG_Int(1)            # Creative
    data["allowCommands"]= nbtlib.TAG_Byte(1)
    data["Time"]         = nbtlib.TAG_Long(6000)        # Noon
    data["SpawnX"]       = nbtlib.TAG_Int(8)
    data["SpawnY"]       = nbtlib.TAG_Int(64)
    data["SpawnZ"]       = nbtlib.TAG_Int(8)
    data["generatorName"]= nbtlib.TAG_String("flat")
    data["RandomSeed"]   = nbtlib.TAG_Long(0)
    root["Data"] = data

    path = os.path.join(output_dir, "level.dat")
    root.write_file(filename=path)
    print(f"  Wrote level.dat")


def make_chunk_nbt(chunk_x, chunk_z, blocks_3d):
    """
    Build a pre-1.13 chunk NBT from a 3D array.
    blocks_3d[y][z][x] = block_id (0–255)
    Covers Y 0–127 (8 sections of 16).
    """
    root = nbtlib.NBTFile()
    root["DataVersion"] = nbtlib.TAG_Int(1343)

    level = nbtlib.TAG_Compound()
    level.name = "Level"
    level["xPos"]             = nbtlib.TAG_Int(chunk_x)
    level["zPos"]             = nbtlib.TAG_Int(chunk_z)
    level["LastUpdate"]       = nbtlib.TAG_Long(0)
    level["LightPopulated"]   = nbtlib.TAG_Byte(1)
    level["TerrainPopulated"] = nbtlib.TAG_Byte(1)
    level["InhabitedTime"]    = nbtlib.TAG_Long(0)
    level["Biomes"]           = nbtlib.TAG_Byte_Array([1] * 256)  # Plains
    level["HeightMap"]        = nbtlib.TAG_Int_Array([128] * 256)
    level["Entities"]         = nbtlib.TAG_List(type=nbtlib.TAG_Compound)
    level["TileEntities"]     = nbtlib.TAG_List(type=nbtlib.TAG_Compound)

    sections = nbtlib.TAG_List(type=nbtlib.TAG_Compound)

    max_y = len(blocks_3d)
    num_sections = math.ceil(max_y / 16)

    for section_y in range(num_sections):
        y_start = section_y * 16
        y_end   = min(y_start + 16, max_y)

        # Build flat 4096-byte Blocks array (YZX order)
        block_arr = bytearray(4096)
        data_arr  = bytearray(2048)   # 4-bit metadata, all 0

        has_blocks = False
        for y_local in range(y_end - y_start):
            y = y_start + y_local
            for z in range(16):
                for x in range(16):
                    bid = blocks_3d[y][z][x] if y < len(blocks_3d) else 0
                    if bid != 0:
                        has_blocks = True
                    idx = (y_local << 8) | (z << 4) | x
                    block_arr[idx] = bid

        if not has_blocks:
            continue  # skip empty sections

        section = nbtlib.TAG_Compound()
        section["Y"]          = nbtlib.TAG_Byte(section_y)
        section["Blocks"]     = nbtlib.TAG_Byte_Array(list(block_arr))
        section["Data"]       = nbtlib.TAG_Byte_Array(list(data_arr))
        section["BlockLight"] = nbtlib.TAG_Byte_Array([255] * 2048)
        section["SkyLight"]   = nbtlib.TAG_Byte_Array([255] * 2048)
        sections.append(section)

    level["Sections"] = sections
    root["Level"] = level
    return root


def write_chunk_to_region(region_data: dict, chunk_x, chunk_z, nbt_chunk):
    """Serialize a chunk NBT and store it in region_data dict."""
    buf = io.BytesIO()
    nbt_chunk.write_file(buffer=buf)
    raw = buf.getvalue()
    compressed = zlib.compress(raw)
    # 4-byte length + 1-byte compression type (2=zlib) + data
    chunk_bytes = struct.pack(">I", len(compressed) + 1) + b'\x02' + compressed
    region_data[(chunk_x % 32, chunk_z % 32)] = chunk_bytes


def write_region_file(path, chunks: dict):
    """Write a complete .mca region file from a dict of {(cx,cz): bytes}."""
    # Calculate sectors needed for each chunk
    placements = {}  # (cx,cz) -> (sector_offset, sector_count)
    current_sector = 2  # sectors 0 and 1 are the header

    for (cx, cz), data in chunks.items():
        # Pad to sector boundary
        padded_len = math.ceil(len(data) / SECTOR) * SECTOR
        sector_count = padded_len // SECTOR
        placements[(cx, cz)] = (current_sector, sector_count, data, padded_len)
        current_sector += sector_count

    # Build header (8192 bytes = 2 sectors)
    header = bytearray(SECTOR * 2)
    for (cx, cz), (offset, count, _, _) in placements.items():
        entry_idx = (cx + cz * 32) * 4
        val = (offset << 8) | (count & 0xFF)
        header[entry_idx:entry_idx+4] = struct.pack(">I", val)

    with open(path, "wb") as f:
        f.write(bytes(header))
        for (cx, cz), (offset, count, data, padded_len) in placements.items():
            f.seek(offset * SECTOR)
            f.write(data)
            # Pad to sector boundary
            remainder = padded_len - len(data)
            if remainder > 0:
                f.write(b'\x00' * remainder)


def bytes_to_world(input_file, output_dir, force_side=None):
    print(f"\nReading: {input_file}")
    with open(input_file, "rb") as f:
        raw_bytes = f.read()

    total_bytes = len(raw_bytes)
    print(f"File size: {total_bytes:,} bytes")

    # Calculate cube side length
    if force_side:
        side = force_side
    else:
        side = math.ceil(total_bytes ** (1/3))
        side = max(side, 1)

    total_cells = side * side * side
    print(f"Cube size: {side} x {side} x {side} = {total_cells:,} cells")

    if total_bytes > total_cells:
        print(f"Warning: file too large for cube, truncating to {total_cells:,} bytes")
        raw_bytes = raw_bytes[:total_cells]
    elif total_bytes < total_cells:
        # Pad with zeros (air)
        raw_bytes = raw_bytes + b'\x00' * (total_cells - total_bytes)

    # Build 3D block array [y][z][x]
    # Layout: X fills first (fastest), then Z, then Y (slowest = layers)
    print("Building 3D block layout...")
    blocks_3d = [[[0]*side for _ in range(side)] for _ in range(side)]
    for i, byte_val in enumerate(raw_bytes):
        y = i // (side * side)
        z = (i // side) % side
        x = i % side
        blocks_3d[y][z][x] = byte_val   # 0 stays as air

    # Count non-air blocks
    non_air = sum(
        1 for y in range(side) for z in range(side) for x in range(side)
        if blocks_3d[y][z][x] != 0
    )
    print(f"Non-air blocks to place: {non_air:,}")

    # Count unique block types used
    used_ids = set(raw_bytes) - {0}
    print(f"Unique block IDs used: {len(used_ids)}")
    for bid in sorted(used_ids)[:10]:
        name = BLOCK_NAMES.get(bid, f"unknown_{bid}")
        print(f"  ID {bid:3d} = {name}")
    if len(used_ids) > 10:
        print(f"  ... and {len(used_ids)-10} more")

    # Create world directory structure
    region_dir = os.path.join(output_dir, "region")
    os.makedirs(region_dir, exist_ok=True)
    print(f"\nOutput world: {output_dir}")

    # Write level.dat
    make_level_dat("ByteWorld", output_dir)

    # Figure out which region files we need
    # Each region covers 32x32 chunks, each chunk is 16x16 blocks
    chunks_needed = math.ceil(side / 16)
    regions_needed = math.ceil(chunks_needed / 32)
    print(f"Chunks per axis: {chunks_needed}, Region files per axis: {regions_needed}")

    # Group chunks by region
    region_chunks = {}  # (rx, rz) -> {(lcx, lcz): blocks_chunk}

    total_chunks = chunks_needed * chunks_needed
    done = 0

    for chunk_z in range(chunks_needed):
        for chunk_x in range(chunks_needed):
            rx = chunk_x // 32
            rz = chunk_z // 32
            lcx = chunk_x % 32
            lcz = chunk_z % 32

            # Extract this chunk's 16x16xside block column
            chunk_blocks = []
            for y in range(side):
                layer = []
                for z in range(16):
                    row = []
                    for x in range(16):
                        bx = chunk_x * 16 + x
                        bz = chunk_z * 16 + z
                        if bx < side and bz < side:
                            row.append(blocks_3d[y][bz][bx])
                        else:
                            row.append(0)
                    layer.append(row)
                chunk_blocks.append(layer)

            key = (rx, rz)
            if key not in region_chunks:
                region_chunks[key] = {}
            region_chunks[key][(lcx, lcz)] = chunk_blocks

            done += 1
            if done % 50 == 0 or done == total_chunks:
                print(f"  Prepared chunk {done}/{total_chunks}...")

    # Write region files
    print("\nWriting region files...")
    for (rx, rz), chunks in region_chunks.items():
        region_data = {}
        for (lcx, lcz), chunk_blocks in chunks.items():
            global_cx = rx * 32 + lcx
            global_cz = rz * 32 + lcz
            nbt_chunk = make_chunk_nbt(global_cx, global_cz, chunk_blocks)
            write_chunk_to_region(region_data, lcx, lcz, nbt_chunk)

        region_path = os.path.join(region_dir, f"r.{rx}.{rz}.mca")
        write_region_file(region_path, region_data)
        print(f"  Wrote {os.path.basename(region_path)}")

    print("\n✓ Done! Copy the folder to your Minecraft saves directory.")
    print(f"  World folder: {output_dir}")
    print(f"  Spawn point is at X=8 Y=64 Z=8 — you may need to fly up/down to see the cube.")
    print(f"  The cube starts at X=0 Y=0 Z=0 and extends to X={side} Y={side} Z={side}.")


# ── RUN ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not os.path.isfile(INPUT_FILE):
        print(f"ERROR: Input file not found: {INPUT_FILE}")
        print("Edit INPUT_FILE at the top of this script.")
        sys.exit(1)

    bytes_to_world(INPUT_FILE, OUTPUT_DIR, force_side=FORCE_SIDE)

```


<!-- 110 | Python script to extract blocks from .mca files | py -->
```py
"""
bytes_to_minecraft.py — Convert any file's raw bytes into a Minecraft 1.12.2 world.

Each byte (0-255) maps directly to a block ID.
Bytes fill X first, then Z (new row), then Y (new layer upward).
Byte 0 = air = left empty.

No external libraries needed — writes NBT binary directly.

HOW TO USE:
1. Set INPUT_FILE to any file you want to convert.
2. Set OUTPUT_DIR to a new empty folder name.
3. Run, then copy OUTPUT_DIR into your Minecraft saves folder.
"""

import os, sys, math, struct, zlib, gzip, io

# ── SETTINGS ──────────────────────────────────────────────────────────────────

INPUT_FILE = "/storage/emulated/0/Download/Bonnie's Lullaby.mid"
OUTPUT_DIR = "/storage/emulated/0/Download/ByteWorld"

FORCE_SIDE = None   # None = auto-calculate. Set an integer to override.

# ── BLOCK ID NAMES (just for the printed summary) ─────────────────────────────

BLOCK_NAMES = {
    0:"air",1:"stone",2:"grass",3:"dirt",4:"cobblestone",5:"planks",
    6:"sapling",7:"bedrock",8:"flowing_water",9:"water",10:"flowing_lava",
    11:"lava",12:"sand",13:"gravel",14:"gold_ore",15:"iron_ore",
    16:"coal_ore",17:"log",18:"leaves",19:"sponge",20:"glass",
    21:"lapis_ore",22:"lapis_block",24:"sandstone",25:"noteblock",
    30:"web",31:"tallgrass",35:"wool",37:"yellow_flower",38:"red_flower",
    39:"brown_mushroom",40:"red_mushroom",41:"gold_block",42:"iron_block",
    43:"double_stone_slab",44:"stone_slab",45:"brick_block",46:"tnt",
    47:"bookshelf",48:"mossy_cobblestone",49:"obsidian",50:"torch",
    51:"fire",56:"diamond_ore",57:"diamond_block",73:"redstone_ore",
    74:"lit_redstone_ore",78:"snow_layer",79:"ice",80:"snow",
    81:"cactus",82:"clay",87:"netherrack",88:"soul_sand",89:"glowstone",
    98:"stonebrick",103:"melon_block",110:"mycelium",112:"nether_brick",
    121:"end_stone",129:"emerald_ore",133:"emerald_block",138:"beacon",
    152:"redstone_block",153:"quartz_ore",155:"quartz_block",
    159:"stained_hardened_clay",168:"prismarine",169:"sea_lantern",
    170:"hay_block",172:"hardened_clay",173:"coal_block",174:"packed_ice",
    201:"purpur_block",213:"magma",214:"nether_wart_block",
    215:"red_nether_brick",216:"bone_block",
}

SECTOR = 4096

# ── PURE BINARY NBT WRITER ────────────────────────────────────────────────────
# NBT tag type IDs
TAG_BYTE       = 1
TAG_SHORT      = 2
TAG_INT        = 3
TAG_LONG       = 4
TAG_FLOAT      = 5
TAG_DOUBLE     = 6
TAG_BYTE_ARRAY = 7
TAG_STRING     = 8
TAG_LIST       = 9
TAG_COMPOUND   = 10
TAG_INT_ARRAY  = 11

def nbt_name(name: str) -> bytes:
    """Encode a tag name: 2-byte length + UTF-8 bytes."""
    encoded = name.encode("utf-8")
    return struct.pack(">H", len(encoded)) + encoded

def nbt_byte(name, value):
    return bytes([TAG_BYTE]) + nbt_name(name) + struct.pack(">b", value)

def nbt_short(name, value):
    return bytes([TAG_SHORT]) + nbt_name(name) + struct.pack(">h", value)

def nbt_int(name, value):
    return bytes([TAG_INT]) + nbt_name(name) + struct.pack(">i", value)

def nbt_long(name, value):
    return bytes([TAG_LONG]) + nbt_name(name) + struct.pack(">q", value)

def nbt_string(name, value):
    enc = value.encode("utf-8")
    return bytes([TAG_STRING]) + nbt_name(name) + struct.pack(">H", len(enc)) + enc

def nbt_byte_array(name, data: bytes):
    return (bytes([TAG_BYTE_ARRAY]) + nbt_name(name)
            + struct.pack(">i", len(data)) + bytes(data))

def nbt_int_array(name, values: list):
    payload = struct.pack(f">{len(values)}i", *values)
    return bytes([TAG_INT_ARRAY]) + nbt_name(name) + struct.pack(">i", len(values)) + payload

def nbt_list(name, element_type, elements: list):
    """elements = list of raw payload bytes (no tag id, no name)."""
    header = bytes([TAG_LIST]) + nbt_name(name)
    header += bytes([element_type]) + struct.pack(">i", len(elements))
    return header + b"".join(elements)

def nbt_compound(name, *fields):
    """fields = pre-serialized tag bytes. Ends with TAG_End (0x00)."""
    header = bytes([TAG_COMPOUND]) + nbt_name(name)
    return header + b"".join(fields) + b"\x00"

def nbt_compound_payload(*fields):
    """Just the payload of a compound (no tag id, no name) for use inside lists."""
    return b"".join(fields) + b"\x00"

# ── CHUNK BUILDER ─────────────────────────────────────────────────────────────

def build_chunk_nbt(chunk_x, chunk_z, blocks_3d) -> bytes:
    """
    Serialize a complete pre-1.13 chunk as raw NBT bytes (uncompressed).
    blocks_3d[y][z][x] = block ID 0-255
    """
    max_y = len(blocks_3d)
    num_sections = math.ceil(max_y / 16)

    section_payloads = []

    for sec_y in range(num_sections):
        y_start = sec_y * 16
        y_end   = min(y_start + 16, max_y)

        block_arr = bytearray(4096)
        has_blocks = False

        for y_local in range(y_end - y_start):
            y = y_start + y_local
            for z in range(16):
                for x in range(16):
                    bid = blocks_3d[y][z][x] if y < max_y else 0
                    if bid:
                        has_blocks = True
                    idx = (y_local << 8) | (z << 4) | x
                    block_arr[idx] = bid

        if not has_blocks:
            continue

        data_arr  = bytearray(2048)   # all metadata = 0
        light_arr = bytearray([255] * 2048)

        sec_payload = nbt_compound_payload(
            nbt_byte("Y", sec_y),
            nbt_byte_array("Blocks", block_arr),
            nbt_byte_array("Data", data_arr),
            nbt_byte_array("BlockLight", light_arr),
            nbt_byte_array("SkyLight", light_arr),
        )
        section_payloads.append(sec_payload)

    # Sections list (TAG_List of TAG_Compound)
    sections_tag = nbt_list("Sections", TAG_COMPOUND, section_payloads)

    # Empty lists for Entities and TileEntities
    entities_tag     = nbt_list("Entities",     TAG_COMPOUND, [])
    tile_ent_tag     = nbt_list("TileEntities", TAG_COMPOUND, [])

    biomes_tag    = nbt_byte_array("Biomes",    bytes([1] * 256))
    heightmap_tag = nbt_int_array("HeightMap",  [max_y] * 256)

    level_payload = nbt_compound_payload(
        nbt_int("xPos", chunk_x),
        nbt_int("zPos", chunk_z),
        nbt_long("LastUpdate", 0),
        nbt_byte("LightPopulated", 1),
        nbt_byte("TerrainPopulated", 1),
        nbt_long("InhabitedTime", 0),
        biomes_tag,
        heightmap_tag,
        sections_tag,
        entities_tag,
        tile_ent_tag,
    )

    # Wrap Level compound inside root compound
    level_tag = bytes([TAG_COMPOUND]) + nbt_name("Level") + level_payload
    dv_tag    = nbt_int("DataVersion", 1343)

    # Root compound (unnamed = empty name)
    root = (bytes([TAG_COMPOUND]) + nbt_name("")
            + dv_tag + level_tag + b"\x00")

    return root


def compress_chunk(nbt_bytes: bytes) -> bytes:
    """Compress chunk NBT and wrap in region format (length + compression byte)."""
    compressed = zlib.compress(nbt_bytes)
    return struct.pack(">I", len(compressed) + 1) + b'\x02' + compressed


# ── REGION FILE WRITER ────────────────────────────────────────────────────────

def write_region_file(path, chunks: dict):
    """
    chunks = {(local_cx, local_cz): compressed_chunk_bytes}
    """
    placements = {}
    current_sector = 2

    for (cx, cz), data in chunks.items():
        padded = math.ceil(len(data) / SECTOR) * SECTOR
        count  = padded // SECTOR
        placements[(cx, cz)] = (current_sector, count, data, padded)
        current_sector += count

    # Header: 4096 bytes locations + 4096 bytes timestamps
    header = bytearray(SECTOR * 2)
    for (cx, cz), (offset, count, _, _) in placements.items():
        idx = (cx + cz * 32) * 4
        header[idx:idx+4] = struct.pack(">I", (offset << 8) | (count & 0xFF))

    with open(path, "wb") as f:
        f.write(bytes(header))
        for (cx, cz), (offset, count, data, padded) in placements.items():
            f.seek(offset * SECTOR)
            f.write(data)
            remainder = padded - len(data)
            if remainder > 0:
                f.write(b'\x00' * remainder)


# ── LEVEL.DAT WRITER ──────────────────────────────────────────────────────────

def write_level_dat(output_dir, world_name):
    data_payload = nbt_compound_payload(
        nbt_string("LevelName", world_name),
        nbt_int("version", 19133),
        nbt_int("DataVersion", 1343),
        nbt_int("GameType", 1),          # Creative
        nbt_byte("allowCommands", 1),
        nbt_long("Time", 6000),           # Noon
        nbt_int("SpawnX", 8),
        nbt_int("SpawnY", 64),
        nbt_int("SpawnZ", 8),
        nbt_string("generatorName", "flat"),
        nbt_long("RandomSeed", 0),
    )
    data_tag = bytes([TAG_COMPOUND]) + nbt_name("Data") + data_payload
    root = bytes([TAG_COMPOUND]) + nbt_name("") + data_tag + b"\x00"

    path = os.path.join(output_dir, "level.dat")
    with gzip.open(path, "wb") as f:
        f.write(root)
    print("  Wrote level.dat")


# ── MAIN ──────────────────────────────────────────────────────────────────────

def bytes_to_world(input_file, output_dir, force_side=None):
    print(f"\nReading: {input_file}")
    with open(input_file, "rb") as f:
        raw_bytes = f.read()

    total_bytes = len(raw_bytes)
    print(f"File size: {total_bytes:,} bytes")

    side = force_side if force_side else max(1, math.ceil(total_bytes ** (1/3)))
    total_cells = side ** 3
    print(f"Cube size: {side} x {side} x {side} = {total_cells:,} cells")

    # Pad or truncate to exactly fit the cube
    if total_bytes > total_cells:
        print(f"Truncating to {total_cells:,} bytes")
        raw_bytes = raw_bytes[:total_cells]
    elif total_bytes < total_cells:
        raw_bytes = raw_bytes + b'\x00' * (total_cells - total_bytes)

    # Build 3D array [y][z][x]
    print("Building 3D block layout...")
    blocks_3d = [[[0]*side for _ in range(side)] for _ in range(side)]
    for i, b in enumerate(raw_bytes):
        y =  i // (side * side)
        z = (i //  side) % side
        x =  i % side
        blocks_3d[y][z][x] = b

    non_air  = sum(1 for i, b in enumerate(raw_bytes) if b != 0)
    used_ids = sorted(set(raw_bytes) - {0})
    print(f"Non-air blocks: {non_air:,}")
    print(f"Unique block IDs: {len(used_ids)}")
    for bid in used_ids[:10]:
        print(f"  ID {bid:3d} = {BLOCK_NAMES.get(bid, f'unknown_{bid}')}")
    if len(used_ids) > 10:
        print(f"  ... and {len(used_ids)-10} more")

    # Setup output folders
    region_dir = os.path.join(output_dir, "region")
    os.makedirs(region_dir, exist_ok=True)
    print(f"\nOutput: {output_dir}")

    write_level_dat(output_dir, "ByteWorld")

    chunks_needed = max(1, math.ceil(side / 16))
    print(f"Chunks per axis: {chunks_needed}")

    # Build and write region files
    region_chunks = {}
    total_chunks = chunks_needed * chunks_needed
    done = 0

    for cz in range(chunks_needed):
        for cx in range(chunks_needed):
            rx, rz = cx // 32, cz // 32
            lcx, lcz = cx % 32, cz % 32

            # Slice out this chunk's block data
            chunk_blocks = []
            for y in range(side):
                layer = []
                for z in range(16):
                    row = []
                    for x in range(16):
                        bx = cx * 16 + x
                        bz = cz * 16 + z
                        row.append(blocks_3d[y][bz][bx] if bx < side and bz < side else 0)
                    layer.append(row)
                chunk_blocks.append(layer)

            nbt_bytes  = build_chunk_nbt(cx, cz, chunk_blocks)
            chunk_data = compress_chunk(nbt_bytes)

            key = (rx, rz)
            if key not in region_chunks:
                region_chunks[key] = {}
            region_chunks[key][(lcx, lcz)] = chunk_data

            done += 1
            if done % max(1, total_chunks // 5) == 0 or done == total_chunks:
                print(f"  Chunks: {done}/{total_chunks}")

    print("\nWriting region files...")
    for (rx, rz), chunks in region_chunks.items():
        path = os.path.join(region_dir, f"r.{rx}.{rz}.mca")
        write_region_file(path, chunks)
        print(f"  Wrote r.{rx}.{rz}.mca")

    print(f"\nDone! Copy '{output_dir}' to your Minecraft saves folder.")
    print(f"Cube is at X=0 Y=0 Z=0, size {side}x{side}x{side}.")
    print(f"Spawn is at X=8 Y=64 Z=8 — fly down to Y=0 to see it.")


if __name__ == "__main__":
    if not os.path.isfile(INPUT_FILE):
        print(f"ERROR: File not found: {INPUT_FILE}")
        sys.exit(1)
    bytes_to_world(INPUT_FILE, OUTPUT_DIR, force_side=FORCE_SIDE)

```


<!-- 111 | Romanian parliament seat distribution | python -->
```python
<!DOCTYPE html>
<html lang="ro">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Camera Deputaților – Distribuție Locuri 2024</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Source+Sans+3:wght@300;400;600&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg: #0e0f14;
    --surface: #16181f;
    --border: #2a2d38;
    --text: #e8e9ee;
    --muted: #6b6f82;

    --psd:  #e03d3d;
    --aur:  #1a3a6b;
    --pnl:  #f5a623;
    --usr:  #3db5e0;
    --sos:  #7b2d8b;
    --pot:  #e07b3d;
    --rmdsz:#2d8b5a;
  }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Source Sans 3', sans-serif;
    font-weight: 300;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 3rem 1.5rem 5rem;
  }

  header {
    text-align: center;
    margin-bottom: 3.5rem;
  }

  .country-label {
    font-size: 0.75rem;
    letter-spacing: 0.35em;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 0.6rem;
  }

  h1 {
    font-family: 'Playfair Display', serif;
    font-size: clamp(1.6rem, 4vw, 2.6rem);
    font-weight: 900;
    line-height: 1.1;
    background: linear-gradient(135deg, #fff 30%, #888 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .subtitle {
    margin-top: 0.8rem;
    font-size: 0.85rem;
    color: var(--muted);
    letter-spacing: 0.05em;
  }

  /* HEMICYCLE */
  .hemicycle-wrap {
    width: 100%;
    max-width: 640px;
    margin-bottom: 3rem;
  }

  svg.hemicycle {
    width: 100%;
    height: auto;
    overflow: visible;
  }

  /* LEGEND / CARDS */
  .cards {
    width: 100%;
    max-width: 680px;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 0.85rem;
  }

  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 1rem 1.1rem 0.9rem;
    position: relative;
    overflow: hidden;
    transition: transform 0.2s, border-color 0.2s;
  }

  .card:hover {
    transform: translateY(-3px);
    border-color: var(--accent);
  }

  .card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: var(--accent);
  }

  .card-acronym {
    font-family: 'Playfair Display', serif;
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--accent);
    margin-bottom: 0.15rem;
  }

  .card-seats {
    font-size: 2rem;
    font-weight: 600;
    line-height: 1;
    color: #fff;
    margin-bottom: 0.25rem;
  }

  .card-seats span {
    font-size: 0.75rem;
    font-weight: 300;
    color: var(--muted);
    margin-left: 3px;
  }

  .card-pct {
    font-size: 0.78rem;
    color: var(--muted);
    margin-bottom: 0.5rem;
  }

  .card-wing {
    display: inline-block;
    font-size: 0.65rem;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    background: rgba(255,255,255,0.06);
    border-radius: 3px;
    padding: 2px 6px;
    color: var(--muted);
    margin-bottom: 0.2rem;
  }

  .card-ideology {
    font-size: 0.72rem;
    color: var(--muted);
    font-style: italic;
  }

  .bar-bg {
    margin-top: 0.7rem;
    height: 4px;
    background: rgba(255,255,255,0.07);
    border-radius: 2px;
    overflow: hidden;
  }

  .bar-fill {
    height: 100%;
    background: var(--accent);
    border-radius: 2px;
    transition: width 1s ease;
  }

  /* total */
  .total-note {
    margin-top: 2.5rem;
    font-size: 0.78rem;
    color: var(--muted);
    letter-spacing: 0.04em;
    text-align: center;
  }

  /* spectrum axis */
  .spectrum {
    width: 100%;
    max-width: 680px;
    margin-bottom: 2.5rem;
    padding: 1rem 1.2rem;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
  }

  .spectrum-label {
    font-size: 0.68rem;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 0.75rem;
  }

  .spectrum-track {
    position: relative;
    height: 6px;
    background: linear-gradient(to right, #e03d3d, #f5a623, #e8e9ee, #3db5e0, #1a3a6b);
    border-radius: 3px;
    margin-bottom: 0.6rem;
  }

  .spectrum-dots {
    position: relative;
    height: 28px;
  }

  .sdot {
    position: absolute;
    top: 0;
    transform: translateX(-50%);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 3px;
  }

  .sdot-circle {
    width: 11px; height: 11px;
    border-radius: 50%;
    border: 2px solid var(--bg);
  }

  .sdot-label {
    font-size: 0.58rem;
    letter-spacing: 0.04em;
    color: var(--muted);
    white-space: nowrap;
  }
</style>
</head>
<body>

<header>
  <p class="country-label">România · 2024</p>
  <h1>Camera Deputaților</h1>
  <p class="subtitle">312 locuri · Distribuție după alegeri</p>
</header>

<!-- HEMICYCLE SVG -->
<div class="hemicycle-wrap">
<svg class="hemicycle" viewBox="0 0 500 270" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <filter id="glow">
      <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
      <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>

  <!-- Background arc -->
  <path d="M 30 255 A 220 220 0 0 1 470 255" fill="none" stroke="#2a2d38" stroke-width="60" stroke-linecap="butt"/>

  <!-- Party arcs — drawn programmatically via JS below -->
  <g id="arcs"></g>

  <!-- Center label -->
  <text x="250" y="248" text-anchor="middle" font-family="'Playfair Display',serif" font-size="22" font-weight="900" fill="#fff">312</text>
  <text x="250" y="264" text-anchor="middle" font-family="'Source Sans 3',sans-serif" font-size="9" fill="#6b6f82" letter-spacing="2">LOCURI TOTALE</text>
</svg>
</div>

<!-- POLITICAL SPECTRUM -->
<div class="spectrum">
  <div class="spectrum-label">Spectrul Politic</div>
  <div class="spectrum-track"></div>
  <div class="spectrum-dots" id="spectrumDots"></div>
  <div style="display:flex;justify-content:space-between;margin-top:4px;">
    <span style="font-size:0.65rem;color:#6b6f82;letter-spacing:0.08em">STÂNGA</span>
    <span style="font-size:0.65rem;color:#6b6f82;letter-spacing:0.08em">DREAPTA</span>
  </div>
</div>

<!-- CARDS -->
<div class="cards" id="cards"></div>

<p class="total-note">Total 312 locuri atribuite · Date furnizate manual</p>

<script>
const TOTAL = 312;

const parties = [
  { abbr: 'PSD',   seats: 86, color: '#e03d3d', wing: 'Centru-Stânga',  ideology: 'Social-democrație',   spectrumPct: 22 },
  { abbr: 'AUR',   seats: 63, color: '#1a3a6b', wing: 'Dreapta Extremă', ideology: 'Național-conservatorism', spectrumPct: 92 },
  { abbr: 'PNL',   seats: 49, color: '#f5a623', wing: 'Centru-Dreapta',  ideology: 'Liberal-conservatorism', spectrumPct: 68 },
  { abbr: 'USR',   seats: 40, color: '#3db5e0', wing: 'Centru',          ideology: 'Liberalism',           spectrumPct: 48 },
  { abbr: 'SOS',   seats: 28, color: '#7b2d8b', wing: 'Dreapta Extremă', ideology: 'Euroscepticism',       spectrumPct: 96 },
  { abbr: 'POT',   seats: 24, color: '#e07b3d', wing: 'Dreapta',         ideology: 'Populism',             spectrumPct: 78 },
  { abbr: 'RMDSZ', seats: 22, color: '#2d8b5a', wing: 'Centru-Dreapta',  ideology: 'Minoritate Maghiară',  spectrumPct: 60 },
];

/* ---- HEMICYCLE ---- */
(function() {
  const cx = 250, cy = 255, r = 220;
  const startAngle = Math.PI;      // 180° = left end
  const endAngle   = 0;            // 0°   = right end (sweep left→right)
  const totalSeats = parties.reduce((s,p) => s+p.seats, 0);
  const arcsEl = document.getElementById('arcs');

  let currentAngle = Math.PI; // start from left

  parties.forEach(p => {
    const fraction = p.seats / totalSeats;
    const sweep = Math.PI * fraction; // portion of the half-circle
    const nextAngle = currentAngle - sweep;

    const x1 = cx + r * Math.cos(currentAngle);
    const y1 = cy + r * Math.sin(currentAngle);
    const x2 = cx + r * Math.cos(nextAngle);
    const y2 = cy + r * Math.sin(nextAngle);

    const largeArc = sweep > Math.PI ? 1 : 0;

    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', `M ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 0 ${x2} ${y2}`);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', p.color);
    path.setAttribute('stroke-width', '52');
    path.setAttribute('stroke-linecap', 'butt');
    path.setAttribute('filter', 'url(#glow)');
    path.setAttribute('opacity', '0.9');
    arcsEl.appendChild(path);

    // midpoint label
    const midAngle = (currentAngle + nextAngle) / 2;
    const lr = r; // on the arc
    const mx = cx + lr * Math.cos(midAngle);
    const my = cy + lr * Math.sin(midAngle);

    if (fraction > 0.06) {
      const txt = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      txt.setAttribute('x', mx);
      txt.setAttribute('y', my + 4);
      txt.setAttribute('text-anchor', 'middle');
      txt.setAttribute('font-family', "'Playfair Display',serif");
      txt.setAttribute('font-size', '11');
      txt.setAttribute('font-weight', '700');
      txt.setAttribute('fill', '#fff');
      txt.textContent = p.abbr;
      arcsEl.appendChild(txt);
    }

    currentAngle = nextAngle;
  });
})();

/* ---- SPECTRUM DOTS ---- */
(function() {
  const container = document.getElementById('spectrumDots');
  parties.forEach(p => {
    const dot = document.createElement('div');
    dot.className = 'sdot';
    dot.style.left = p.spectrumPct + '%';
    dot.innerHTML = `
      <div class="sdot-circle" style="background:${p.color}"></div>
      <span class="sdot-label">${p.abbr}</span>
    `;
    container.appendChild(dot);
  });
})();

/* ---- CARDS ---- */
(function() {
  const container = document.getElementById('cards');
  const total = parties.reduce((s,p) => s+p.seats, 0);
  parties.forEach(p => {
    const pct = ((p.seats / total) * 100).toFixed(1);
    const card = document.createElement('div');
    card.className = 'card';
    card.style.setProperty('--accent', p.color);
    card.innerHTML = `
      <div class="card-acronym">${p.abbr}</div>
      <div class="card-seats">${p.seats}<span>locuri</span></div>
      <div class="card-pct">${pct}% din total</div>
      <div class="card-wing">${p.wing}</div>
      <div class="card-ideology">${p.ideology}</div>
      <div class="bar-bg"><div class="bar-fill" style="width:${pct}%"></div></div>
    `;
    container.appendChild(card);
  });
})();
</script>
</body>
</html>

```


<!-- 112 | Chess PGN analysis script with statistics | bash -->
```bash
# Analyse the current folder (and subfolders)
python pgn_analyzer.py

# Or point it at a specific folder
python pgn_analyzer.py /path/to/your/pgn/files
```


<!-- 113 | Chess PGN analysis script with statistics | py -->
```py
#!/usr/bin/env python3
"""
Chess PGN Analyzer
==================
Scans the current directory (and subdirectories) for .pgn files and produces
a detailed statistical report covering:
  - Most common event types
  - Most mentioned player
  - Win rates by ELO range (white vs black vs draw)
  - Highest ELO ever recorded
  - Most played opening per ELO range
  - Most played variation per ELO range
  - Time control distribution
  - Game termination types
  - Website distribution
  - Day vs Night play distribution
"""

import os
import re
import sys
from collections import defaultdict, Counter
from pathlib import Path
from datetime import datetime

# ---------------------------------------------------------------------------
# ELO ranges
# ---------------------------------------------------------------------------
ELO_RANGES = [
    (0,    100,  "0-100"),
    (100,  200,  "100-200"),
    (200,  300,  "200-300"),
    (300,  400,  "300-400"),
    (400,  500,  "400-500"),
    (500,  600,  "500-600"),
    (600,  700,  "600-700"),
    (700,  800,  "700-800"),
    (800,  900,  "800-900"),
    (900,  1000, "900-1000"),
    (1000, 1100, "1000-1100"),
    (1100, 1200, "1100-1200"),
    (1200, 1300, "1200-1300"),
    (1300, 1400, "1300-1400"),
    (1400, 1500, "1400-1500"),
    (1500, 1600, "1500-1600"),
    (1600, 1700, "1600-1700"),
    (1700, 1800, "1700-1800"),
    (1800, 1900, "1800-1900"),
    (1900, 2000, "1900-2000"),
    (2000, 99999,"2000+"),
]

def elo_bucket(elo: int) -> str:
    for lo, hi, label in ELO_RANGES:
        if lo <= elo < hi:
            return label
    return "2000+"

# ---------------------------------------------------------------------------
# PGN parser (no external dependencies)
# ---------------------------------------------------------------------------
TAG_RE = re.compile(r'\[(\w+)\s+"([^"]*)"\]')

def parse_pgn_file(filepath: str):
    """
    Yields one dict per game found in the PGN file.
    Each dict contains lowercased tag names as keys plus a 'moves' key.
    """
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    # Split on double-newline sequences that separate tag blocks
    # Strategy: split file into games by finding lines that start with [Event
    games_raw = re.split(r'\n(?=\[Event )', content)

    for raw in games_raw:
        if not raw.strip():
            continue
        tags = {}
        for m in TAG_RE.finditer(raw):
            tags[m.group(1).lower()] = m.group(2)
        if not tags:
            continue
        # Extract moves (everything after the last tag line)
        lines = raw.splitlines()
        move_lines = [l for l in lines if l and not l.startswith("[")]
        tags["moves"] = " ".join(move_lines).strip()
        yield tags

def find_pgn_files(root: str = "."):
    """Recursively find all .pgn files under root."""
    return list(Path(root).rglob("*.pgn"))

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def safe_int(value: str, default: int = -1) -> int:
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def detect_website(site: str, link: str) -> str:
    combined = (site + " " + link).lower()
    if "lichess" in combined:
        return "lichess.org"
    if "chess.com" in combined:
        return "chess.com"
    if combined.strip():
        # Try to extract domain
        m = re.search(r'([\w-]+\.\w+)', combined)
        if m:
            return m.group(1)
    return "Unknown"

def detect_termination(termination: str, result: str) -> str:
    t = (termination or "").lower()
    if "checkmate" in t or "mate" in t:
        return "Checkmate"
    if "time" in t or "forfeit" in t:
        return "Time forfeit"
    if "resign" in t:
        return "Resignation"
    if "draw" in t or "stalemate" in t or "repetition" in t or "insufficient" in t or "agreement" in t:
        return "Draw"
    if "abandon" in t:
        return "Abandoned"
    # Infer from result
    if result == "1/2-1/2":
        return "Draw"
    return "Other / Unknown"

def hour_from_time_tag(utctime: str) -> int | None:
    """Parse HH:MM:SS or HH:MM and return the hour."""
    m = re.match(r'(\d{1,2}):', utctime or "")
    if m:
        return int(m.group(1))
    return None

def is_night(hour: int) -> bool:
    """Night = 22:00-08:00 UTC."""
    return hour >= 22 or hour < 8

# ---------------------------------------------------------------------------
# Main analysis
# ---------------------------------------------------------------------------
def analyse(root: str = "."):
    pgn_files = find_pgn_files(root)
    if not pgn_files:
        print("❌  No .pgn files found under:", os.path.abspath(root))
        sys.exit(1)

    print(f"🔍  Found {len(pgn_files)} PGN file(s). Parsing...\n")

    # Accumulators
    total_games = 0
    event_counter        = Counter()
    player_counter       = Counter()
    website_counter      = Counter()
    termination_counter  = Counter()
    time_control_counter = Counter()
    day_night_counter    = Counter()

    highest_elo          = -1
    highest_elo_player   = "Unknown"

    # Per ELO-range: wins/draws
    range_results = {label: {"white": 0, "black": 0, "draw": 0, "total": 0}
                     for *_, label in ELO_RANGES}

    # Per ELO-range: opening counters  (label -> Counter of opening names)
    range_openings    = {label: Counter() for *_, label in ELO_RANGES}
    # Per ELO-range: variation counters (label -> Counter of ECO+variation)
    range_variations  = {label: Counter() for *_, label in ELO_RANGES}

    for pgn_path in pgn_files:
        for game in parse_pgn_file(str(pgn_path)):
            total_games += 1

            # --- Event ---
            event = game.get("event", "").strip() or "Unknown"
            event_counter[event] += 1

            # --- Players ---
            white = game.get("white", "").strip()
            black = game.get("black", "").strip()
            if white:
                player_counter[white] += 1
            if black:
                player_counter[black] += 1

            # --- ELOs ---
            white_elo = safe_int(game.get("whiteelo", "-1"))
            black_elo = safe_int(game.get("blackelo", "-1"))

            for elo, name in [(white_elo, white), (black_elo, black)]:
                if elo > highest_elo:
                    highest_elo = elo
                    highest_elo_player = name or "Unknown"

            # Use average ELO of the two players to bucket the game
            valid_elos = [e for e in [white_elo, black_elo] if e > 0]
            avg_elo = int(sum(valid_elos) / len(valid_elos)) if valid_elos else -1
            bucket = elo_bucket(avg_elo) if avg_elo >= 0 else None

            # --- Result ---
            result = game.get("result", "").strip()
            if bucket:
                r = range_results[bucket]
                r["total"] += 1
                if result == "1-0":
                    r["white"] += 1
                elif result == "0-1":
                    r["black"] += 1
                elif result == "1/2-1/2":
                    r["draw"] += 1

            # --- Opening / Variation ---
            opening   = game.get("opening",   "").strip()
            variation = game.get("variation", "").strip()
            eco       = game.get("eco",       "").strip()

            if bucket and opening:
                range_openings[bucket][opening] += 1
                full_var = f"{opening}: {variation}" if variation else opening
                range_variations[bucket][full_var] += 1

            # --- Time control ---
            tc = game.get("timecontrol", "").strip() or "Unknown"
            time_control_counter[tc] += 1

            # --- Termination ---
            termination_raw = game.get("termination", "").strip()
            term_label = detect_termination(termination_raw, result)
            termination_counter[term_label] += 1

            # --- Website ---
            site = game.get("site", "")
            link = game.get("link", "")
            website_counter[detect_website(site, link)] += 1

            # --- Time of day ---
            utctime = game.get("utctime", "").strip()
            if utctime:
                h = hour_from_time_tag(utctime)
                if h is not None:
                    day_night_counter["Night" if is_night(h) else "Day"] += 1

    # ---------------------------------------------------------------------------
    # Report
    # ---------------------------------------------------------------------------
    sep  = "=" * 70
    sep2 = "-" * 70

    def pct(n, total):
        return f"{n/total*100:.1f}%" if total else "N/A"

    print(sep)
    print("  ♟  CHESS PGN ANALYSIS REPORT")
    print(sep)
    print(f"  Total games analysed : {total_games:,}")
    print(f"  PGN files scanned    : {len(pgn_files)}")
    print()

    # 1. Event types
    print(sep2)
    print("  1. MOST PLAYED EVENT TYPES")
    print(sep2)
    for event, count in event_counter.most_common(10):
        print(f"  {count:>7,}  ({pct(count, total_games):>6})  {event}")
    print()

    # 2. Most mentioned player
    print(sep2)
    print("  2. MOST MENTIONED PLAYER")
    print(sep2)
    top_player, top_count = player_counter.most_common(1)[0] if player_counter else ("N/A", 0)
    print(f"  {top_player}  —  mentioned in {top_count:,} game(s)")
    print()
    print("  Top 10 players:")
    for p, c in player_counter.most_common(10):
        print(f"    {c:>7,}  {p}")
    print()

    # 3. Win rates by ELO range
    print(sep2)
    print("  3. WIN RATES BY ELO RANGE  (average ELO of both players)")
    print(sep2)
    print(f"  {'Range':<12}  {'Games':>7}  {'White':>8}  {'Black':>8}  {'Draw':>8}")
    print(f"  {'-'*12}  {'-'*7}  {'-'*8}  {'-'*8}  {'-'*8}")
    for *_, label in ELO_RANGES:
        r = range_results[label]
        t = r["total"]
        if t == 0:
            continue
        print(f"  {label:<12}  {t:>7,}  {pct(r['white'],t):>8}  {pct(r['black'],t):>8}  {pct(r['draw'],t):>8}")
    print()

    # 4. Highest ELO recorded
    print(sep2)
    print("  4. HIGHEST ELO EVER RECORDED")
    print(sep2)
    if highest_elo > 0:
        print(f"  {highest_elo_player}  —  ELO {highest_elo}")
    else:
        print("  No ELO data found.")
    print()

    # 5. Most played opening per ELO range
    print(sep2)
    print("  5. MOST PLAYED OPENING PER ELO RANGE")
    print(sep2)
    for *_, label in ELO_RANGES:
        c = range_openings[label]
        if not c:
            continue
        top_op, top_op_count = c.most_common(1)[0]
        total_range = range_results[label]["total"]
        print(f"  {label:<12}  ▶  {top_op}  ({top_op_count:,} games, {pct(top_op_count, total_range)})")
        # List all openings in this range
        all_ops = c.most_common()
        if len(all_ops) > 1:
            others = ", ".join(f"{op} ×{n}" for op, n in all_ops[1:])
            # Wrap at 80 chars
            for chunk in [others[i:i+80] for i in range(0, len(others), 80)]:
                print(f"              {chunk}")
        print()

    # 6. Most played variation per ELO range
    print(sep2)
    print("  6. MOST PLAYED VARIATION PER ELO RANGE")
    print(sep2)
    for *_, label in ELO_RANGES:
        c = range_variations[label]
        if not c:
            continue
        top_var, top_var_count = c.most_common(1)[0]
        total_range = range_results[label]["total"]
        print(f"  {label:<12}  ▶  {top_var}  ({top_var_count:,} games, {pct(top_var_count, total_range)})")
        all_vars = c.most_common()
        if len(all_vars) > 1:
            others = ", ".join(f"{v} ×{n}" for v, n in all_vars[1:])
            for chunk in [others[i:i+80] for i in range(0, len(others), 80)]:
                print(f"              {chunk}")
        print()

    # 7. Time controls
    print(sep2)
    print("  7. TIME CONTROL DISTRIBUTION")
    print(sep2)
    for tc, count in time_control_counter.most_common():
        print(f"  {count:>7,}  ({pct(count, total_games):>6})  {tc}")
    print()

    # 8. Termination types
    print(sep2)
    print("  8. HOW GAMES ENDED (TERMINATION)")
    print(sep2)
    for term, count in termination_counter.most_common():
        print(f"  {count:>7,}  ({pct(count, total_games):>6})  {term}")
    print()

    # 9. Website distribution
    print(sep2)
    print("  9. WEBSITE DISTRIBUTION")
    print(sep2)
    for site, count in website_counter.most_common():
        print(f"  {count:>7,}  ({pct(count, total_games):>6})  {site}")
    print()

    # 10. Day / Night
    print(sep2)
    print("  10. TIME OF DAY  (UTC — Night: 22:00-08:00 / Day: 08:00-22:00)")
    print(sep2)
    dn_total = sum(day_night_counter.values())
    if dn_total:
        for label in ["Night", "Day"]:
            count = day_night_counter.get(label, 0)
            print(f"  {label:<6}  {count:>7,}  ({pct(count, dn_total):>6})")
    else:
        print("  No UTCTime tags found in the PGN files.")
    print()

    print(sep)
    print("  ✅  Analysis complete.")
    print(sep)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    search_root = sys.argv[1] if len(sys.argv) > 1 else "."
    print(f"\n📂  Searching for .pgn files in: {os.path.abspath(search_root)}\n")
    analyse(search_root)

```


<!-- 114 | Chess PGN analysis script with statistics | bash -->
```bash
python pgn_analyzer_fast.py file1.pgn file2.pgn file3.pgn
```


<!-- 115 | Chess PGN analysis script with statistics | bash -->
```bash
python pgn_analyzer_fast.py /path/to/folder
```


<!-- 116 | Chess PGN analysis script with statistics | bash -->
```bash
# If you get a "spawn" error, try:
python pgn_analyzer_fast.py file1.pgn file2.pgn file3.pgn
# It should still work — mp.freeze_support() is already included
```


<!-- 117 | Chess PGN analysis script with statistics | py -->
```py
#!/usr/bin/env python3
"""
Chess PGN Analyzer — Fast Edition
===================================
Uses the `chess` library for fast PGN parsing and Python multiprocessing
to spread work across all available CPU cores.

Usage:
    python pgn_analyzer_fast.py                    # scans current folder
    python pgn_analyzer_fast.py /path/to/pgns      # scans given folder
    python pgn_analyzer_fast.py a.pgn b.pgn c.pgn  # specific files

Each file is assigned to its own worker process. Results are merged at the end.
"""

import os
import re
import sys
import io
import time
import multiprocessing as mp
from collections import Counter
from pathlib import Path

try:
    import chess.pgn
except ImportError:
    print("❌  The 'chess' library is not installed.")
    print("    Run:  pip install chess")
    sys.exit(1)

# ---------------------------------------------------------------------------
# ELO ranges
# ---------------------------------------------------------------------------
ELO_RANGES = [
    (0,     100,  "0-100"),
    (100,   200,  "100-200"),
    (200,   300,  "200-300"),
    (300,   400,  "300-400"),
    (400,   500,  "400-500"),
    (500,   600,  "500-600"),
    (600,   700,  "600-700"),
    (700,   800,  "700-800"),
    (800,   900,  "800-900"),
    (900,   1000, "900-1000"),
    (1000,  1100, "1000-1100"),
    (1100,  1200, "1100-1200"),
    (1200,  1300, "1200-1300"),
    (1300,  1400, "1300-1400"),
    (1400,  1500, "1400-1500"),
    (1500,  1600, "1500-1600"),
    (1600,  1700, "1600-1700"),
    (1700,  1800, "1700-1800"),
    (1800,  1900, "1800-1900"),
    (1900,  2000, "1900-2000"),
    (2000,  99999,"2000+"),
]
RANGE_LABELS = [label for *_, label in ELO_RANGES]

def elo_bucket(elo: int) -> str:
    for lo, hi, label in ELO_RANGES:
        if lo <= elo < hi:
            return label
    return "2000+"

# ---------------------------------------------------------------------------
# Empty stats skeleton (plain dicts — picklable for multiprocessing)
# ---------------------------------------------------------------------------
def empty_stats() -> dict:
    return {
        "total":            0,
        "events":           {},   # Counter-like dict
        "players":          {},
        "websites":         {},
        "terminations":     {},
        "time_controls":    {},
        "day_night":        {},
        "highest_elo":      -1,
        "highest_elo_player": "Unknown",
        # per ELO range dicts-of-dicts
        "range_results":    {lbl: {"white": 0, "black": 0, "draw": 0, "total": 0} for lbl in RANGE_LABELS},
        "range_openings":   {lbl: {} for lbl in RANGE_LABELS},
        "range_variations": {lbl: {} for lbl in RANGE_LABELS},
    }

def inc(d: dict, key: str, n: int = 1):
    d[key] = d.get(key, 0) + n

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def safe_int(value, default: int = -1) -> int:
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def detect_website(site: str) -> str:
    s = (site or "").lower()
    if "lichess" in s:
        return "lichess.org"
    if "chess.com" in s:
        return "chess.com"
    if s.strip():
        m = re.search(r'([\w-]+\.\w+)', s)
        if m:
            return m.group(1)
    return "Unknown"

def detect_termination(termination: str, result: str) -> str:
    t = (termination or "").lower()
    if "checkmate" in t or "mate" in t:
        return "Checkmate"
    if "time" in t or "forfeit" in t:
        return "Time forfeit"
    if "resign" in t:
        return "Resignation"
    if "draw" in t or "stalemate" in t or "repetition" in t or "insufficient" in t or "agreement" in t:
        return "Draw"
    if "abandon" in t:
        return "Abandoned"
    if result == "1/2-1/2":
        return "Draw"
    return "Other / Unknown"

def is_night(hour: int) -> bool:
    return hour >= 22 or hour < 8

# ---------------------------------------------------------------------------
# Worker: process one PGN file, return stats dict
# ---------------------------------------------------------------------------
def process_file(args):
    filepath, worker_id, total_workers = args
    stats = empty_stats()
    filesize = os.path.getsize(filepath)

    print(f"  [Worker {worker_id}/{total_workers}] Starting → {Path(filepath).name}  "
          f"({filesize / 1_000_000:.1f} MB)", flush=True)

    progress_every = 50_000   # print a progress line every N games
    last_time = time.time()

    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        while True:
            try:
                game = chess.pgn.read_game(f)
            except Exception:
                continue
            if game is None:
                break

            stats["total"] += 1
            h = game.headers

            # --- Event ---
            event = h.get("Event", "Unknown").strip() or "Unknown"
            inc(stats["events"], event)

            # --- Players ---
            white = h.get("White", "").strip()
            black = h.get("Black", "").strip()
            if white:
                inc(stats["players"], white)
            if black:
                inc(stats["players"], black)

            # --- ELOs ---
            white_elo = safe_int(h.get("WhiteElo", ""))
            black_elo = safe_int(h.get("BlackElo", ""))

            for elo, name in [(white_elo, white), (black_elo, black)]:
                if elo > stats["highest_elo"]:
                    stats["highest_elo"] = elo
                    stats["highest_elo_player"] = name or "Unknown"

            valid_elos = [e for e in [white_elo, black_elo] if e > 0]
            avg_elo = int(sum(valid_elos) / len(valid_elos)) if valid_elos else -1
            bucket = elo_bucket(avg_elo) if avg_elo >= 0 else None

            # --- Result ---
            result = h.get("Result", "").strip()
            if bucket:
                r = stats["range_results"][bucket]
                r["total"] += 1
                if result == "1-0":
                    r["white"] += 1
                elif result == "0-1":
                    r["black"] += 1
                elif result == "1/2-1/2":
                    r["draw"] += 1

            # --- Opening / Variation ---
            opening   = h.get("Opening",   "").strip()
            variation = h.get("Variation",  "").strip()

            if bucket and opening:
                inc(stats["range_openings"][bucket],   opening)
                full_var = f"{opening}: {variation}" if variation else opening
                inc(stats["range_variations"][bucket], full_var)

            # --- Time control ---
            tc = h.get("TimeControl", "").strip() or "Unknown"
            inc(stats["time_controls"], tc)

            # --- Termination ---
            term_raw = h.get("Termination", "").strip()
            inc(stats["terminations"], detect_termination(term_raw, result))

            # --- Website ---
            inc(stats["websites"], detect_website(h.get("Site", "")))

            # --- Day / Night ---
            utctime = h.get("UTCTime", "").strip()
            if utctime:
                m = re.match(r'(\d{1,2}):', utctime)
                if m:
                    hour = int(m.group(1))
                    inc(stats["day_night"], "Night" if is_night(hour) else "Day")

            # --- Progress ---
            if stats["total"] % progress_every == 0:
                elapsed = time.time() - last_time
                rate = progress_every / elapsed if elapsed else 0
                print(f"  [Worker {worker_id}] {stats['total']:,} games  "
                      f"({rate:,.0f} games/s)", flush=True)
                last_time = time.time()

    print(f"  [Worker {worker_id}] ✅ Done — {stats['total']:,} games parsed", flush=True)
    return stats

# ---------------------------------------------------------------------------
# Merge stats from multiple workers
# ---------------------------------------------------------------------------
def merge_stats(all_stats: list) -> dict:
    merged = empty_stats()

    for s in all_stats:
        merged["total"] += s["total"]

        for key in ("events", "players", "websites", "terminations", "time_controls", "day_night"):
            for k, v in s[key].items():
                merged[key][k] = merged[key].get(k, 0) + v

        if s["highest_elo"] > merged["highest_elo"]:
            merged["highest_elo"] = s["highest_elo"]
            merged["highest_elo_player"] = s["highest_elo_player"]

        for lbl in RANGE_LABELS:
            sr = s["range_results"][lbl]
            mr = merged["range_results"][lbl]
            for k in ("white", "black", "draw", "total"):
                mr[k] += sr[k]

            for op, cnt in s["range_openings"][lbl].items():
                merged["range_openings"][lbl][op] = \
                    merged["range_openings"][lbl].get(op, 0) + cnt

            for var, cnt in s["range_variations"][lbl].items():
                merged["range_variations"][lbl][var] = \
                    merged["range_variations"][lbl].get(var, 0) + cnt

    return merged

# ---------------------------------------------------------------------------
# Report printer
# ---------------------------------------------------------------------------
def print_report(stats: dict, num_files: int, elapsed: float):
    total = stats["total"]
    sep  = "=" * 72
    sep2 = "-" * 72

    def pct(n, t):
        return f"{n / t * 100:.1f}%" if t else "N/A"

    def top_n(d: dict, n: int = 10):
        return sorted(d.items(), key=lambda x: x[1], reverse=True)[:n]

    print()
    print(sep)
    print("  ♟  CHESS PGN ANALYSIS REPORT")
    print(sep)
    print(f"  Total games analysed : {total:,}")
    print(f"  PGN files scanned    : {num_files}")
    print(f"  Time taken           : {elapsed:.1f}s")
    if elapsed > 0:
        print(f"  Parse speed          : {total / elapsed:,.0f} games/s")
    print()

    # 1. Event types
    print(sep2)
    print("  1. MOST PLAYED EVENT TYPES")
    print(sep2)
    for event, count in top_n(stats["events"]):
        print(f"  {count:>8,}  ({pct(count, total):>6})  {event}")
    print()

    # 2. Most mentioned player
    print(sep2)
    print("  2. MOST MENTIONED PLAYER")
    print(sep2)
    players_sorted = sorted(stats["players"].items(), key=lambda x: x[1], reverse=True)
    if players_sorted:
        top_p, top_c = players_sorted[0]
        print(f"  ▶  {top_p}  —  {top_c:,} appearance(s)")
        print()
        print("  Top 10 players:")
        for p, c in players_sorted[:10]:
            print(f"    {c:>8,}  {p}")
    print()

    # 3. Win rates by ELO range
    print(sep2)
    print("  3. WIN RATES BY ELO RANGE  (avg ELO of both players)")
    print(sep2)
    print(f"  {'Range':<12}  {'Games':>8}  {'White':>8}  {'Black':>8}  {'Draw':>8}")
    print(f"  {'-'*12}  {'-'*8}  {'-'*8}  {'-'*8}  {'-'*8}")
    for lbl in RANGE_LABELS:
        r = stats["range_results"][lbl]
        t = r["total"]
        if t == 0:
            continue
        print(f"  {lbl:<12}  {t:>8,}  {pct(r['white'],t):>8}  "
              f"{pct(r['black'],t):>8}  {pct(r['draw'],t):>8}")
    print()

    # 4. Highest ELO
    print(sep2)
    print("  4. HIGHEST ELO EVER RECORDED")
    print(sep2)
    if stats["highest_elo"] > 0:
        print(f"  {stats['highest_elo_player']}  —  ELO {stats['highest_elo']}")
    else:
        print("  No ELO data found.")
    print()

    # 5. Most played opening per ELO range
    print(sep2)
    print("  5. MOST PLAYED OPENING PER ELO RANGE")
    print(sep2)
    for lbl in RANGE_LABELS:
        ops = stats["range_openings"][lbl]
        if not ops:
            continue
        sorted_ops = sorted(ops.items(), key=lambda x: x[1], reverse=True)
        top_op, top_cnt = sorted_ops[0]
        total_range = stats["range_results"][lbl]["total"]
        print(f"  {lbl:<12}  ▶  {top_op}  ({top_cnt:,} games, {pct(top_cnt, total_range)})")
        if len(sorted_ops) > 1:
            all_list = "  All: " + " | ".join(
                f"{op} ×{n}" for op, n in sorted_ops
            )
            # word-wrap at 80 chars
            words = all_list.split(" | ")
            line = ""
            for w in words:
                if len(line) + len(w) > 78:
                    print(f"        {line.rstrip(' |')}")
                    line = w + " | "
                else:
                    line += w + " | "
            if line.strip(" |"):
                print(f"        {line.rstrip(' |')}")
        print()

    # 6. Most played variation per ELO range
    print(sep2)
    print("  6. MOST PLAYED VARIATION PER ELO RANGE")
    print(sep2)
    for lbl in RANGE_LABELS:
        vars_ = stats["range_variations"][lbl]
        if not vars_:
            continue
        sorted_vars = sorted(vars_.items(), key=lambda x: x[1], reverse=True)
        top_var, top_cnt = sorted_vars[0]
        total_range = stats["range_results"][lbl]["total"]
        print(f"  {lbl:<12}  ▶  {top_var}  ({top_cnt:,} games, {pct(top_cnt, total_range)})")
        if len(sorted_vars) > 1:
            all_list = " | ".join(f"{v} ×{n}" for v, n in sorted_vars)
            words = all_list.split(" | ")
            line = "  All: "
            for w in words:
                if len(line) + len(w) > 78:
                    print(f"        {line.rstrip(' |')}")
                    line = w + " | "
                else:
                    line += w + " | "
            if line.strip(" |"):
                print(f"        {line.rstrip(' |')}")
        print()

    # 7. Time controls
    print(sep2)
    print("  7. TIME CONTROL DISTRIBUTION")
    print(sep2)
    for tc, count in top_n(stats["time_controls"], 20):
        print(f"  {count:>8,}  ({pct(count, total):>6})  {tc}")
    print()

    # 8. Terminations
    print(sep2)
    print("  8. HOW GAMES ENDED")
    print(sep2)
    for term, count in top_n(stats["terminations"], 20):
        print(f"  {count:>8,}  ({pct(count, total):>6})  {term}")
    print()

    # 9. Websites
    print(sep2)
    print("  9. WEBSITE DISTRIBUTION")
    print(sep2)
    for site, count in top_n(stats["websites"]):
        print(f"  {count:>8,}  ({pct(count, total):>6})  {site}")
    print()

    # 10. Day / Night
    print(sep2)
    print("  10. TIME OF DAY  (UTC — Night: 22:00-08:00 / Day: 08:00-22:00)")
    print(sep2)
    dn = stats["day_night"]
    dn_total = sum(dn.values())
    if dn_total:
        for label in ["Night", "Day"]:
            count = dn.get(label, 0)
            print(f"  {label:<6}  {count:>8,}  ({pct(count, dn_total):>6})")
    else:
        print("  No UTCTime tags found in these PGN files.")
    print()

    print(sep)
    print("  ✅  Analysis complete.")
    print(sep)

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main():
    args = sys.argv[1:]

    # Determine list of PGN files
    if args:
        # Check if args are files or a directory
        pgn_files = []
        for a in args:
            p = Path(a)
            if p.is_file() and p.suffix.lower() == ".pgn":
                pgn_files.append(str(p))
            elif p.is_dir():
                pgn_files.extend(str(f) for f in p.rglob("*.pgn"))
            else:
                print(f"⚠️  Skipping (not a .pgn file or directory): {a}")
    else:
        pgn_files = [str(f) for f in Path(".").rglob("*.pgn")]

    if not pgn_files:
        print("❌  No .pgn files found.")
        sys.exit(1)

    num_files = len(pgn_files)
    total_size_mb = sum(os.path.getsize(f) for f in pgn_files) / 1_000_000

    # How many workers? Min(num_files × 1, cpu_count, 8)
    # Each file gets its own process; extras do nothing so cap at file count
    cpu_count = mp.cpu_count()
    num_workers = min(num_files, cpu_count, 8)

    print(f"\n📂  Found {num_files} PGN file(s)  ({total_size_mb:,.1f} MB total)")
    print(f"⚙️   Using {num_workers} worker process(es)  ({cpu_count} CPUs available)")
    print()

    # Build work items — distribute files across workers
    # If more files than workers, multiple files can go to same worker,
    # but here we just assign one process per file (up to 8).
    # For >8 files we batch them.
    work_items = [
        (filepath, i + 1, num_files)
        for i, filepath in enumerate(pgn_files)
    ]

    t_start = time.time()

    if num_workers == 1:
        # Single-process path (avoids mp overhead)
        all_stats = [process_file(work_items[0])]
    else:
        with mp.Pool(processes=num_workers) as pool:
            all_stats = pool.map(process_file, work_items)

    t_end = time.time()
    elapsed = t_end - t_start

    print("\n🔀  Merging results from all workers...")
    merged = merge_stats(all_stats)

    print_report(merged, num_files, elapsed)

    # Optionally save report to file
    report_path = "pgn_report.txt"
    try:
        import io as _io
        old_stdout = sys.stdout
        sys.stdout = buf = _io.StringIO()
        print_report(merged, num_files, elapsed)
        sys.stdout = old_stdout
        with open(report_path, "w", encoding="utf-8") as rf:
            rf.write(buf.getvalue())
        print(f"\n📄  Report also saved to: {report_path}")
    except Exception:
        pass  # stdout redirect failed, no big deal


if __name__ == "__main__":
    # Required on Windows / some Android environments
    mp.freeze_support()
    main()

```


<!-- 118 | Chess PGN analysis script with statistics | txt -->
```txt
  [Worker 1] 50,000 games  (1,200 games/s)
  [Worker 2] 50,000 games  (1,100 games/s)
  ...
```


<!-- 119 | Chess PGN analysis script with statistics | bash -->
```bash
python pgn_analyzer_ultrafast.py file1.pgn file2.pgn file3.pgn
```


<!-- 120 | Chess PGN analysis script with statistics | py -->
```py
#!/usr/bin/env python3
"""
Chess PGN Analyzer — Ultra Fast Edition
========================================
Splits each PGN file into chunks and distributes ALL chunks across all 8 CPU
cores, with large read buffers to minimize I/O stalls.

Strategy:
  1. Scan each file for game boundaries (lines starting with "[Event ")
  2. Split into N byte-range chunks (one per CPU core)
  3. Each worker reads its chunk with a large buffer, parses with chess.pgn
  4. Merge all results and print report

Usage:
    python pgn_analyzer_ultrafast.py                    # scans current folder
    python pgn_analyzer_ultrafast.py /path/to/pgns      # scans given folder
    python pgn_analyzer_ultrafast.py a.pgn b.pgn c.pgn  # specific files
"""

import os
import re
import sys
import time
import multiprocessing as mp
from pathlib import Path
from io import BufferedReader, RawIOBase

try:
    import chess.pgn
except ImportError:
    print("❌  The 'chess' library is not installed.  Run:  pip install chess")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
READ_BUFFER_BYTES = 8 * 1024 * 1024   # 8 MB read buffer per worker
PROGRESS_EVERY    = 25_000             # print progress every N games

# ---------------------------------------------------------------------------
# ELO ranges
# ---------------------------------------------------------------------------
ELO_RANGES = [
    (0,     100,  "0-100"),
    (100,   200,  "100-200"),
    (200,   300,  "200-300"),
    (300,   400,  "300-400"),
    (400,   500,  "400-500"),
    (500,   600,  "500-600"),
    (600,   700,  "600-700"),
    (700,   800,  "700-800"),
    (800,   900,  "800-900"),
    (900,   1000, "900-1000"),
    (1000,  1100, "1000-1100"),
    (1100,  1200, "1100-1200"),
    (1200,  1300, "1200-1300"),
    (1300,  1400, "1300-1400"),
    (1400,  1500, "1400-1500"),
    (1500,  1600, "1500-1600"),
    (1600,  1700, "1600-1700"),
    (1700,  1800, "1700-1800"),
    (1800,  1900, "1800-1900"),
    (1900,  2000, "1900-2000"),
    (2000,  99999,"2000+"),
]
RANGE_LABELS = [label for *_, label in ELO_RANGES]

def elo_bucket(elo: int) -> str:
    for lo, hi, label in ELO_RANGES:
        if lo <= elo < hi:
            return label
    return "2000+"

# ---------------------------------------------------------------------------
# Stats helpers
# ---------------------------------------------------------------------------
def empty_stats() -> dict:
    return {
        "total":              0,
        "events":             {},
        "players":            {},
        "websites":           {},
        "terminations":       {},
        "time_controls":      {},
        "day_night":          {},
        "highest_elo":        -1,
        "highest_elo_player": "Unknown",
        "range_results":      {lbl: {"white": 0, "black": 0, "draw": 0, "total": 0} for lbl in RANGE_LABELS},
        "range_openings":     {lbl: {} for lbl in RANGE_LABELS},
        "range_variations":   {lbl: {} for lbl in RANGE_LABELS},
    }

def inc(d: dict, key: str, n: int = 1):
    d[key] = d.get(key, 0) + n

def safe_int(value, default: int = -1) -> int:
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def detect_website(site: str) -> str:
    s = (site or "").lower()
    if "lichess" in s:   return "lichess.org"
    if "chess.com" in s: return "chess.com"
    if s.strip():
        m = re.search(r'([\w-]+\.\w+)', s)
        if m: return m.group(1)
    return "Unknown"

def detect_termination(termination: str, result: str) -> str:
    t = (termination or "").lower()
    if "checkmate" in t or "mate" in t:   return "Checkmate"
    if "time" in t or "forfeit" in t:     return "Time forfeit"
    if "resign" in t:                      return "Resignation"
    if any(x in t for x in ("draw", "stalemate", "repetition",
                              "insufficient", "agreement")): return "Draw"
    if "abandon" in t:                     return "Abandoned"
    if result == "1/2-1/2":               return "Draw"
    return "Other / Unknown"

def is_night(hour: int) -> bool:
    return hour >= 22 or hour < 8

# ---------------------------------------------------------------------------
# File splitter — finds byte offsets of game boundaries
# ---------------------------------------------------------------------------
def find_chunk_offsets(filepath: str, num_chunks: int) -> list[tuple[int, int]]:
    """
    Divide filepath into num_chunks roughly equal byte ranges, each starting
    at a '[Event ' line boundary.
    Returns list of (start_byte, end_byte) pairs; end_byte == -1 means EOF.
    """
    file_size = os.path.getsize(filepath)
    if file_size == 0:
        return []

    approx_chunk = file_size // num_chunks
    offsets = [0]

    with open(filepath, "rb", buffering=READ_BUFFER_BYTES) as f:
        for i in range(1, num_chunks):
            target = i * approx_chunk
            f.seek(target)
            # Advance to the next '[Event ' boundary
            while True:
                line = f.readline()
                if not line:
                    break
                if line.startswith(b"[Event "):
                    offsets.append(f.tell() - len(line))
                    break

    # Build (start, end) pairs
    chunks = []
    for i, start in enumerate(offsets):
        end = offsets[i + 1] if i + 1 < len(offsets) else -1
        chunks.append((start, end))
    return chunks

# ---------------------------------------------------------------------------
# Bounded file wrapper — lets chess.pgn read only a byte slice
# ---------------------------------------------------------------------------
class SlicedFile(RawIOBase):
    """Wraps a file and exposes only bytes [start, end)."""

    def __init__(self, filepath: str, start: int, end: int):
        self._f    = open(filepath, "rb", buffering=READ_BUFFER_BYTES)
        self._end  = end   # -1 = read to EOF
        self._f.seek(start)

    def readable(self):
        return True

    def readinto(self, b):
        if self._end != -1:
            remaining = self._end - self._f.tell()
            if remaining <= 0:
                return 0
            to_read = min(len(b), remaining)
        else:
            to_read = len(b)

        data = self._f.read(to_read)
        n = len(data)
        b[:n] = data
        return n

    def close(self):
        self._f.close()
        super().close()

# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------
def process_chunk(args):
    filepath, start_byte, end_byte, worker_id, total_workers = args
    stats = empty_stats()

    label = f"Worker {worker_id:>2}/{total_workers}"
    chunk_mb = ((end_byte - start_byte) if end_byte != -1
                else os.path.getsize(filepath) - start_byte) / 1_000_000
    print(f"  [{label}] start  offset={start_byte:,}  ~{chunk_mb:.1f} MB", flush=True)

    last_time = time.time()

    raw   = SlicedFile(filepath, start_byte, end_byte)
    buf   = BufferedReader(raw, buffer_size=READ_BUFFER_BYTES)
    text  = __import__("io").TextIOWrapper(buf, encoding="utf-8", errors="replace")

    while True:
        try:
            game = chess.pgn.read_game(text)
        except Exception:
            continue
        if game is None:
            break

        stats["total"] += 1
        h = game.headers

        # Event
        event = h.get("Event", "Unknown").strip() or "Unknown"
        inc(stats["events"], event)

        # Players
        white = h.get("White", "").strip()
        black = h.get("Black", "").strip()
        if white: inc(stats["players"], white)
        if black: inc(stats["players"], black)

        # ELOs
        white_elo = safe_int(h.get("WhiteElo", ""))
        black_elo = safe_int(h.get("BlackElo", ""))

        for elo, name in [(white_elo, white), (black_elo, black)]:
            if elo > stats["highest_elo"]:
                stats["highest_elo"]        = elo
                stats["highest_elo_player"] = name or "Unknown"

        valid_elos = [e for e in [white_elo, black_elo] if e > 0]
        avg_elo    = int(sum(valid_elos) / len(valid_elos)) if valid_elos else -1
        bucket     = elo_bucket(avg_elo) if avg_elo >= 0 else None

        # Result
        result = h.get("Result", "").strip()
        if bucket:
            r = stats["range_results"][bucket]
            r["total"] += 1
            if   result == "1-0":     r["white"] += 1
            elif result == "0-1":     r["black"] += 1
            elif result == "1/2-1/2": r["draw"]  += 1

        # Opening / Variation
        opening   = h.get("Opening",  "").strip()
        variation = h.get("Variation", "").strip()
        if bucket and opening:
            inc(stats["range_openings"][bucket], opening)
            full_var = f"{opening}: {variation}" if variation else opening
            inc(stats["range_variations"][bucket], full_var)

        # Time control
        tc = h.get("TimeControl", "").strip() or "Unknown"
        inc(stats["time_controls"], tc)

        # Termination
        inc(stats["terminations"],
            detect_termination(h.get("Termination", ""), result))

        # Website
        inc(stats["websites"], detect_website(h.get("Site", "")))

        # Day / Night
        utctime = h.get("UTCTime", "").strip()
        if utctime:
            m = re.match(r'(\d{1,2}):', utctime)
            if m:
                hour = int(m.group(1))
                inc(stats["day_night"], "Night" if is_night(hour) else "Day")

        # Progress
        if stats["total"] % PROGRESS_EVERY == 0:
            now     = time.time()
            elapsed = now - last_time
            rate    = PROGRESS_EVERY / elapsed if elapsed else 0
            print(f"  [{label}] {stats['total']:>7,} games  {rate:>6,.0f} g/s", flush=True)
            last_time = now

    text.close()
    print(f"  [{label}] ✅ done — {stats['total']:,} games", flush=True)
    return stats

# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------
def merge_stats(all_stats: list) -> dict:
    merged = empty_stats()
    for s in all_stats:
        merged["total"] += s["total"]
        for key in ("events", "players", "websites", "terminations",
                    "time_controls", "day_night"):
            for k, v in s[key].items():
                merged[key][k] = merged[key].get(k, 0) + v
        if s["highest_elo"] > merged["highest_elo"]:
            merged["highest_elo"]        = s["highest_elo"]
            merged["highest_elo_player"] = s["highest_elo_player"]
        for lbl in RANGE_LABELS:
            mr = merged["range_results"][lbl]
            sr = s["range_results"][lbl]
            for k in ("white", "black", "draw", "total"):
                mr[k] += sr[k]
            for op, cnt in s["range_openings"][lbl].items():
                merged["range_openings"][lbl][op] = \
                    merged["range_openings"][lbl].get(op, 0) + cnt
            for var, cnt in s["range_variations"][lbl].items():
                merged["range_variations"][lbl][var] = \
                    merged["range_variations"][lbl].get(var, 0) + cnt
    return merged

# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------
def print_report(stats: dict, num_files: int, elapsed: float):
    total = stats["total"]
    sep   = "=" * 72
    sep2  = "-" * 72

    def pct(n, t):    return f"{n/t*100:.1f}%" if t else "N/A"
    def top_n(d, n=10): return sorted(d.items(), key=lambda x: x[1], reverse=True)[:n]

    lines = []
    def p(*a, **kw):
        import io as _io
        buf = _io.StringIO()
        print(*a, **kw, file=buf)
        s = buf.getvalue()
        lines.append(s)
        sys.stdout.write(s)

    p()
    p(sep)
    p("  ♟  CHESS PGN ANALYSIS REPORT")
    p(sep)
    p(f"  Total games analysed : {total:,}")
    p(f"  PGN files scanned    : {num_files}")
    p(f"  Time taken           : {elapsed:.1f}s")
    if elapsed > 0:
        p(f"  Parse speed          : {total/elapsed:,.0f} games/s")
    p()

    p(sep2); p("  1. MOST PLAYED EVENT TYPES"); p(sep2)
    for event, count in top_n(stats["events"]):
        p(f"  {count:>8,}  ({pct(count,total):>6})  {event}")
    p()

    p(sep2); p("  2. MOST MENTIONED PLAYER"); p(sep2)
    ps = sorted(stats["players"].items(), key=lambda x: x[1], reverse=True)
    if ps:
        p(f"  ▶  {ps[0][0]}  —  {ps[0][1]:,} appearance(s)")
        p()
        p("  Top 10 players:")
        for name, cnt in ps[:10]:
            p(f"    {cnt:>8,}  {name}")
    p()

    p(sep2); p("  3. WIN RATES BY ELO RANGE  (avg ELO of both players)"); p(sep2)
    p(f"  {'Range':<12}  {'Games':>8}  {'White':>8}  {'Black':>8}  {'Draw':>8}")
    p(f"  {'-'*12}  {'-'*8}  {'-'*8}  {'-'*8}  {'-'*8}")
    for lbl in RANGE_LABELS:
        r = stats["range_results"][lbl]; t = r["total"]
        if t == 0: continue
        p(f"  {lbl:<12}  {t:>8,}  {pct(r['white'],t):>8}  "
          f"{pct(r['black'],t):>8}  {pct(r['draw'],t):>8}")
    p()

    p(sep2); p("  4. HIGHEST ELO EVER RECORDED"); p(sep2)
    if stats["highest_elo"] > 0:
        p(f"  {stats['highest_elo_player']}  —  ELO {stats['highest_elo']}")
    else:
        p("  No ELO data found.")
    p()

    p(sep2); p("  5. MOST PLAYED OPENING PER ELO RANGE"); p(sep2)
    for lbl in RANGE_LABELS:
        ops = stats["range_openings"][lbl]
        if not ops: continue
        sops = sorted(ops.items(), key=lambda x: x[1], reverse=True)
        top_op, top_cnt = sops[0]
        tr = stats["range_results"][lbl]["total"]
        p(f"  {lbl:<12}  ▶  {top_op}  ({top_cnt:,} games, {pct(top_cnt,tr)})")
        if len(sops) > 1:
            all_str = " | ".join(f"{op} ×{n}" for op, n in sops)
            _wrap_print(p, all_str)
        p()

    p(sep2); p("  6. MOST PLAYED VARIATION PER ELO RANGE"); p(sep2)
    for lbl in RANGE_LABELS:
        vs = stats["range_variations"][lbl]
        if not vs: continue
        svs = sorted(vs.items(), key=lambda x: x[1], reverse=True)
        top_v, top_cnt = svs[0]
        tr = stats["range_results"][lbl]["total"]
        p(f"  {lbl:<12}  ▶  {top_v}  ({top_cnt:,} games, {pct(top_cnt,tr)})")
        if len(svs) > 1:
            all_str = " | ".join(f"{v} ×{n}" for v, n in svs)
            _wrap_print(p, all_str)
        p()

    p(sep2); p("  7. TIME CONTROL DISTRIBUTION"); p(sep2)
    for tc, count in top_n(stats["time_controls"], 20):
        p(f"  {count:>8,}  ({pct(count,total):>6})  {tc}")
    p()

    p(sep2); p("  8. HOW GAMES ENDED"); p(sep2)
    for term, count in top_n(stats["terminations"], 20):
        p(f"  {count:>8,}  ({pct(count,total):>6})  {term}")
    p()

    p(sep2); p("  9. WEBSITE DISTRIBUTION"); p(sep2)
    for site, count in top_n(stats["websites"]):
        p(f"  {count:>8,}  ({pct(count,total):>6})  {site}")
    p()

    p(sep2); p("  10. TIME OF DAY  (UTC — Night 22:00-08:00 / Day 08:00-22:00)"); p(sep2)
    dn = stats["day_night"]; dn_total = sum(dn.values())
    if dn_total:
        for label in ["Night", "Day"]:
            cnt = dn.get(label, 0)
            p(f"  {label:<6}  {cnt:>8,}  ({pct(cnt,dn_total):>6})")
    else:
        p("  No UTCTime tags found.")
    p()
    p(sep); p("  ✅  Analysis complete."); p(sep)

    # Save to file
    report_path = "pgn_report.txt"
    try:
        with open(report_path, "w", encoding="utf-8") as rf:
            rf.writelines(lines)
        print(f"\n📄  Report saved to: {report_path}")
    except Exception as e:
        print(f"\n⚠️  Could not save report: {e}")

def _wrap_print(p_fn, text: str, width: int = 76, indent: str = "        "):
    words = text.split(" | ")
    line  = indent
    for w in words:
        candidate = (line + w + " | ")
        if len(candidate) > width and line != indent:
            p_fn(line.rstrip(" | "))
            line = indent + w + " | "
        else:
            line = candidate
    if line.strip(" | "):
        p_fn(line.rstrip(" | "))

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    args = sys.argv[1:]

    pgn_files = []
    if args:
        for a in args:
            p = Path(a)
            if p.is_file() and p.suffix.lower() == ".pgn":
                pgn_files.append(str(p))
            elif p.is_dir():
                pgn_files.extend(str(f) for f in p.rglob("*.pgn"))
            else:
                print(f"⚠️  Skipping: {a}")
    else:
        pgn_files = [str(f) for f in Path(".").rglob("*.pgn")]

    if not pgn_files:
        print("❌  No .pgn files found.")
        sys.exit(1)

    num_files     = len(pgn_files)
    total_size_mb = sum(os.path.getsize(f) for f in pgn_files) / 1_000_000
    cpu_count     = mp.cpu_count()
    num_workers   = min(cpu_count, 8)

    # Distribute chunks: split each file into (num_workers // num_files) chunks
    # so that total chunks == num_workers (or close to it)
    chunks_per_file = max(1, num_workers // num_files)
    extra_chunks    = num_workers - chunks_per_file * num_files  # distribute remainder

    print(f"\n📂  Found {num_files} PGN file(s)  ({total_size_mb:,.1f} MB total)")
    print(f"⚙️   Using {num_workers} worker(s) across {num_files} file(s)  "
          f"(~{chunks_per_file} chunk(s)/file)")
    print(f"💾  Read buffer: {READ_BUFFER_BYTES // 1024 // 1024} MB per worker\n")

    work_items = []
    worker_id  = 1
    for i, filepath in enumerate(pgn_files):
        n_chunks = chunks_per_file + (1 if i < extra_chunks else 0)
        print(f"  Splitting {Path(filepath).name} into {n_chunks} chunk(s)...", flush=True)
        offsets = find_chunk_offsets(filepath, n_chunks)
        for start, end in offsets:
            work_items.append((filepath, start, end, worker_id, num_workers))
            worker_id += 1

    print(f"\n🚀  Launching {len(work_items)} worker(s)...\n")
    t_start = time.time()

    with mp.Pool(processes=num_workers) as pool:
        all_stats = pool.map(process_chunk, work_items)

    elapsed = time.time() - t_start
    print(f"\n🔀  Merging {len(all_stats)} result(s)...")
    merged = merge_stats(all_stats)
    print_report(merged, num_files, elapsed)


if __name__ == "__main__":
    mp.freeze_support()
    main()

```


<!-- 121 | Chess PGN analysis script with statistics | txt -->
```txt
  [Worker  1/8]  25,000 games   380 g/s
  [Worker  4/8]  25,000 games   375 g/s
  ...
```


<!-- 122 | Prezentare PowerPoint despre Australia | bash -->
```bash
    22	# Text extraction, one `## Slide N` section per slide
    23	extract-text presentation.pptx
    24	
    25	# Visual overview
    26	python scripts/thumbnail.py presentation.pptx
    27	
    28	# Raw XML
    29	python scripts/office/unpack.py presentation.pptx unpacked/
    30	
```


<!-- 123 | Prezentare PowerPoint despre Australia | bash -->
```bash
   153	extract-text output.pptx
   154	
```


<!-- 124 | Prezentare PowerPoint despre Australia | bash -->
```bash
   161	extract-text output.pptx | grep -iE "\bx{3,}\b|lorem|ipsum|\bTODO|\[insert|this.*(page|slide).*layout"
   162	
```


<!-- 125 | Prezentare PowerPoint despre Australia | txt -->
```txt
   173	Visually inspect these slides for user-visible defects.
   174	
   175	Look for:
   176	- Overlapping elements (text through shapes, lines through words, stacked elements)
   177	- Text overflow or cut off at edges/box boundaries
   178	- Decorative lines positioned for single-line text but title wrapped to two lines
   179	- Source citations or footers colliding with content above
   180	- Elements too close (< 0.3" gaps) or cards/sections nearly touching
   181	- Uneven gaps (large empty area in one place, cramped in another)
   182	- Insufficient margin from slide edges (< 0.5")
   183	- Columns or similar elements not aligned consistently
   184	- Low-contrast text (e.g., light gray text on cream-colored background)
   185	- Low-contrast icons (e.g., dark icons on dark backgrounds without a contrasting circle)
   186	- Text boxes too narrow causing excessive wrapping
   187	- Leftover placeholder content
   188	
   189	For each slide, list user-visible issues. Skip sub-pixel positioning and cosmetic nitpicks a viewer wouldn't notice.
   190	
   191	Read and analyze these images — run `ls -1 "$PWD"/slide-*.jpg` and use the exact absolute paths it prints:
   192	1. <absolute-path>/slide-N.jpg — (Expected: [brief description])
   193	2. <absolute-path>/slide-N.jpg — (Expected: [brief description])
   194	...
   195	
```


<!-- 126 | Prezentare PowerPoint despre Australia | bash -->
```bash
   213	python scripts/office/soffice.py --headless --convert-to pdf output.pptx
   214	rm -f slide-*.jpg
   215	pdftoppm -jpeg -r 150 output.pdf slide
   216	ls -1 "$PWD"/slide-*.jpg
   217	
```


<!-- 127 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
     6	const pptxgen = require("pptxgenjs");
     7	
     8	let pres = new pptxgen();
     9	pres.layout = 'LAYOUT_16x9';  // or 'LAYOUT_16x10', 'LAYOUT_4x3', 'LAYOUT_WIDE'
    10	pres.author = 'Your Name';
    11	pres.title = 'Presentation Title';
    12	
    13	let slide = pres.addSlide();
    14	slide.addText("Hello World!", { x: 0.5, y: 0.5, fontSize: 36, color: "363636" });
    15	
    16	pres.writeFile({ fileName: "Presentation.pptx" });
    17	
```


<!-- 128 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
    32	// Basic text
    33	slide.addText("Simple Text", {
    34	  x: 1, y: 1, w: 8, h: 2, fontSize: 24, fontFace: "Arial",
    35	  color: "363636", bold: true, align: "center", valign: "middle"
    36	});
    37	
    38	// Character spacing (use charSpacing, not letterSpacing which is silently ignored)
    39	slide.addText("SPACED TEXT", { x: 1, y: 1, w: 8, h: 1, charSpacing: 6 });
    40	
    41	// Rich text arrays
    42	slide.addText([
    43	  { text: "Bold ", options: { bold: true } },
    44	  { text: "Italic ", options: { italic: true } }
    45	], { x: 1, y: 3, w: 8, h: 1 });
    46	
    47	// Multi-line text (requires breakLine: true)
    48	slide.addText([
    49	  { text: "Line 1", options: { breakLine: true } },
    50	  { text: "Line 2", options: { breakLine: true } },
    51	  { text: "Line 3" }  // Last item doesn't need breakLine
    52	], { x: 0.5, y: 0.5, w: 8, h: 2 });
    53	
    54	// Text box margin (internal padding)
    55	slide.addText("Title", {
    56	  x: 0.5, y: 0.3, w: 9, h: 0.6,
    57	  margin: 0  // Use 0 when aligning text with other elements like shapes or icons
    58	});
    59	
```


<!-- 129 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
    68	// ✅ CORRECT: Multiple bullets
    69	slide.addText([
    70	  { text: "First item", options: { bullet: true, breakLine: true } },
    71	  { text: "Second item", options: { bullet: true, breakLine: true } },
    72	  { text: "Third item", options: { bullet: true } }
    73	], { x: 0.5, y: 0.5, w: 8, h: 3 });
    74	
    75	// ❌ WRONG: Never use unicode bullets
    76	slide.addText("• First item", { ... });  // Creates double bullets
    77	
    78	// Sub-items and numbered lists
    79	{ text: "Sub-item", options: { bullet: true, indentLevel: 1 } }
    80	{ text: "First", options: { bullet: { type: "number" }, breakLine: true } }
    81	
```


<!-- 130 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
    88	slide.addShape(pres.shapes.RECTANGLE, {
    89	  x: 0.5, y: 0.8, w: 1.5, h: 3.0,
    90	  fill: { color: "FF0000" }, line: { color: "000000", width: 2 }
    91	});
    92	
    93	slide.addShape(pres.shapes.OVAL, { x: 4, y: 1, w: 2, h: 2, fill: { color: "0000FF" } });
    94	
    95	slide.addShape(pres.shapes.LINE, {
    96	  x: 1, y: 3, w: 5, h: 0, line: { color: "FF0000", width: 3, dashType: "dash" }
    97	});
    98	
    99	// With transparency
   100	slide.addShape(pres.shapes.RECTANGLE, {
   101	  x: 1, y: 1, w: 3, h: 2,
   102	  fill: { color: "0088CC", transparency: 50 }
   103	});
   104	
   105	// Rounded rectangle (rectRadius only works with ROUNDED_RECTANGLE, not RECTANGLE)
   106	// ⚠️ Don't pair with rectangular accent overlays — they won't cover rounded corners. Use RECTANGLE instead.
   107	slide.addShape(pres.shapes.ROUNDED_RECTANGLE, {
   108	  x: 1, y: 1, w: 3, h: 2,
   109	  fill: { color: "FFFFFF" }, rectRadius: 0.1
   110	});
   111	
   112	// With shadow
   113	slide.addShape(pres.shapes.RECTANGLE, {
   114	  x: 1, y: 1, w: 3, h: 2,
   115	  fill: { color: "FFFFFF" },
   116	  shadow: { type: "outer", color: "000000", blur: 6, offset: 2, angle: 135, opacity: 0.15 }
   117	});
   118	
```


<!-- 131 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   142	// From file path
   143	slide.addImage({ path: "images/photo.jpg", x: 1, y: 1, w: 5, h: 3 });
   144	
   145	// From URL
   146	slide.addImage({ path: "https://example.com/image.jpg", x: 1, y: 1, w: 5, h: 3 });
   147	
   148	// From base64 (faster, no file I/O)
   149	slide.addImage({ data: "image/png;base64,iVBORw0KGgo...", x: 1, y: 1, w: 5, h: 3 });
   150	
```


<!-- 132 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   155	slide.addImage({
   156	  path: "image.png",
   157	  x: 1, y: 1, w: 5, h: 3,
   158	  rotate: 45,              // 0-359 degrees
   159	  rounding: true,          // Circular crop
   160	  transparency: 50,        // 0-100
   161	  flipH: true,             // Horizontal flip
   162	  flipV: false,            // Vertical flip
   163	  altText: "Description",  // Accessibility
   164	  hyperlink: { url: "https://example.com" }
   165	});
   166	
```


<!-- 133 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   171	// Contain - fit inside, preserve ratio
   172	{ sizing: { type: 'contain', w: 4, h: 3 } }
   173	
   174	// Cover - fill area, preserve ratio (may crop)
   175	{ sizing: { type: 'cover', w: 4, h: 3 } }
   176	
   177	// Crop - cut specific portion
   178	{ sizing: { type: 'crop', x: 0.5, y: 0.5, w: 2, h: 2 } }
   179	
```


<!-- 134 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   184	const origWidth = 1978, origHeight = 923, maxHeight = 3.0;
   185	const calcWidth = maxHeight * (origWidth / origHeight);
   186	const centerX = (10 - calcWidth) / 2;
   187	
   188	slide.addImage({ path: "image.png", x: centerX, y: 1.2, w: calcWidth, h: maxHeight });
   189	
```


<!-- 135 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   205	const React = require("react");
   206	const ReactDOMServer = require("react-dom/server");
   207	const sharp = require("sharp");
   208	const { FaCheckCircle, FaChartLine } = require("react-icons/fa");
   209	
   210	function renderIconSvg(IconComponent, color = "#000000", size = 256) {
   211	  return ReactDOMServer.renderToStaticMarkup(
   212	    React.createElement(IconComponent, { color, size: String(size) })
   213	  );
   214	}
   215	
   216	async function iconToBase64Png(IconComponent, color, size = 256) {
   217	  const svg = renderIconSvg(IconComponent, color, size);
   218	  const pngBuffer = await sharp(Buffer.from(svg)).png().toBuffer();
   219	  return "image/png;base64," + pngBuffer.toString("base64");
   220	}
   221	
```


<!-- 136 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   226	const iconData = await iconToBase64Png(FaCheckCircle, "#4472C4", 256);
   227	
   228	slide.addImage({
   229	  data: iconData,
   230	  x: 1, y: 1, w: 0.5, h: 0.5  // Size in inches
   231	});
   232	
```


<!-- 137 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   251	// Solid color
   252	slide.background = { color: "F1F1F1" };
   253	
   254	// Color with transparency
   255	slide.background = { color: "FF3399", transparency: 50 };
   256	
   257	// Image from URL
   258	slide.background = { path: "https://example.com/bg.jpg" };
   259	
   260	// Image from base64
   261	slide.background = { data: "image/png;base64,iVBORw0KGgo..." };
   262	
```


<!-- 138 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   269	slide.addTable([
   270	  ["Header 1", "Header 2"],
   271	  ["Cell 1", "Cell 2"]
   272	], {
   273	  x: 1, y: 1, w: 8, h: 2,
   274	  border: { pt: 1, color: "999999" }, fill: { color: "F1F1F1" }
   275	});
   276	
   277	// Advanced with merged cells
   278	let tableData = [
   279	  [{ text: "Header", options: { fill: { color: "6699CC" }, color: "FFFFFF", bold: true } }, "Cell"],
   280	  [{ text: "Merged", options: { colspan: 2 } }]
   281	];
   282	slide.addTable(tableData, { x: 1, y: 3.5, w: 8, colW: [4, 4] });
   283	
```


<!-- 139 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   296	// Bar chart
   297	slide.addChart(pres.charts.BAR, [{
   298	  name: "Sales", labels: ["Q1", "Q2", "Q3", "Q4"], values: [4500, 5500, 6200, 7100]
   299	}], {
   300	  x: 0.5, y: 0.6, w: 6, h: 3, barDir: 'col',
   301	  showTitle: true, title: 'Quarterly Sales'
   302	});
   303	
   304	// Line chart
   305	slide.addChart(pres.charts.LINE, [{
   306	  name: "Temp", labels: ["Jan", "Feb", "Mar"], values: [32, 35, 42]
   307	}], { x: 0.5, y: 4, w: 6, h: 3, lineSize: 3, lineSmooth: true });
   308	
   309	// Pie chart
   310	slide.addChart(pres.charts.PIE, [{
   311	  name: "Share", labels: ["A", "B", "Other"], values: [35, 45, 20]
   312	}], { x: 7, y: 1, w: 5, h: 4, showPercent: true });
   313	
   314	// Scatter with a computed trend line (tier-2: stay native, add regression as a second series)
   315	const xs = [8, 12, 18, 22, 25, 31], ys = [102, 145, 198, 241, 267, 312];
   316	const n = xs.length, sx = xs.reduce((a,b)=>a+b), sy = ys.reduce((a,b)=>a+b);
   317	const sxy = xs.reduce((a,x,i)=>a+x*ys[i],0), sxx = xs.reduce((a,x)=>a+x*x,0);
   318	const m = (n*sxy - sx*sy)/(n*sxx - sx*sx), b = (sy - m*sx)/n;
   319	slide.addChart(pres.charts.SCATTER, [
   320	  { name: "X",     values: xs },
   321	  { name: "Data",  values: ys },
   322	  { name: "Trend", values: xs.map(x => m*x + b) },
   323	], { x: 0.5, y: 1, w: 9, h: 4 });
   324	
```


<!-- 140 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   331	slide.addChart(pres.charts.BAR, chartData, {
   332	  x: 0.5, y: 1, w: 9, h: 4, barDir: "col",
   333	
   334	  // Custom colors (match your presentation palette)
   335	  chartColors: ["0D9488", "14B8A6", "5EEAD4"],
   336	
   337	  // Clean background
   338	  chartArea: { fill: { color: "FFFFFF" }, roundedCorners: true },
   339	
   340	  // Muted axis labels
   341	  catAxisLabelColor: "64748B",
   342	  valAxisLabelColor: "64748B",
   343	
   344	  // Subtle grid (value axis only)
   345	  valGridLine: { color: "E2E8F0", size: 0.5 },
   346	  catGridLine: { style: "none" },
   347	
   348	  // Data labels on bars
   349	  showValue: true,
   350	  dataLabelPosition: "outEnd",
   351	  dataLabelColor: "1E293B",
   352	
   353	  // Hide legend for single series
   354	  showLegend: false,
   355	});
   356	
```


<!-- 141 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   370	pres.defineSlideMaster({
   371	  title: 'TITLE_SLIDE', background: { color: '283A5E' },
   372	  objects: [{
   373	    placeholder: { options: { name: 'title', type: 'title', x: 1, y: 2, w: 8, h: 2 } }
   374	  }]
   375	});
   376	
   377	let titleSlide = pres.addSlide({ masterName: "TITLE_SLIDE" });
   378	titleSlide.addText("My Title", { placeholder: "title" });
   379	
```


<!-- 142 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   389	   color: "FF0000"      // ✅ CORRECT
   390	   color: "#FF0000"     // ❌ WRONG
   391	   
```


<!-- 143 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   395	   shadow: { type: "outer", blur: 6, offset: 2, color: "00000020" }          // ❌ CORRUPTS FILE
   396	   shadow: { type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.12 }  // ✅ CORRECT
   397	   
```


<!-- 144 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   409	   const shadow = { type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.15 };
   410	   slide.addShape(pres.shapes.RECTANGLE, { shadow, ... });  // ❌ second call gets already-converted values
   411	   slide.addShape(pres.shapes.RECTANGLE, { shadow, ... });
   412	
   413	   const makeShadow = () => ({ type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.15 });
   414	   slide.addShape(pres.shapes.RECTANGLE, { shadow: makeShadow(), ... });  // ✅ fresh object each time
   415	   slide.addShape(pres.shapes.RECTANGLE, { shadow: makeShadow(), ... });
   416	   
```


<!-- 145 | Prezentare PowerPoint despre Australia | javascript -->
```javascript
   420	   // ❌ WRONG: Accent bar doesn't cover rounded corners
   421	   slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 1, y: 1, w: 3, h: 1.5, fill: { color: "FFFFFF" } });
   422	   slide.addShape(pres.shapes.RECTANGLE, { x: 1, y: 1, w: 0.08, h: 1.5, fill: { color: "0891B2" } });
   423	
   424	   // ✅ CORRECT: Use RECTANGLE for clean alignment
   425	   slide.addShape(pres.shapes.RECTANGLE, { x: 1, y: 1, w: 3, h: 1.5, fill: { color: "FFFFFF" } });
   426	   slide.addShape(pres.shapes.RECTANGLE, { x: 1, y: 1, w: 0.08, h: 1.5, fill: { color: "0891B2" } });
   427	   
```


<!-- 146 | Prezentare PowerPoint despre Australia | js -->
```js
const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");

// Color palette - Ocean/Australia theme
const COLORS = {
  darkBlue: "003366",
  medBlue: "005B99",
  lightBlue: "0077CC",
  gold: "FFCC00",
  darkGold: "CC9900",
  white: "FFFFFF",
  offWhite: "F4F8FC",
  lightGray: "E8EEF4",
  darkGray: "2D3A4A",
  text: "1A2B3C",
  accent: "FF6B35",
  green: "2D7D46",
};

const makeShadow = () => ({ type: "outer", blur: 8, offset: 3, angle: 135, color: "000000", opacity: 0.15 });

async function createPresentation() {
  let pres = new pptxgen();
  pres.layout = "LAYOUT_16x9";
  pres.title = "Australia - Prezentare Geografică";

  // ============================================================
  // SLIDE 1 - Informații Generale
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkBlue };

    // Top accent band
    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.gold }, line: { color: COLORS.gold } });

    // Australian flag from Wikipedia (SVG)
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Flag_of_Australia_%28converted%29.svg/640px-Flag_of_Australia_%28converted%29.svg.png",
      x: 0.4, y: 0.25, w: 3.8, h: 1.9,
    });

    // Coat of Arms
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Coat_of_Arms_of_Australia.svg/500px-Coat_of_Arms_of_Australia.svg.png",
      x: 0.4, y: 2.35, w: 1.4, h: 1.8,
    });

    // Title
    slide.addText("Commonwealth of Australia", {
      x: 4.6, y: 0.3, w: 5.2, h: 0.8,
      fontSize: 28, bold: true, color: COLORS.white,
      fontFace: "Calibri", align: "left",
    });
    slide.addText("Commonwealth-ul Australiei", {
      x: 4.6, y: 1.0, w: 5.2, h: 0.5,
      fontSize: 17, color: COLORS.gold, fontFace: "Calibri", align: "left", italic: true,
    });

    // Info cards - right side
    const stats = [
      { label: "Suprafață", value: "7.692.024 km²", icon: "🗺️" },
      { label: "Populație", value: "~27,1 milioane", icon: "👥" },
      { label: "Capitală", value: "Canberra", icon: "🏛️" },
      { label: "Cel mai mare oraș", value: "Sydney", icon: "🌆" },
    ];
    stats.forEach((s, i) => {
      const cx = 4.6 + (i % 2) * 2.7;
      const cy = 1.65 + Math.floor(i / 2) * 1.3;
      slide.addShape(pres.shapes.RECTANGLE, {
        x: cx, y: cy, w: 2.5, h: 1.1,
        fill: { color: "FFFFFF", transparency: 92 },
        line: { color: COLORS.gold, width: 1.5 },
        shadow: makeShadow(),
      });
      slide.addText(s.icon + "  " + s.label, {
        x: cx + 0.1, y: cy + 0.08, w: 2.3, h: 0.35,
        fontSize: 10, color: COLORS.gold, fontFace: "Calibri", bold: true,
      });
      slide.addText(s.value, {
        x: cx + 0.1, y: cy + 0.42, w: 2.3, h: 0.5,
        fontSize: 13, color: COLORS.white, fontFace: "Calibri", bold: true,
      });
    });

    // Bottom stema label
    slide.addText("Stema Australiei", {
      x: 0.4, y: 4.2, w: 1.7, h: 0.3,
      fontSize: 9, color: COLORS.gold, fontFace: "Calibri", align: "center", italic: true,
    });

    // Bottom info bar
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 5.12, w: 10, h: 0.5,
      fill: { color: COLORS.medBlue }, line: { color: COLORS.medBlue },
    });
    slide.addText("Al 6-lea continent ca suprafață  •  Singurul continent-stat din lume  •  Densitate: 3,5 loc/km²", {
      x: 0.2, y: 5.17, w: 9.6, h: 0.4,
      fontSize: 11, color: COLORS.gold, fontFace: "Calibri", align: "center", bold: true,
    });
  }

  // ============================================================
  // SLIDE 2 - Harta și Vecinii
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.offWhite };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.darkBlue }, line: { color: COLORS.darkBlue } });

    slide.addText("🗺️ Harta Australiei și Vecinii", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    // Map image
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Australia_with_AAT_%28orthographic_projection%29.svg/640px-Australia_with_AAT_%28orthographic_projection%29.svg.png",
      x: 0.3, y: 0.9, w: 5.5, h: 4.2,
    });

    // Neighbor cards
    const neighbors = [
      { name: "Indonezia", dir: "Nord-Vest", dist: "~500 km" },
      { name: "Papua Noua Guinee", dir: "Nord", dist: "~150 km" },
      { name: "Insulele Solomon", dir: "Nord-Est", dist: "~1.700 km" },
      { name: "Noua Zeelandă", dir: "Sud-Est", dist: "~2.000 km" },
      { name: "Timor de Est", dir: "Nord", dist: "~500 km" },
    ];

    slide.addText("Vecini și Proximitate Geografică", {
      x: 6.0, y: 0.9, w: 3.8, h: 0.45,
      fontSize: 14, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    neighbors.forEach((n, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 6.0, y: 1.45 + i * 0.72, w: 3.8, h: 0.62,
        fill: { color: COLORS.darkBlue }, line: { color: COLORS.medBlue },
        shadow: makeShadow(),
      });
      slide.addText(n.name, {
        x: 6.1, y: 1.48 + i * 0.72, w: 2.5, h: 0.3,
        fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(n.dir + "  |  " + n.dist, {
        x: 6.1, y: 1.75 + i * 0.72, w: 3.5, h: 0.25,
        fontSize: 10, color: COLORS.white, fontFace: "Calibri",
      });
    });

    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 5.12, w: 10, h: 0.5,
      fill: { color: COLORS.darkBlue }, line: { color: COLORS.darkBlue },
    });
    slide.addText("Australia este înconjurată de Oceanul Indian la Vest, Oceanul Pacific la Est și Oceanul Antarctic la Sud", {
      x: 0.2, y: 5.17, w: 9.6, h: 0.4,
      fontSize: 10, color: COLORS.white, fontFace: "Calibri", align: "center",
    });
  }

  // ============================================================
  // SLIDE 3 - Cadrul Natural
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkGray };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.accent }, line: { color: COLORS.accent } });

    slide.addText("🌿 Cadrul Natural al Australiei", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.white, fontFace: "Calibri",
    });

    // Uluru image
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Uluru_Landscape.jpg/640px-Uluru_Landscape.jpg",
      x: 0.3, y: 0.9, w: 4.2, h: 2.8,
    });

    // Great Barrier Reef
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Coral_reef_at_palmyra.jpg/640px-Coral_reef_at_palmyra.jpg",
      x: 0.3, y: 3.8, w: 4.2, h: 1.65,
    });

    // Right side content
    const sections = [
      {
        title: "🏔️ Relief",
        text: "Australia are un relief variat: Great Dividing Range (Est, cel mai lung lanț muntos), Câmpia Centrală Australiană, Podișul Vestic (67% din teritoriu) și Munții Snowy (2.228m - Mt. Kosciuszko - cel mai înalt vârf)."
      },
      {
        title: "🌊 Fluvii și Lacuri",
        text: "Murray-Darling (3.750 km) - cel mai important sistem fluvial. Lacul Eyre (Kati Thanda) - cel mai mare lac, frecvent secat. Râul Murchison, Fitzroy și Ord sunt alte artere importante."
      },
      {
        title: "🌡️ Climate",
        text: "Climate tropicale în Nord, deșertice în centru (Marele Deșert Victoria, Gibson, Simpson), temperate în Sud-Est. 70% din teritoriu primește sub 500mm ploaie/an."
      },
      {
        title: "🐨 Faună Unică",
        text: "Australia găzduiește mamifere marsupiale unice: cangur, koala, wombat, diavol tasmaniac. 80% din specii sunt endemice. Platypus și echidna sunt singurele mamifere ovipare."
      },
    ];

    sections.forEach((s, i) => {
      const x = 4.7;
      const y = 0.9 + i * 1.15;
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y, w: 5.1, h: 1.05,
        fill: { color: "FFFFFF", transparency: 88 },
        line: { color: COLORS.accent, width: 1.5 },
        shadow: makeShadow(),
      });
      slide.addText(s.title, {
        x: x + 0.12, y: y + 0.06, w: 4.8, h: 0.32,
        fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(s.text, {
        x: x + 0.12, y: y + 0.38, w: 4.85, h: 0.62,
        fontSize: 9.5, color: COLORS.white, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 4 - Populatie si Demografie
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.offWhite };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.darkBlue }, line: { color: COLORS.darkBlue } });
    slide.addText("👥 Populație & Demografie", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    // Big stat boxes
    const bigStats = [
      { val: "27,1M", label: "Populație totală\n(2024)" },
      { val: "3,5", label: "Densitate\nloc/km²" },
      { val: "86%", label: "Pop. urbană" },
      { val: "26 ani", label: "Vârstă mediană" },
    ];

    bigStats.forEach((s, i) => {
      const x = 0.3 + i * 2.4;
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y: 0.9, w: 2.1, h: 1.4,
        fill: { color: COLORS.darkBlue },
        line: { color: COLORS.lightBlue },
        shadow: makeShadow(),
      });
      slide.addText(s.val, {
        x: x + 0.05, y: 1.0, w: 2.0, h: 0.7,
        fontSize: 36, bold: true, color: COLORS.gold, fontFace: "Calibri", align: "center",
      });
      slide.addText(s.label, {
        x: x + 0.05, y: 1.68, w: 2.0, h: 0.55,
        fontSize: 11, color: COLORS.white, fontFace: "Calibri", align: "center",
      });
    });

    // Ethnic composition chart
    slide.addText("Compoziție Etnică", {
      x: 0.3, y: 2.5, w: 4.8, h: 0.4,
      fontSize: 14, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    slide.addChart(pres.charts.PIE, [{
      name: "Etnii",
      labels: ["Europeni (Anglo-Celtici)", "Asiatici", "Alți europeni", "Aborigeni", "Alte origini"],
      values: [58, 20, 12, 3.3, 6.7],
    }], {
      x: 0.3, y: 2.95, w: 4.8, h: 2.5,
      chartColors: ["003366", "0077CC", "66AADD", "FF6B35", "FFCC00"],
      showPercent: true,
      showLegend: true,
      legendPos: "b",
      legendFontSize: 9,
      chartArea: { fill: { color: COLORS.offWhite } },
    });

    // Right side info
    const popInfo = [
      { icon: "🏠", title: "Speranța de Viață", text: "82,1 ani (una din cele mai ridicate din lume)" },
      { icon: "📈", title: "Creștere Naturală", text: "1,5% anual, susținută de imigrație (80% din creștere)" },
      { icon: "🌍", title: "Imigranți", text: "30% din populație s-a născut în afara Australiei" },
      { icon: "🏛️", title: "Popoare Indigene", text: "Aborigenii și insularii Torres Strait - primii locuitori, acum ~3,3% din populație" },
    ];

    popInfo.forEach((p, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 5.4, y: 2.5 + i * 0.72, w: 4.35, h: 0.62,
        fill: { color: COLORS.lightGray },
        line: { color: COLORS.medBlue, width: 1 },
        shadow: makeShadow(),
      });
      slide.addText(p.icon + " " + p.title, {
        x: 5.55, y: 2.53 + i * 0.72, w: 4.1, h: 0.28,
        fontSize: 11, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
      });
      slide.addText(p.text, {
        x: 5.55, y: 2.8 + i * 0.72, w: 4.1, h: 0.28,
        fontSize: 9.5, color: COLORS.text, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 5 - Așezări și Orașe
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkBlue };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.gold }, line: { color: COLORS.gold } });

    slide.addText("🏙️ Principalele Orașe ale Australiei", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.white, fontFace: "Calibri",
    });

    // City images
    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Sydney_from_the_air.jpg/640px-Sydney_from_the_air.jpg",
      x: 0.3, y: 0.9, w: 3.0, h: 1.9,
    });
    slide.addText("Sydney", {
      x: 0.3, y: 2.82, w: 3.0, h: 0.3,
      fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri", align: "center",
    });

    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/22/Melbourne_CBD_from_Rialto.jpg/640px-Melbourne_CBD_from_Rialto.jpg",
      x: 3.5, y: 0.9, w: 3.0, h: 1.9,
    });
    slide.addText("Melbourne", {
      x: 3.5, y: 2.82, w: 3.0, h: 0.3,
      fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri", align: "center",
    });

    slide.addImage({
      path: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Canberra_cityscape.jpg/640px-Canberra_cityscape.jpg",
      x: 6.7, y: 0.9, w: 3.0, h: 1.9,
    });
    slide.addText("Canberra - Capitala", {
      x: 6.7, y: 2.82, w: 3.0, h: 0.3,
      fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri", align: "center",
    });

    // City details table
    const cities = [
      { name: "Sydney", pop: "5,3M", special: "Casa Operei, Harbour Bridge, cel mai populat oraș" },
      { name: "Melbourne", pop: "5,1M", special: "Capitala culturală, „cel mai locuibil oraș din lume"" },
      { name: "Brisbane", pop: "2,6M", special: "Gazdă JO 2032, climat subtropical" },
      { name: "Perth", pop: "2,1M", special: "Cel mai izolat oraș mare din lume, minereuri" },
      { name: "Adelaide", pop: "1,4M", special: "Oraș al festivalurilor, vin Barossa Valley" },
      { name: "Canberra", pop: "470K", special: "Capitala națională planificată, gândită ca compromis între Sydney și Melbourne" },
    ];

    cities.forEach((c, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = 0.3 + col * 4.9;
      const y = 3.2 + row * 0.68;
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y, w: 4.6, h: 0.6,
        fill: { color: "FFFFFF", transparency: 90 },
        line: { color: COLORS.lightBlue, width: 1 },
      });
      slide.addText(c.name + "  (" + c.pop + ")", {
        x: x + 0.1, y: y + 0.04, w: 4.3, h: 0.26,
        fontSize: 11, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(c.special, {
        x: x + 0.1, y: y + 0.3, w: 4.3, h: 0.26,
        fontSize: 9, color: COLORS.white, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 6 - Economia
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.offWhite };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.green }, line: { color: COLORS.green } });

    slide.addText("💰 Economia Australiei", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    // Key economic stats
    const econStats = [
      { val: "$1,7T", label: "PIB (2023)", color: COLORS.green },
      { val: "AUD", label: "Moneda Oficială\n(Dolarul Australian)", color: COLORS.darkBlue },
      { val: "#13", label: "Economie Mondială", color: COLORS.accent },
      { val: "$62K", label: "PIB/cap locuitor", color: "6B21A8" },
    ];

    econStats.forEach((s, i) => {
      const x = 0.3 + i * 2.38;
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y: 0.88, w: 2.2, h: 1.3,
        fill: { color: s.color },
        line: { color: s.color },
        shadow: makeShadow(),
      });
      slide.addText(s.val, {
        x: x + 0.05, y: 0.95, w: 2.1, h: 0.6,
        fontSize: 30, bold: true, color: COLORS.white, fontFace: "Calibri", align: "center",
      });
      slide.addText(s.label, {
        x: x + 0.05, y: 1.53, w: 2.1, h: 0.55,
        fontSize: 10, color: COLORS.white, fontFace: "Calibri", align: "center",
      });
    });

    // Sector chart
    slide.addText("Sectoare Economice (% din PIB)", {
      x: 0.3, y: 2.35, w: 4.5, h: 0.4,
      fontSize: 13, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    slide.addChart(pres.charts.BAR, [{
      name: "% PIB",
      labels: ["Servicii", "Minerit", "Construcții", "Agricultură", "Industrie"],
      values: [70, 10, 8, 2.2, 6],
    }], {
      x: 0.3, y: 2.8, w: 4.5, h: 2.65,
      barDir: "col",
      chartColors: ["003366", "0077CC", "00A896", "FFCC00", "FF6B35"],
      showValue: true,
      dataLabelFontSize: 9,
      chartArea: { fill: { color: COLORS.offWhite }, roundedCorners: true },
      catAxisLabelColor: "333333",
      valAxisLabelColor: "333333",
      valGridLine: { color: "DDDDDD", size: 0.5 },
    });

    // Right side
    const econInfo = [
      { icon: "⛏️", title: "Minerit & Resurse", text: "Australia este cel mai mare exportator mondial de cărbune, fier, aur, bauxită. Minele din Western Australia sunt sursa a 80% din exporturi." },
      { icon: "🌾", title: "Agricultură", text: "Grâu, lână (top 2 mondial), carne de vită, zahăr. Agricultura ocupă 54% din suprafața țării." },
      { icon: "🏦", title: "Servicii Financiare", text: "Sydney este al 9-lea centru financiar global. Bursa ASX gestionează active de peste 2 trilioane AUD." },
      { icon: "🐄", title: "Turism", text: "Al 3-lea sector ca importanță, generând peste $60 miliarde AUD anual pre-pandemie." },
    ];

    econInfo.forEach((e, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 5.1, y: 2.35 + i * 0.78, w: 4.65, h: 0.68,
        fill: { color: COLORS.lightGray },
        line: { color: COLORS.green, width: 1.5 },
        shadow: makeShadow(),
      });
      slide.addText(e.icon + " " + e.title, {
        x: 5.25, y: 2.38 + i * 0.78, w: 4.4, h: 0.3,
        fontSize: 11, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
      });
      slide.addText(e.text, {
        x: 5.25, y: 2.67 + i * 0.78, w: 4.4, h: 0.32,
        fontSize: 9, color: COLORS.text, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 7 - Densitate si Regiuni
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkGray };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.lightBlue }, line: { color: COLORS.lightBlue } });

    slide.addText("📊 Densitate și Distribuție Regională", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 24, bold: true, color: COLORS.white, fontFace: "Calibri",
    });

    // Density chart by state
    slide.addText("Densitate Populație pe State (loc/km²)", {
      x: 0.3, y: 0.85, w: 5.5, h: 0.38,
      fontSize: 13, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });

    slide.addChart(pres.charts.BAR, [{
      name: "Densitate loc/km²",
      labels: ["ACT", "VIC", "NSW", "TAS", "QLD", "SA", "WA", "NT"],
      values: [160, 28, 10, 7.8, 3.3, 1.6, 1.0, 0.2],
    }], {
      x: 0.3, y: 1.28, w: 5.5, h: 3.05,
      barDir: "bar",
      chartColors: ["0077CC"],
      showValue: true,
      dataLabelFontSize: 9,
      chartArea: { fill: { color: "2D3A4A" }, roundedCorners: true },
      catAxisLabelColor: "CCCCCC",
      valAxisLabelColor: "CCCCCC",
      dataLabelColor: "FFFFFF",
      valGridLine: { color: "444444", size: 0.5 },
    });

    // Right side - regional info
    const regions = [
      { name: "ACT (Canberra)", pop: "470K", dens: "160 loc/km²", note: "Cel mai dens, capitala națională" },
      { name: "Victoria", pop: "6,7M", dens: "28 loc/km²", note: "Cea mai densă provincie" },
      { name: "NSW", pop: "8,3M", dens: "10 loc/km²", note: "Cea mai populată provincie" },
      { name: "Queensland", pop: "5,4M", dens: "3,3 loc/km²", note: "Crește rapid prin migrație internă" },
      { name: "Western Australia", pop: "2,8M", dens: "1,0 loc/km²", note: "1/3 din suprafață, bogat în resurse" },
      { name: "Northern Territory", pop: "250K", dens: "0,2 loc/km²", note: "Cel mai puțin populat, 30% aborigeni" },
    ];

    slide.addText("Provincii și Teritorii", {
      x: 6.0, y: 0.85, w: 3.8, h: 0.38,
      fontSize: 13, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });

    regions.forEach((r, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 6.0, y: 1.28 + i * 0.67, w: 3.8, h: 0.58,
        fill: { color: "FFFFFF", transparency: 90 },
        line: { color: COLORS.lightBlue, width: 1 },
      });
      slide.addText(r.name + " — " + r.pop + " / " + r.dens, {
        x: 6.1, y: 1.31 + i * 0.67, w: 3.6, h: 0.28,
        fontSize: 10, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(r.note, {
        x: 6.1, y: 1.57 + i * 0.67, w: 3.6, h: 0.25,
        fontSize: 9, color: COLORS.white, fontFace: "Calibri",
      });
    });

    // Bottom note
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 5.05, w: 10, h: 0.57,
      fill: { color: COLORS.medBlue }, line: { color: COLORS.medBlue },
    });
    slide.addText("⚠️  90% din australieni trăiesc pe o fâșie de max. 50 km de coastă — interiorul este aproape nelocuit (Outback)", {
      x: 0.2, y: 5.12, w: 9.6, h: 0.4,
      fontSize: 11, color: COLORS.gold, fontFace: "Calibri", align: "center", bold: true,
    });
  }

  // ============================================================
  // SLIDE 8 - Turism
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.offWhite };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.accent }, line: { color: COLORS.accent } });

    slide.addText("🏖️ Zone Turistice de Top", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.darkBlue, fontFace: "Calibri",
    });

    // Tourist destination images
    const destinations = [
      {
        name: "Great Barrier Reef",
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Coral_reef_at_palmyra.jpg/400px-Coral_reef_at_palmyra.jpg",
        desc: "Cel mai mare recif de corali din lume, UNESCO. 2.300 km, vizibil din spațiu."
      },
      {
        name: "Uluru (Ayers Rock)",
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Uluru_Landscape.jpg/400px-Uluru_Landscape.jpg",
        desc: "Monolit sacru, 348m înălțime, simbolul Australiei. Patrimoniu UNESCO."
      },
      {
        name: "Sydney Opera House",
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Sydney_Opera_House_Exterior_2019.jpg/400px-Sydney_Opera_House_Exterior_2019.jpg",
        desc: "Capodoperă arhitecturală, UNESCO. 2.000 de spectacole/an, 8 milioane vizitatori."
      },
    ];

    destinations.forEach((d, i) => {
      const x = 0.3 + i * 3.25;
      slide.addImage({
        path: d.img,
        x, y: 0.88, w: 3.0, h: 1.85,
      });
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y: 2.76, w: 3.0, h: 1.3,
        fill: { color: COLORS.darkBlue }, line: { color: COLORS.lightBlue },
        shadow: makeShadow(),
      });
      slide.addText(d.name, {
        x: x + 0.1, y: 2.82, w: 2.8, h: 0.32,
        fontSize: 12, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(d.desc, {
        x: x + 0.1, y: 3.13, w: 2.8, h: 0.85,
        fontSize: 9.5, color: COLORS.white, fontFace: "Calibri",
      });
    });

    // More tourist info
    const moreInfo = [
      { icon: "🐊", title: "Kakadu NP", text: "Cel mai mare parc național, 19.804 km², artă rupestră aborigenă de 40.000 ani" },
      { icon: "🌊", title: "Bondi Beach", text: "Cea mai faimoasă plajă, Sydney. Surf internaţional, populara cu turiştii" },
      { icon: "🦘", title: "Kangaroo Island", text: "Rezervație naturală cu fauna sălbatică protejată, koala, canguri, focă" },
      { icon: "🌿", title: "Daintree Rainforest", text: "Cea mai veche pădure tropicală din lume, 135 milioane ani, UNESCO" },
    ];

    moreInfo.forEach((m, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = 0.3 + col * 4.9;
      const y = 4.18 + row * 0.6;
      slide.addShape(pres.shapes.RECTANGLE, {
        x, y, w: 4.6, h: 0.5,
        fill: { color: COLORS.lightGray },
        line: { color: COLORS.accent, width: 1 },
      });
      slide.addText(m.icon + " " + m.title + ": " + m.text, {
        x: x + 0.1, y: y + 0.06, w: 4.4, h: 0.38,
        fontSize: 9, color: COLORS.text, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 9 - Festivaluri, Cultura, Guvernare
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkBlue };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.gold }, line: { color: COLORS.gold } });

    slide.addText("🎉 Festivaluri, Cultură & Guvernare", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 24, bold: true, color: COLORS.white, fontFace: "Calibri",
    });

    // Left - Festivals
    slide.addText("🎊 Festivaluri Specifice", {
      x: 0.3, y: 0.9, w: 4.7, h: 0.4,
      fontSize: 15, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });

    const festivals = [
      { name: "Australia Day (26 Ian)", desc: "Ziua națională, comemorează sosirea britanicilor în 1788. Focuri de artificii, concerte, dezbateri despre identitate națională." },
      { name: "Anzac Day (25 Apr)", desc: "Ziua comemorativă a veteranilor. Parade solemne, ceremonia Zorilor (Dawn Service), cea mai importantă zi națională." },
      { name: "Sydney Mardi Gras (Feb)", desc: "Cel mai mare festival LGBT din lume, 500.000 participanți, parade spectaculoase." },
      { name: "Melbourne Cup (Nov)", desc: "„Cursa care oprește o națiune" — cel mai faimos eveniment ecvestru, zi liberă în Victoria." },
      { name: "Vivid Sydney (Mai-Iun)", desc: "Festival de lumini, muzică și idei, 2,4 milioane vizitatori, spectacole pe Opera House." },
    ];

    festivals.forEach((f, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 0.3, y: 1.38 + i * 0.78, w: 4.7, h: 0.68,
        fill: { color: "FFFFFF", transparency: 90 },
        line: { color: COLORS.gold, width: 1 },
      });
      slide.addText(f.name, {
        x: 0.4, y: 1.41 + i * 0.78, w: 4.5, h: 0.28,
        fontSize: 11, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(f.desc, {
        x: 0.4, y: 1.68 + i * 0.78, w: 4.5, h: 0.33,
        fontSize: 9, color: COLORS.white, fontFace: "Calibri",
      });
    });

    // Right - Governance
    slide.addText("🏛️ Forma de Guvernare", {
      x: 5.3, y: 0.9, w: 4.5, h: 0.4,
      fontSize: 15, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });

    const govInfo = [
      { icon: "👑", label: "Forma de stat", val: "Monarhie constituțională parlamentară federală" },
      { icon: "👸", label: "Șef de stat", val: "Regele Charles III, reprezentat de Guvernatorul General" },
      { icon: "🗳️", label: "Șef de guvern", val: "Primul Ministru Anthony Albanese (Australian Labor Party)" },
      { icon: "🏛️", label: "Parlamentul", val: "Bicameral: Senat (76 senatori) + Camera Reprezentanților (151 membri)" },
      { icon: "⚖️", label: "Sistem juridic", val: "Common law britanic, Curtea Supremă (High Court of Australia)" },
      { icon: "🗺️", label: "Structura federală", val: "6 state + 2 teritorii: NSW, VIC, QLD, SA, WA, TAS, ACT, NT" },
    ];

    govInfo.forEach((g, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 5.3, y: 1.38 + i * 0.65, w: 4.5, h: 0.55,
        fill: { color: COLORS.medBlue, transparency: 30 },
        line: { color: COLORS.lightBlue, width: 1 },
      });
      slide.addText(g.icon + " " + g.label, {
        x: 5.4, y: 1.41 + i * 0.65, w: 4.3, h: 0.24,
        fontSize: 10, bold: true, color: COLORS.gold, fontFace: "Calibri",
      });
      slide.addText(g.val, {
        x: 5.4, y: 1.64 + i * 0.65, w: 4.3, h: 0.24,
        fontSize: 9, color: COLORS.white, fontFace: "Calibri",
      });
    });
  }

  // ============================================================
  // SLIDE 10 - Limbă, Internet, Concluzii
  // ============================================================
  {
    let slide = pres.addSlide();
    slide.background = { color: COLORS.darkGray };

    slide.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: COLORS.lightBlue }, line: { color: COLORS.lightBlue } });

    slide.addText("🌐 Limbă, Internet & Date Diverse", {
      x: 0.3, y: 0.15, w: 9.4, h: 0.6,
      fontSize: 24, bold: true, color: COLORS.white, fontFace: "Calibri",
    });

    // Left - Language
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0.3, y: 0.88, w: 4.5, h: 2.2,
      fill: { color: COLORS.darkBlue, transparency: 30 },
      line: { color: COLORS.lightBlue, width: 1.5 },
      shadow: makeShadow(),
    });
    slide.addText("🗣️ Limbă Oficială", {
      x: 0.45, y: 0.95, w: 4.2, h: 0.38,
      fontSize: 15, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });
    slide.addText([
      { text: "Engleza australiană", options: { bold: true, breakLine: true } },
      { text: "De facto (nu există limbă oficială declarată prin constituție)\n", options: { breakLine: true } },
      { text: "98% din australieni vorbesc engleza acasă sau o cunosc.", options: { breakLine: true } },
      { text: "\nAlte limbi vorbite:", options: { bold: true, breakLine: true } },
      { text: "Mandarina (~2,9%), Arabă (1,4%), Cantoneza (1,2%),\nVietnameză (1,2%), Italiană (1,2%), limbile aborigene (~250 de limbi).", options: { breakLine: false } },
    ], {
      x: 0.45, y: 1.38, w: 4.2, h: 1.55,
      fontSize: 10, color: COLORS.white, fontFace: "Calibri",
    });

    // Internet
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0.3, y: 3.2, w: 4.5, h: 1.2,
      fill: { color: COLORS.green, transparency: 20 },
      line: { color: COLORS.green, width: 1.5 },
      shadow: makeShadow(),
    });
    slide.addText("🌐 Domeniu de Internet", {
      x: 0.45, y: 3.27, w: 4.2, h: 0.38,
      fontSize: 15, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });
    slide.addText(".au  (pentru persoane fizice: .com.au, .org.au, .edu.au, .gov.au)\nIntroduced: 1986  |  Registrar: auDA (au Domain Administration)\n14,3 milioane domenii înregistrate (2024)", {
      x: 0.45, y: 3.65, w: 4.2, h: 0.65,
      fontSize: 10, color: COLORS.white, fontFace: "Calibri",
    });

    // Right - Miscellaneous facts
    slide.addText("🦘 Fapte Interesante", {
      x: 5.1, y: 0.88, w: 4.65, h: 0.4,
      fontSize: 15, bold: true, color: COLORS.gold, fontFace: "Calibri",
    });

    const facts = [
      { icon: "⏰", text: "Australia are 9 fuse orare diferite, inclusiv jumătăți de oră" },
      { icon: "🔵", text: "Drapelul include Union Jack (legătura cu Marea Britanie) și Crucea Sudului" },
      { icon: "🌡️", text: "Temperatura record: 50,7°C la Oodnadatta (1960)" },
      { icon: "🐊", text: "Mai mulți canguri decât oameni: 50M canguri vs 27M oameni" },
      { icon: "🏆", text: "Australia a câștigat de 5 ori titlul „Cel mai locuibil oraș" pentru Melbourne" },
      { icon: "🌊", text: "A 3-a zonă economică exclusivă din lume: 8,5M km² de ocean" },
      { icon: "🎓", text: "8 universități în Top 100 mondial, inclusiv Australian National University" },
      { icon: "🚂", text: "Indian Pacific: una din cele mai lungi rute feroviare din lume (4.352 km Sydney-Perth)" },
    ];

    facts.forEach((f, i) => {
      slide.addShape(pres.shapes.RECTANGLE, {
        x: 5.1, y: 1.35 + i * 0.52, w: 4.65, h: 0.44,
        fill: { color: "FFFFFF", transparency: 92 },
        line: { color: COLORS.lightBlue, width: 0.8 },
      });
      slide.addText(f.icon + "  " + f.text, {
        x: 5.22, y: 1.38 + i * 0.52, w: 4.42, h: 0.38,
        fontSize: 9.5, color: COLORS.white, fontFace: "Calibri",
      });
    });

    // Bottom footer
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 5.1, w: 10, h: 0.52,
      fill: { color: COLORS.lightBlue }, line: { color: COLORS.lightBlue },
    });
    slide.addText("🦘 Australia — Continentul de Jos, Insula de Sus, Națiunea Unicornului 🌏", {
      x: 0.2, y: 5.16, w: 9.6, h: 0.38,
      fontSize: 13, bold: true, color: COLORS.white, fontFace: "Calibri", align: "center",
    });
  }

  await pres.writeFile({ fileName: "/home/claude/australia.pptx" });
  console.log("Done!");
}

createPresentation().catch(console.error);

```


<!-- 147 | 💬 Do you know the app named "Bum... | python -->
```python
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bump Leaderboard</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0d0d0f;
    --surface: #16161a;
    --border: #2a2a30;
    --accent: #c8f135;
    --accent2: #f1a735;
    --accent3: #35c8f1;
    --text: #f0f0f0;
    --muted: #6b6b7a;
    --you: #c8f135;
  }

  * { margin: 0; padding: 0; box-sizing: border-box; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'DM Mono', monospace;
    min-height: 100vh;
    padding: 24px 16px 48px;
  }

  header {
    text-align: center;
    margin-bottom: 40px;
    padding-top: 12px;
  }

  header h1 {
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: clamp(2rem, 6vw, 3.2rem);
    letter-spacing: -1px;
    line-height: 1;
  }

  header h1 span {
    color: var(--accent);
  }

  header p {
    color: var(--muted);
    font-size: 0.75rem;
    margin-top: 8px;
    letter-spacing: 2px;
    text-transform: uppercase;
  }

  /* Overall rankings */
  .overall {
    max-width: 700px;
    margin: 0 auto 48px;
  }

  .section-label {
    font-family: 'Syne', sans-serif;
    font-size: 0.65rem;
    letter-spacing: 3px;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 14px;
    padding-left: 4px;
  }

  .overall-grid {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .overall-row {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 14px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    transition: border-color 0.2s;
    position: relative;
    overflow: hidden;
  }

  .overall-row:hover { border-color: #444; }

  .overall-row .bar-bg {
    position: absolute;
    left: 0; top: 0; bottom: 0;
    background: rgba(200,241,53,0.06);
    border-radius: 8px;
    transition: width 0.8s cubic-bezier(.16,1,.3,1);
  }

  .overall-row.is-you .bar-bg { background: rgba(200,241,53,0.10); }
  .overall-row.is-you { border-color: var(--accent); }

  .rank {
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: 1rem;
    min-width: 28px;
    color: var(--muted);
    position: relative;
  }

  .rank.gold { color: #ffd700; }
  .rank.silver { color: #c0c0c0; }
  .rank.bronze { color: #cd7f32; }

  .name {
    flex: 1;
    font-size: 0.85rem;
    position: relative;
  }

  .is-you .name { color: var(--accent); font-weight: 500; }
  .you-badge {
    font-size: 0.6rem;
    background: var(--accent);
    color: #000;
    padding: 1px 5px;
    border-radius: 3px;
    margin-left: 6px;
    font-weight: 700;
    letter-spacing: 1px;
    vertical-align: middle;
  }

  .score {
    font-size: 0.85rem;
    font-weight: 500;
    color: var(--accent);
    position: relative;
    min-width: 60px;
    text-align: right;
  }

  /* City cards */
  .cities {
    max-width: 700px;
    margin: 0 auto;
    display: grid;
    gap: 20px;
  }

  .city-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 12px;
    overflow: hidden;
  }

  .city-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 18px 12px;
    border-bottom: 1px solid var(--border);
  }

  .city-name {
    font-family: 'Syne', sans-serif;
    font-weight: 700;
    font-size: 1rem;
    letter-spacing: -0.3px;
  }

  .your-rank-badge {
    font-size: 0.65rem;
    letter-spacing: 1px;
    text-transform: uppercase;
    padding: 3px 8px;
    border-radius: 4px;
    font-weight: 500;
  }

  .rank-1st { background: rgba(200,241,53,0.15); color: var(--accent); border: 1px solid rgba(200,241,53,0.3); }
  .rank-top3 { background: rgba(241,167,53,0.12); color: var(--accent2); border: 1px solid rgba(241,167,53,0.25); }
  .rank-mid { background: rgba(53,200,241,0.10); color: var(--accent3); border: 1px solid rgba(53,200,241,0.2); }
  .rank-low { background: rgba(107,107,122,0.15); color: var(--muted); border: 1px solid var(--border); }

  .city-rows {
    padding: 8px 0;
  }

  .city-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 6px 18px;
    position: relative;
  }

  .city-row.is-you {
    background: rgba(200,241,53,0.05);
  }

  .city-row .c-rank {
    font-family: 'Syne', sans-serif;
    font-weight: 700;
    font-size: 0.75rem;
    min-width: 20px;
    color: var(--muted);
  }

  .city-row.is-you .c-rank { color: var(--accent); }

  .city-row .c-bar-wrap {
    flex: 1;
    height: 4px;
    background: var(--border);
    border-radius: 2px;
    overflow: hidden;
  }

  .city-row .c-bar {
    height: 100%;
    border-radius: 2px;
    background: var(--muted);
    transition: width 1s cubic-bezier(.16,1,.3,1);
  }

  .city-row.is-you .c-bar { background: var(--accent); }
  .city-row:nth-child(1) .c-bar { background: #ffd700; }

  .city-row .c-name {
    font-size: 0.75rem;
    min-width: 72px;
    color: #ccc;
  }

  .city-row.is-you .c-name { color: var(--accent); }

  .city-row .c-pct {
    font-size: 0.72rem;
    color: var(--muted);
    min-width: 42px;
    text-align: right;
  }

  .city-row.is-you .c-pct { color: var(--accent); }

  /* Stat pills */
  .stats-row {
    max-width: 700px;
    margin: 0 auto 32px;
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
  }

  .stat-pill {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 14px 12px;
    text-align: center;
  }

  .stat-pill .s-val {
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: 1.5rem;
    color: var(--accent);
    line-height: 1;
  }

  .stat-pill .s-label {
    font-size: 0.6rem;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: var(--muted);
    margin-top: 5px;
  }
</style>
</head>
<body>

<header>
  <h1>BUMP <span>LEADERBOARD</span></h1>
  <p>Your squad · Argeș county</p>
</header>

<div class="stats-row">
  <div class="stat-pill">
    <div class="s-val">2</div>
    <div class="s-label">Cities Led</div>
  </div>
  <div class="stat-pill">
    <div class="s-val">#1</div>
    <div class="s-label">Stolnici & Hârsești</div>
  </div>
  <div class="stat-pill">
    <div class="s-val">7</div>
    <div class="s-label">Cities Tracked</div>
  </div>
</div>

<!-- Overall score table -->
<div class="overall">
  <div class="section-label">Overall ranking · avg position across cities</div>
  <div class="overall-grid" id="overall-grid"></div>
</div>

<div class="cities" id="cities"></div>

<script>
const YOU = "Andrei";

const data = [
  {
    city: "Pitești",
    entries: [
      { name: "DJ Luca", pct: 30.1 },
      { name: "Fane", pct: 25.9 },
      { name: "Edy", pct: 25.2 },
      { name: "Alex", pct: 25.0 },
      { name: "Seby", pct: 25.0 },
      { name: "George", pct: 15.5 },
      { name: "Iulia", pct: 13.2 },
      { name: "Tania", pct: 13.0 },
      { name: "Bobby", pct: 11.5 },
      { name: "Gabriel", pct: 3.2 },
      { name: YOU, pct: 2.3, you: true },
    ]
  },
  {
    city: "Bradu",
    entries: [
      { name: "DJ Luca", pct: 16.8 },
      { name: "Seby", pct: 14.2 },
      { name: "Alex", pct: 7.5 },
      { name: "Fane", pct: 7.2 },
      { name: "Edy", pct: 3.4 },
      { name: "Iulia", pct: 2.7 },
      { name: "George", pct: 2.4 },
      { name: "Tania", pct: 1.6 },
      { name: "Bobby", pct: 1.1 },
      { name: YOU, pct: 0.9, you: true },
    ]
  },
  {
    city: "Albota",
    entries: [
      { name: "Fane", pct: 4.6 },
      { name: YOU, pct: 3.1, you: true },
      { name: "Iulia", pct: 3.1 },
      { name: "DJ Luca", pct: 2.8 },
      { name: "Alex", pct: 1.8 },
      { name: "Seby", pct: 1.4 },
      { name: "Tania", pct: 0.9 },
      { name: "Edy", pct: 0.1 },
    ]
  },
  {
    city: "Costești",
    entries: [
      { name: "Seby", pct: 1.9 },
      { name: "Tania", pct: 1.5 },
      { name: "DJ Luca", pct: 0.6 },
      { name: "Iulia", pct: 0.6 },
      { name: "Fane", pct: 0.5 },
      { name: YOU, pct: 0.3, you: true },
    ]
  },
  {
    city: "Lunca Corbului",
    entries: [
      { name: YOU, pct: 2.5, you: true },
      { name: "Iulia", pct: 2.0 },
      { name: "DJ Luca", pct: 1.9 },
      { name: "Fane", pct: 0.5 },
      { name: "Seby", pct: 0.1 },
      { name: "Tania", pct: 0.1 },
    ]
  },
  {
    city: "Stolnici",
    entries: [
      { name: YOU, pct: 2.3, you: true },
    ]
  },
  {
    city: "Hârsești",
    entries: [
      { name: YOU, pct: 0.3, you: true },
    ]
  },
];

// Overall ranking: average position across all cities (lower = better)
const allNames = [...new Set(data.flatMap(c => c.entries.map(e => e.name)))];

const overallScores = allNames.map(name => {
  let totalRank = 0;
  let count = 0;
  let totalPct = 0;
  data.forEach(city => {
    const idx = city.entries.findIndex(e => e.name === name);
    if (idx !== -1) {
      totalRank += (idx + 1);
      count++;
      totalPct += city.entries[idx].pct;
    }
  });
  return { name, avgRank: count ? totalRank / count : 99, totalPct, cities: count };
});

overallScores.sort((a, b) => a.avgRank - b.avgRank);

const maxTotalPct = Math.max(...overallScores.map(s => s.totalPct));

const grid = document.getElementById('overall-grid');
overallScores.forEach((s, i) => {
  const isYou = s.name === YOU;
  const rankClass = i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';
  const pct = (s.totalPct / maxTotalPct) * 100;
  const div = document.createElement('div');
  div.className = `overall-row${isYou ? ' is-you' : ''}`;
  div.innerHTML = `
    <div class="bar-bg" style="width:0%" data-target="${pct}%"></div>
    <div class="rank ${rankClass}">${i + 1}</div>
    <div class="name">${s.name}${isYou ? '<span class="you-badge">YOU</span>' : ''}</div>
    <div class="score" style="color:var(--muted);font-size:0.7rem">avg #${s.avgRank.toFixed(1)}</div>
    <div class="score">${s.totalPct.toFixed(1)}%</div>
  `;
  grid.appendChild(div);
});

// City cards
const citiesEl = document.getElementById('cities');
data.forEach(cityData => {
  const max = cityData.entries[0].pct;
  const yourIdx = cityData.entries.findIndex(e => e.you);
  const yourRank = yourIdx + 1;
  const total = cityData.entries.length;

  let badgeClass, badgeText;
  if (yourRank === 1) { badgeClass = 'rank-1st'; badgeText = '🥇 #1'; }
  else if (yourRank <= 3) { badgeClass = 'rank-top3'; badgeText = `#${yourRank} of ${total}`; }
  else if (yourRank <= Math.ceil(total / 2)) { badgeClass = 'rank-mid'; badgeText = `#${yourRank} of ${total}`; }
  else { badgeClass = 'rank-low'; badgeText = `#${yourRank} of ${total}`; }

  const card = document.createElement('div');
  card.className = 'city-card';

  const rows = cityData.entries.map((e, i) => {
    const barW = (e.pct / max * 100).toFixed(1);
    const isYou = e.you;
    return `<div class="city-row${isYou ? ' is-you' : ''}">
      <div class="c-rank">${i + 1}</div>
      <div class="c-name">${isYou ? '<span style="color:var(--accent)">▶ You</span>' : e.name}</div>
      <div class="c-bar-wrap"><div class="c-bar" style="width:0%" data-target="${barW}%"></div></div>
      <div class="c-pct">${e.pct}%</div>
    </div>`;
  }).join('');

  card.innerHTML = `
    <div class="city-header">
      <div class="city-name">${cityData.city}</div>
      <div class="your-rank-badge ${badgeClass}">${badgeText}</div>
    </div>
    <div class="city-rows">${rows}</div>
  `;
  citiesEl.appendChild(card);
});

// Animate bars on load
setTimeout(() => {
  document.querySelectorAll('.bar-bg[data-target]').forEach(el => {
    el.style.transition = 'width 1s cubic-bezier(.16,1,.3,1)';
    el.style.width = el.dataset.target;
  });
  document.querySelectorAll('.c-bar[data-target]').forEach(el => {
    el.style.width = el.dataset.target;
  });
}, 100);
</script>
</body>
</html>

```


<!-- 148 | Audio loudness analysis in Python | bash -->
```bash
python audio_loudness_analyzer.py your_audio_file.wav
```


<!-- 149 | Audio loudness analysis in Python | txt -->
```txt
==================================================
  Audio File: my_recording.wav
==================================================

  Average Loudness : -18.43 dBFS  (~77.6 dB SPL)
  Peak Loudness    : -3.21 dBFS   (~92.8 dB SPL)

  Peak threshold checks (dB SPL):
  --------------------------------
    Over  10 dB? ✅ YES
    Over  20 dB? ✅ YES
    ...
    Over  90 dB? ✅ YES
    Over 100 dB? ❌ NO
    ...
```


<!-- 150 | Audio loudness analysis in Python | bash -->
```bash
  pip install pydub
  # then install ffmpeg from https://ffmpeg.org/download.html
  
```


<!-- 151 | Audio loudness analysis in Python | py -->
```py
import numpy as np
import wave
import sys
import os

def analyze_audio(filepath):
    """
    Analyzes an audio file and reports:
    - Average loudness in dBFS
    - Whether the peak exceeds 10, 20, ..., 130 dB thresholds
    """

    ext = os.path.splitext(filepath)[1].lower()

    # --- Load audio samples ---
    if ext == ".wav":
        with wave.open(filepath, 'rb') as wf:
            n_channels = wf.getnchannels()
            sampwidth = wf.getsampwidth()
            n_frames = wf.getnframes()
            raw = wf.readframes(n_frames)

        # Convert raw bytes to numpy array
        dtype_map = {1: np.int8, 2: np.int16, 4: np.int32}
        dtype = dtype_map.get(sampwidth)
        if dtype is None:
            raise ValueError(f"Unsupported sample width: {sampwidth} bytes")

        samples = np.frombuffer(raw, dtype=dtype).astype(np.float64)

        # Normalize to [-1.0, 1.0]
        max_val = float(2 ** (8 * sampwidth - 1))
        samples /= max_val

    else:
        # Try pydub for mp3, flac, ogg, m4a, etc.
        try:
            from pydub import AudioSegment
        except ImportError:
            print("ERROR: 'pydub' is required for non-WAV files.")
            print("Install it with: pip install pydub")
            print("You may also need ffmpeg: https://ffmpeg.org/download.html")
            sys.exit(1)

        audio = AudioSegment.from_file(filepath)
        samples = np.array(audio.get_array_of_samples(), dtype=np.float64)
        max_val = float(2 ** (8 * audio.sample_width - 1))
        samples /= max_val

    if len(samples) == 0:
        raise ValueError("Audio file is empty or could not be read.")

    # --- dBFS calculations ---
    # Avoid log(0) by clamping
    epsilon = 1e-10

    rms = np.sqrt(np.mean(samples ** 2))
    avg_dbfs = 20 * np.log10(max(rms, epsilon))

    peak = np.max(np.abs(samples))
    peak_dbfs = 20 * np.log10(max(peak, epsilon))

    # dBFS → approximate dB SPL
    # 0 dBFS is roughly 96 dB SPL for 16-bit audio (common convention)
    DBFS_TO_SPL_OFFSET = 96.0
    avg_db_spl = avg_dbfs + DBFS_TO_SPL_OFFSET
    peak_db_spl = peak_dbfs + DBFS_TO_SPL_OFFSET

    # --- Report ---
    print("=" * 50)
    print(f"  Audio File: {os.path.basename(filepath)}")
    print("=" * 50)
    print(f"\n  Average Loudness : {avg_dbfs:+.2f} dBFS  (~{avg_db_spl:.1f} dB SPL)")
    print(f"  Peak Loudness    : {peak_dbfs:+.2f} dBFS  (~{peak_db_spl:.1f} dB SPL)")
    print()
    print("  Peak threshold checks (dB SPL):")
    print("  " + "-" * 32)

    thresholds = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130]
    for t in thresholds:
        status = "✅ YES" if peak_db_spl >= t else "❌ NO "
        print(f"    Over {t:>3} dB? {status}")

    print("\n" + "=" * 50)
    print("  Note: dB SPL values use the 0 dBFS ≈ 96 dB SPL")
    print("  convention (standard for 16-bit digital audio).")
    print("=" * 50)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python audio_loudness_analyzer.py <audio_file>")
        print("Supported formats: .wav, .mp3, .flac, .ogg, .m4a (mp3/flac/ogg/m4a require pydub + ffmpeg)")
        sys.exit(1)

    path = sys.argv[1]

    if not os.path.isfile(path):
        print(f"ERROR: File not found: {path}")
        sys.exit(1)

    analyze_audio(path)

```


<!-- 152 | Audio loudness analysis in Python | python -->
```python
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python audio_loudness_analyzer.py <audio_file>")
        print("Supported formats: .wav, .mp3, .flac, .ogg, .m4a (mp3/flac/ogg/m4a require pydub + ffmpeg)")
        sys.exit(1)

    path = sys.argv[1]
```


<!-- 153 | Audio loudness analysis in Python | python -->
```python
if __name__ == "__main__":
    path = "/storage/emulated/0/download/examplefile.mp3"
```


<!-- 154 | Audio loudness analysis in Python | bash -->
```bash
python audio_loudness_analyzer.py
```


<!-- 155 | Audio loudness analysis in Python | bash -->
```bash
pip install static-ffmpeg
```


<!-- 156 | Audio loudness analysis in Python | python -->
```python
import static_ffmpeg
static_ffmpeg.add_paths()
```


<!-- 157 | Trip accident on the way to Pitești | bash -->
```bash
    76	pdfinfo /mnt/user-data/uploads/report.pdf
    77	pdftotext -f 1 -l 1 /mnt/user-data/uploads/report.pdf - | head -20
    78	
```


<!-- 158 | Trip accident on the way to Pitești | python -->
```python
    83	from pypdf import PdfReader
    84	r = PdfReader("/mnt/user-data/uploads/report.pdf")
    85	print(f"{len(r.pages)} pages")
    86	print(r.pages[0].extract_text()[:2000])
    87	
```


<!-- 159 | Trip accident on the way to Pitești | bash -->
```bash
   106	pandoc /mnt/user-data/uploads/memo.docx -t markdown | head -200
   107	
```


<!-- 160 | Trip accident on the way to Pitești | python -->
```python
   120	from openpyxl import load_workbook
   121	wb = load_workbook("/mnt/user-data/uploads/data.xlsx", read_only=True)
   122	print("Sheets:", wb.sheetnames)
   123	ws = wb.active
   124	for row in ws.iter_rows(max_row=5, values_only=True):
   125	    print(row)
   126	
```


<!-- 161 | Trip accident on the way to Pitești | python -->
```python
   137	import pandas as pd
   138	df = pd.read_excel("/mnt/user-data/uploads/old.xls", engine="xlrd", nrows=5)
   139	
```


<!-- 162 | Trip accident on the way to Pitești | python -->
```python
   144	import pandas as pd
   145	df = pd.read_excel("/mnt/user-data/uploads/data.ods", engine="odf", nrows=5)
   146	
```


<!-- 163 | Trip accident on the way to Pitești | python -->
```python
   153	from itertools import islice
   154	from pptx import Presentation
   155	p = Presentation("/mnt/user-data/uploads/deck.pptx")
   156	print(f"{len(p.slides)} slides")
   157	for i, slide in enumerate(islice(p.slides, 3), 1):
   158	    texts = [s.text for s in slide.shapes if s.has_text_frame]
   159	    print(f"Slide {i}:", " | ".join(t for t in texts if t))
   160	
```


<!-- 164 | Trip accident on the way to Pitești | python -->
```python
   181	import pandas as pd
   182	df = pd.read_csv("/mnt/user-data/uploads/data.csv", nrows=5)
   183	print(df)
   184	print()
   185	print(df.dtypes)
   186	
```


<!-- 165 | Trip accident on the way to Pitești | bash -->
```bash
   193	wc -l /mnt/user-data/uploads/data.csv
   194	
```


<!-- 166 | Trip accident on the way to Pitești | python -->
```python
   199	df = pd.read_csv("/mnt/user-data/uploads/data.csv")
   200	print(df.describe())
   201	
```


<!-- 167 | Trip accident on the way to Pitești | bash -->
```bash
   212	jq 'type' /mnt/user-data/uploads/data.json
   213	jq 'if type == "array" then length elif type == "object" then keys else . end' /mnt/user-data/uploads/data.json
   214	
```


<!-- 168 | Trip accident on the way to Pitești | bash -->
```bash
   225	head -3 /mnt/user-data/uploads/data.jsonl | jq .
   226	wc -l /mnt/user-data/uploads/data.jsonl
   227	
```


<!-- 169 | Trip accident on the way to Pitești | python -->
```python
   241	from PIL import Image
   242	img = Image.open("/mnt/user-data/uploads/photo.jpg")
   243	print(img.size, img.mode, img.format)
   244	
```


<!-- 170 | Trip accident on the way to Pitești | python -->
```python
   249	import pytesseract
   250	print(pytesseract.image_to_string(img))
   251	
```


<!-- 171 | Trip accident on the way to Pitești | bash -->
```bash
   266	unzip -l /mnt/user-data/uploads/bundle.zip
   267	tar -tf /mnt/user-data/uploads/bundle.tar
   268	
```


<!-- 172 | Trip accident on the way to Pitești | bash -->
```bash
   276	unzip -p /mnt/user-data/uploads/bundle.zip path/inside/file.txt
   277	
```


<!-- 173 | Trip accident on the way to Pitești | bash -->
```bash
   283	zcat /mnt/user-data/uploads/data.json.gz | head -50
   284	
```


<!-- 174 | Trip accident on the way to Pitești | bash -->
```bash
   291	pandoc /mnt/user-data/uploads/book.epub -t plain | head -200
   292	
```


<!-- 175 | Trip accident on the way to Pitești | bash -->
```bash
   305	pandoc /mnt/user-data/uploads/notes.rtf -t plain | head -200
   306	
```


<!-- 176 | Trip accident on the way to Pitești | bash -->
```bash
   320	wc -c /mnt/user-data/uploads/app.log
   321	
```


<!-- 177 | Trip accident on the way to Pitești | bash -->
```bash
   331	tail -200 /mnt/user-data/uploads/app.log
   332	
```


<!-- 178 | Trip accident on the way to Pitești | bash -->
```bash
   339	file /mnt/user-data/uploads/mystery.bin
   340	xxd /mnt/user-data/uploads/mystery.bin | head -5
   341	
```


<!-- 179 | Retrieving saved WiFi passwords | txt -->
```txt
python wifi_passwords.py
```


<!-- 180 | Retrieving saved WiFi passwords | txt -->
```txt
python3 wifi_passwords.py
```


<!-- 181 | Retrieving saved WiFi passwords | txt -->
```txt
sudo python3 wifi_passwords.py
```


<!-- 182 | Retrieving saved WiFi passwords | py -->
```py
#!/usr/bin/env python3
"""
wifi_passwords.py - Check saved Wi-Fi passwords on your device.

Supports: Windows, macOS, Linux (NetworkManager)
Run with admin/root privileges for best results.
"""

import subprocess
import platform
import sys
import re


def get_wifi_passwords_windows():
    """Get saved Wi-Fi profiles and passwords on Windows."""
    results = []

    try:
        # Get all saved Wi-Fi profiles
        output = subprocess.check_output(
            ["netsh", "wlan", "show", "profiles"],
            text=True, errors="ignore"
        )
    except subprocess.CalledProcessError as e:
        print(f"[!] Error listing profiles: {e}")
        return results

    # Extract profile names
    profiles = re.findall(r"All User Profile\s*:\s*(.+)", output)

    for profile in profiles:
        profile = profile.strip()
        try:
            # Get details for each profile, including password (key=clear)
            detail = subprocess.check_output(
                ["netsh", "wlan", "show", "profile", profile, "key=clear"],
                text=True, errors="ignore"
            )
            # Find the password
            match = re.search(r"Key Content\s*:\s*(.+)", detail)
            password = match.group(1).strip() if match else "(no password / open network)"
        except subprocess.CalledProcessError:
            password = "(could not retrieve)"

        results.append({"ssid": profile, "password": password})

    return results


def get_wifi_passwords_macos():
    """Get saved Wi-Fi passwords on macOS using the security command."""
    results = []

    try:
        # List all preferred networks
        airport_output = subprocess.check_output(
            ["/System/Library/PrivateFrameworks/Apple80211.framework/Resources/airport", "-s"],
            text=True, errors="ignore"
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        airport_output = ""

    # Try to read from networksetup
    try:
        preferred = subprocess.check_output(
            ["networksetup", "-listpreferredwirelessnetworks", "en0"],
            text=True, errors="ignore"
        )
        ssids = [line.strip() for line in preferred.splitlines() if line.strip() and "Preferred" not in line]
    except subprocess.CalledProcessError:
        ssids = []

    if not ssids:
        print("[!] No saved networks found via networksetup. Try running as root.")
        return results

    for ssid in ssids:
        try:
            pw_output = subprocess.check_output(
                ["security", "find-generic-password", "-D", "AirPort network password",
                 "-a", ssid, "-w"],
                text=True, stderr=subprocess.DEVNULL
            ).strip()
            password = pw_output if pw_output else "(no password / open network)"
        except subprocess.CalledProcessError:
            password = "(not found in Keychain — may need permissions)"

        results.append({"ssid": ssid, "password": password})

    return results


def get_wifi_passwords_linux():
    """Get saved Wi-Fi passwords on Linux (NetworkManager)."""
    results = []
    import os

    nm_dir = "/etc/NetworkManager/system-connections"

    if not os.path.exists(nm_dir):
        print("[!] NetworkManager config directory not found.")
        print("    Try: /etc/NetworkManager/system-connections/")
        return results

    try:
        files = os.listdir(nm_dir)
    except PermissionError:
        print("[!] Permission denied. Please run with: sudo python3 wifi_passwords.py")
        return results

    for filename in files:
        filepath = os.path.join(nm_dir, filename)
        try:
            with open(filepath, "r", errors="ignore") as f:
                content = f.read()
        except PermissionError:
            results.append({"ssid": filename, "password": "(permission denied — run as root)"})
            continue

        ssid_match = re.search(r"^ssid\s*=\s*(.+)", content, re.MULTILINE)
        psk_match = re.search(r"^psk\s*=\s*(.+)", content, re.MULTILINE)

        ssid = ssid_match.group(1).strip() if ssid_match else filename
        password = psk_match.group(1).strip() if psk_match else "(no password / open network)"

        results.append({"ssid": ssid, "password": password})

    return results


def print_results(results):
    if not results:
        print("\n[!] No Wi-Fi profiles found.\n")
        return

    print(f"\n{'='*50}")
    print(f"  Found {len(results)} saved Wi-Fi network(s)")
    print(f"{'='*50}")

    max_ssid = max(len(r["ssid"]) for r in results)
    header = f"  {'Network (SSID)':<{max_ssid}}   Password"
    print(header)
    print(f"  {'-'*max_ssid}   {'-'*30}")

    for r in results:
        print(f"  {r['ssid']:<{max_ssid}}   {r['password']}")

    print(f"{'='*50}\n")


def main():
    os_name = platform.system()
    print(f"\n[*] Wi-Fi Password Checker")
    print(f"[*] Detected OS: {os_name}")

    if os_name == "Windows":
        results = get_wifi_passwords_windows()
    elif os_name == "Darwin":
        results = get_wifi_passwords_macos()
    elif os_name == "Linux":
        results = get_wifi_passwords_linux()
    else:
        print(f"[!] Unsupported OS: {os_name}")
        sys.exit(1)

    print_results(results)


if __name__ == "__main__":
    main()

```
