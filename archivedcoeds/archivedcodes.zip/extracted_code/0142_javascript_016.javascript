   389	   color: "FF0000"      // ✅ CORRECT
   390	   color: "#FF0000"     // ❌ WRONG
   391	   