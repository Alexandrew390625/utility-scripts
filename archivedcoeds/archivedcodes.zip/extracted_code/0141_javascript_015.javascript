   370	pres.defineSlideMaster({
   371	  title: 'TITLE_SLIDE', background: { color: '283A5E' },
   372	  objects: [{
   373	    placeholder: { options: { name: 'title', type: 'title', x: 1, y: 2, w: 8, h: 2 } }
   374	  }]
   375	});
   376	
   377	let titleSlide = pres.addSlide({ masterName: "TITLE_SLIDE" });
   378	titleSlide.addText("My Title", { placeholder: "title" });
   379	