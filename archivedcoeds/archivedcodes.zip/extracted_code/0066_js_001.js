// ============================================================
//  Scratch 3.0 Custom Extension — List Range with Custom Join
//  Block: "list items [FROM] to [TO] of [LIST] joined by [SEP]"
// ============================================================

(function () {
  'use strict';

  // ---------- Extension Class ----------
  class ListRangeExtension {
    getInfo() {
      return {
        id: 'listrange',
        name: 'List Range',
        color1: '#5C6BC0',
        color2: '#3949AB',
        color3: '#283593',
        blocks: [
          {
            opcode: 'getRange',
            blockType: Scratch.BlockType.REPORTER,
            text: 'list items [FROM] to [TO] of [LIST] joined by [SEP]',
            arguments: {
              FROM: {
                type: Scratch.ArgumentType.NUMBER,
                defaultValue: 1,
              },
              TO: {
                type: Scratch.ArgumentType.NUMBER,
                defaultValue: 5,
              },
              LIST: {
                type: Scratch.ArgumentType.STRING,
                defaultValue: 'my list',
              },
              SEP: {
                type: Scratch.ArgumentType.STRING,
                defaultValue: ', ',
              },
            },
          },
          {
            opcode: 'getRangeCount',
            blockType: Scratch.BlockType.REPORTER,
            text: 'number of items [FROM] to [TO] of [LIST]',
            arguments: {
              FROM: {
                type: Scratch.ArgumentType.NUMBER,
                defaultValue: 1,
              },
              TO: {
                type: Scratch.ArgumentType.NUMBER,
                defaultValue: 5,
              },
              LIST: {
                type: Scratch.ArgumentType.STRING,
                defaultValue: 'my list',
              },
            },
          },
          '---', // separator line
          {
            opcode: 'getItem',
            blockType: Scratch.BlockType.REPORTER,
            text: 'item [INDEX] of [LIST]',
            arguments: {
              INDEX: {
                type: Scratch.ArgumentType.NUMBER,
                defaultValue: 1,
              },
              LIST: {
                type: Scratch.ArgumentType.STRING,
                defaultValue: 'my list',
              },
            },
          },
        ],
      };
    }

    // ---- Helper: resolve list by name from runtime ----
    _getList(args, util) {
      const name = args.LIST;
      const stage = util.runtime.getTargetForStage();
      const target = util.target;

      // Search in current sprite, then stage
      const findIn = (t) =>
        Object.values(t.variables).find(
          (v) => v.type === 'list' && v.name === name
        );

      return findIn(target) || findIn(stage) || null;
    }

    // ---- Block: list items FROM to TO joined by SEP ----
    getRange(args, util) {
      const from = Math.round(Number(args.FROM));
      const to   = Math.round(Number(args.TO));
      const sep  = String(args.SEP);          // user-defined separator
      const list = this._getList(args, util);

      if (!list || !list.value || list.value.length === 0) return '';

      const items = list.value;
      const len   = items.length;

      // Clamp indices to valid range (1-based → 0-based)
      const start = Math.max(1, Math.min(from, len));
      const end   = Math.max(1, Math.min(to,   len));

      // Support reverse ranges (e.g. 5 to 1)
      const slice =
        start <= end
          ? items.slice(start - 1, end)
          : items.slice(end - 1, start).reverse();

      return slice.join(sep);
    }

    // ---- Block: count items FROM to TO ----
    getRangeCount(args, util) {
      const from = Math.round(Number(args.FROM));
      const to   = Math.round(Number(args.TO));
      const list = this._getList(args, util);

      if (!list || !list.value) return 0;

      const len   = list.value.length;
      const start = Math.max(1, Math.min(from, len));
      const end   = Math.max(1, Math.min(to,   len));

      return Math.abs(end - start) + 1;
    }

    // ---- Block: get single item by index ----
    getItem(args, util) {
      const index = Math.round(Number(args.INDEX));
      const list  = this._getList(args, util);

      if (!list || !list.value) return '';
      if (index < 1 || index > list.value.length) return '';

      return list.value[index - 1];
    }
  }

  // ---------- Register the extension ----------
  Scratch.extensions.register(new ListRangeExtension());
})();
