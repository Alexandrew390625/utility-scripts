"""
Brawl Stars Club Finder
-----------------------
Searches for clubs that are:
  - Open (anyone can join)
  - Family friendly
  - Require <= 50,000 trophies

Usage:
  1. Get your API token from https://developer.brawlstars.com
  2. Run: python search_clubs.py --token YOUR_TOKEN_HERE
     Or set the env variable: BS_API_TOKEN=your_token python search_clubs.py
"""

import argparse
import os
import sys
import time

try:
    import requests
except ImportError:
    print("Missing dependency. Run: pip install requests")
    sys.exit(1)

BASE_URL = "https://api.brawlstars.com/v1"

# ── Filters ────────────────────────────────────────────────────────────────────
MY_TROPHIES        = 50_000
REQUIRED_TYPE      = "open"          # open | inviteOnly | closed
REQUIRED_BADGE     = "family"        # clubs with "family" badge / badge name containing this
MAX_TROPHY_REQ     = MY_TROPHIES     # club's required trophies must be ≤ this
# ──────────────────────────────────────────────────────────────────────────────


def get_headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def search_clubs(token: str, name_query: str = "", limit: int = 200) -> list:
    """Fetch clubs from the API with optional name filter."""
    params = {"limit": min(limit, 200)}
    if name_query:
        params["name"] = name_query

    url = f"{BASE_URL}/clubs"
    resp = requests.get(url, headers=get_headers(token), params=params, timeout=10)

    if resp.status_code == 403:
        print("❌  Access denied. Check your API token and allowed IPs.")
        sys.exit(1)
    if resp.status_code != 200:
        print(f"❌  API error {resp.status_code}: {resp.text}")
        sys.exit(1)

    return resp.json().get("items", [])


def get_club_detail(token: str, club_tag: str) -> dict | None:
    """Fetch full club details by tag."""
    encoded_tag = club_tag.replace("#", "%23")
    url = f"{BASE_URL}/clubs/{encoded_tag}"
    resp = requests.get(url, headers=get_headers(token), timeout=10)
    if resp.status_code == 200:
        return resp.json()
    return None


def is_family_friendly(club: dict) -> bool:
    """Return True if the club badge or description signals family-friendly."""
    badge = (club.get("badgeId") or "")
    name  = (club.get("name") or "").lower()
    desc  = (club.get("description") or "").lower()

    family_keywords = ["family", "friendly", "fun", "casual", "kids", "safe", "clean"]
    return any(kw in desc or kw in name for kw in family_keywords)


def passes_filters(club: dict) -> bool:
    """Apply all search filters to a club dict."""
    # Must be open
    if club.get("type", "").lower() != REQUIRED_TYPE:
        return False

    # Trophy requirement must not exceed our trophies
    trophy_req = club.get("requiredTrophies", 0)
    if trophy_req > MAX_TROPHY_REQ:
        return False

    # Family-friendly check
    if not is_family_friendly(club):
        return False

    return True


def format_club(club: dict) -> str:
    tag        = club.get("tag", "N/A")
    name       = club.get("name", "Unknown")
    members    = club.get("members", [])
    member_cnt = len(members) if isinstance(members, list) else club.get("memberCount", "?")
    trophies   = club.get("trophies", "?")
    req        = club.get("requiredTrophies", 0)
    desc       = (club.get("description") or "—")[:80]

    return (
        f"  🏆 {name} [{tag}]\n"
        f"     Members : {member_cnt}/30\n"
        f"     Trophies: {trophies:,} club | {req:,} required to join\n"
        f"     Desc    : {desc}\n"
    )


def main():
    parser = argparse.ArgumentParser(description="Brawl Stars Open & Family-Friendly Club Finder")
    parser.add_argument("--token", default=os.getenv("BS_API_TOKEN"), help="Brawl Stars API token")
    parser.add_argument("--query", default="", help="Optional club name keyword to search for")
    parser.add_argument("--limit", type=int, default=200, help="How many clubs to fetch (max 200)")
    parser.add_argument("--details", action="store_true", help="Fetch full details for each match (slower)")
    args = parser.parse_args()

    if not args.token:
        print("❌  No API token provided.\n"
              "    Use --token YOUR_TOKEN or set BS_API_TOKEN environment variable.\n"
              "    Get a token at: https://developer.brawlstars.com")
        sys.exit(1)

    print(f"\n🔍 Searching Brawl Stars clubs...")
    print(f"   Trophy requirement : ≤ {MAX_TROPHY_REQ:,}")
    print(f"   Club type          : {REQUIRED_TYPE}")
    print(f"   Filter             : family-friendly keywords\n")

    clubs = search_clubs(args.token, name_query=args.query, limit=args.limit)
    print(f"   Fetched {len(clubs)} clubs from API.\n")

    matches = []
    for club in clubs:
        if args.details:
            detail = get_club_detail(args.token, club["tag"])
            if detail:
                club = detail
            time.sleep(0.05)  # be polite to the API

        if passes_filters(club):
            matches.append(club)

    if not matches:
        print("😕  No clubs matched your filters. Try broadening the search or use --query with different keywords.")
        return

    print(f"✅  Found {len(matches)} matching club(s):\n")
    for club in matches:
        print(format_club(club))

    print(f"\nTip: Copy a tag and visit https://brawlify.com/stats/club/ to view the full club page.")


if __name__ == "__main__":
    main()
