  pip install pydub
  # then install ffmpeg from https://ffmpeg.org/download.html
  