"""
Grok PDF Challenge Checker
Reads the PDF directly — no copy-pasting, no hallucinations.
Checks every unique word against your dictionary.

Usage:
    python grok_pdf_challenge.py
    python grok_pdf_challenge.py /path/to/other_dictionary.txt
"""

import re
import os
import sys

DICTIONARY_PATH = "/storage/emulated/0/download/words_backup.txt"
PDF_PATH        = "/storage/emulated/0/download/facing.pdf"

def load_dictionary(path):
    if not os.path.exists(path):
        print(f"❌ Dictionary not found: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        words = set(line.strip().lower() for line in f if line.strip())
    print(f"📖 Loaded {len(words):,} words from dictionary.")
    return words

def extract_text_from_pdf(path):
    try:
        from pypdf import PdfReader
    except ImportError:
        print("❌ pypdf not installed. Run: pip install pypdf")
        sys.exit(1)

    if not os.path.exists(path):
        print(f"❌ PDF not found: {path}")
        sys.exit(1)

    reader = PdfReader(path)
    print(f"📄 PDF loaded: {len(reader.pages)} pages.")
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    print(f"🔤 Characters extracted from PDF: {len(text):,}")
    return text

def extract_words(text):
    raw = re.findall(r"[a-zA-Z]+", text)
    seen = set()
    unique = []
    for w in raw:
        low = w.lower()
        if low not in seen and len(low) > 2:
            seen.add(low)
            unique.append(low)
    return unique

def check(words, dictionary):
    found     = [w for w in words if w in dictionary]
    not_found = [w for w in words if w not in dictionary]
    return found, not_found

def print_results(found, not_found):
    total = len(found) + len(not_found)
    print("\n" + "=" * 60)
    print("      📄 GROK PDF CHALLENGE — CHALMERS PAPER")
    print("=" * 60)

    print(f"\n✅ FOUND in dictionary ({len(found)}/{total}):")
    for w in found:
        print(f"   ✔  {w}")

    print(f"\n❌ NOT FOUND ({len(not_found)}/{total}):")
    if not_found:
        for w in not_found:
            print(f"   ✘  {w}")
    else:
        print("   (none — perfect score!)")

    print("\n" + "=" * 60)
    score = len(found) / total * 100
    print(f"  Score: {len(found)}/{total} unique words recognized ({score:.1f}%)")
    print("=" * 60)

    print("\n📋 COPY-PASTE REPLY FOR GROK:\n")
    print(f"My dictionary recognized {len(found)}/{total} unique words ({score:.1f}%).")
    if not_found:
        print(f"Words it missed: {', '.join(not_found)}")
    else:
        print("It caught every single word. What's next?")

if __name__ == "__main__":
    dict_path = sys.argv[1] if len(sys.argv) > 1 else DICTIONARY_PATH
    pdf_path  = sys.argv[2] if len(sys.argv) > 2 else PDF_PATH

    print(f"🔍 Dictionary: {dict_path}")
    print(f"📂 PDF: {pdf_path}\n")

    dictionary = load_dictionary(dict_path)
    text       = extract_text_from_pdf(pdf_path)
    words      = extract_words(text)

    print(f"📝 Unique words extracted (length > 2): {len(words):,}\n")

    found, not_found = check(words, dictionary)
    print_results(found, not_found)
