   193	wc -l /mnt/user-data/uploads/data.csv
   194	