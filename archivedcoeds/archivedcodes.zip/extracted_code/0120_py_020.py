#!/usr/bin/env python3
"""
Chess PGN Analyzer — Ultra Fast Edition
========================================
Splits each PGN file into chunks and distributes ALL chunks across all 8 CPU
cores, with large read buffers to minimize I/O stalls.

Strategy:
  1. Scan each file for game boundaries (lines starting with "[Event ")
  2. Split into N byte-range chunks (one per CPU core)
  3. Each worker reads its chunk with a large buffer, parses with chess.pgn
  4. Merge all results and print report

Usage:
    python pgn_analyzer_ultrafast.py                    # scans current folder
    python pgn_analyzer_ultrafast.py /path/to/pgns      # scans given folder
    python pgn_analyzer_ultrafast.py a.pgn b.pgn c.pgn  # specific files
"""

import os
import re
import sys
import time
import multiprocessing as mp
from pathlib import Path
from io import BufferedReader, RawIOBase

try:
    import chess.pgn
except ImportError:
    print("❌  The 'chess' library is not installed.  Run:  pip install chess")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
READ_BUFFER_BYTES = 8 * 1024 * 1024   # 8 MB read buffer per worker
PROGRESS_EVERY    = 25_000             # print progress every N games

# ---------------------------------------------------------------------------
# ELO ranges
# ---------------------------------------------------------------------------
ELO_RANGES = [
    (0,     100,  "0-100"),
    (100,   200,  "100-200"),
    (200,   300,  "200-300"),
    (300,   400,  "300-400"),
    (400,   500,  "400-500"),
    (500,   600,  "500-600"),
    (600,   700,  "600-700"),
    (700,   800,  "700-800"),
    (800,   900,  "800-900"),
    (900,   1000, "900-1000"),
    (1000,  1100, "1000-1100"),
    (1100,  1200, "1100-1200"),
    (1200,  1300, "1200-1300"),
    (1300,  1400, "1300-1400"),
    (1400,  1500, "1400-1500"),
    (1500,  1600, "1500-1600"),
    (1600,  1700, "1600-1700"),
    (1700,  1800, "1700-1800"),
    (1800,  1900, "1800-1900"),
    (1900,  2000, "1900-2000"),
    (2000,  99999,"2000+"),
]
RANGE_LABELS = [label for *_, label in ELO_RANGES]

def elo_bucket(elo: int) -> str:
    for lo, hi, label in ELO_RANGES:
        if lo <= elo < hi:
            return label
    return "2000+"

# ---------------------------------------------------------------------------
# Stats helpers
# ---------------------------------------------------------------------------
def empty_stats() -> dict:
    return {
        "total":              0,
        "events":             {},
        "players":            {},
        "websites":           {},
        "terminations":       {},
        "time_controls":      {},
        "day_night":          {},
        "highest_elo":        -1,
        "highest_elo_player": "Unknown",
        "range_results":      {lbl: {"white": 0, "black": 0, "draw": 0, "total": 0} for lbl in RANGE_LABELS},
        "range_openings":     {lbl: {} for lbl in RANGE_LABELS},
        "range_variations":   {lbl: {} for lbl in RANGE_LABELS},
    }

def inc(d: dict, key: str, n: int = 1):
    d[key] = d.get(key, 0) + n

def safe_int(value, default: int = -1) -> int:
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def detect_website(site: str) -> str:
    s = (site or "").lower()
    if "lichess" in s:   return "lichess.org"
    if "chess.com" in s: return "chess.com"
    if s.strip():
        m = re.search(r'([\w-]+\.\w+)', s)
        if m: return m.group(1)
    return "Unknown"

def detect_termination(termination: str, result: str) -> str:
    t = (termination or "").lower()
    if "checkmate" in t or "mate" in t:   return "Checkmate"
    if "time" in t or "forfeit" in t:     return "Time forfeit"
    if "resign" in t:                      return "Resignation"
    if any(x in t for x in ("draw", "stalemate", "repetition",
                              "insufficient", "agreement")): return "Draw"
    if "abandon" in t:                     return "Abandoned"
    if result == "1/2-1/2":               return "Draw"
    return "Other / Unknown"

def is_night(hour: int) -> bool:
    return hour >= 22 or hour < 8

# ---------------------------------------------------------------------------
# File splitter — finds byte offsets of game boundaries
# ---------------------------------------------------------------------------
def find_chunk_offsets(filepath: str, num_chunks: int) -> list[tuple[int, int]]:
    """
    Divide filepath into num_chunks roughly equal byte ranges, each starting
    at a '[Event ' line boundary.
    Returns list of (start_byte, end_byte) pairs; end_byte == -1 means EOF.
    """
    file_size = os.path.getsize(filepath)
    if file_size == 0:
        return []

    approx_chunk = file_size // num_chunks
    offsets = [0]

    with open(filepath, "rb", buffering=READ_BUFFER_BYTES) as f:
        for i in range(1, num_chunks):
            target = i * approx_chunk
            f.seek(target)
            # Advance to the next '[Event ' boundary
            while True:
                line = f.readline()
                if not line:
                    break
                if line.startswith(b"[Event "):
                    offsets.append(f.tell() - len(line))
                    break

    # Build (start, end) pairs
    chunks = []
    for i, start in enumerate(offsets):
        end = offsets[i + 1] if i + 1 < len(offsets) else -1
        chunks.append((start, end))
    return chunks

# ---------------------------------------------------------------------------
# Bounded file wrapper — lets chess.pgn read only a byte slice
# ---------------------------------------------------------------------------
class SlicedFile(RawIOBase):
    """Wraps a file and exposes only bytes [start, end)."""

    def __init__(self, filepath: str, start: int, end: int):
        self._f    = open(filepath, "rb", buffering=READ_BUFFER_BYTES)
        self._end  = end   # -1 = read to EOF
        self._f.seek(start)

    def readable(self):
        return True

    def readinto(self, b):
        if self._end != -1:
            remaining = self._end - self._f.tell()
            if remaining <= 0:
                return 0
            to_read = min(len(b), remaining)
        else:
            to_read = len(b)

        data = self._f.read(to_read)
        n = len(data)
        b[:n] = data
        return n

    def close(self):
        self._f.close()
        super().close()

# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------
def process_chunk(args):
    filepath, start_byte, end_byte, worker_id, total_workers = args
    stats = empty_stats()

    label = f"Worker {worker_id:>2}/{total_workers}"
    chunk_mb = ((end_byte - start_byte) if end_byte != -1
                else os.path.getsize(filepath) - start_byte) / 1_000_000
    print(f"  [{label}] start  offset={start_byte:,}  ~{chunk_mb:.1f} MB", flush=True)

    last_time = time.time()

    raw   = SlicedFile(filepath, start_byte, end_byte)
    buf   = BufferedReader(raw, buffer_size=READ_BUFFER_BYTES)
    text  = __import__("io").TextIOWrapper(buf, encoding="utf-8", errors="replace")

    while True:
        try:
            game = chess.pgn.read_game(text)
        except Exception:
            continue
        if game is None:
            break

        stats["total"] += 1
        h = game.headers

        # Event
        event = h.get("Event", "Unknown").strip() or "Unknown"
        inc(stats["events"], event)

        # Players
        white = h.get("White", "").strip()
        black = h.get("Black", "").strip()
        if white: inc(stats["players"], white)
        if black: inc(stats["players"], black)

        # ELOs
        white_elo = safe_int(h.get("WhiteElo", ""))
        black_elo = safe_int(h.get("BlackElo", ""))

        for elo, name in [(white_elo, white), (black_elo, black)]:
            if elo > stats["highest_elo"]:
                stats["highest_elo"]        = elo
                stats["highest_elo_player"] = name or "Unknown"

        valid_elos = [e for e in [white_elo, black_elo] if e > 0]
        avg_elo    = int(sum(valid_elos) / len(valid_elos)) if valid_elos else -1
        bucket     = elo_bucket(avg_elo) if avg_elo >= 0 else None

        # Result
        result = h.get("Result", "").strip()
        if bucket:
            r = stats["range_results"][bucket]
            r["total"] += 1
            if   result == "1-0":     r["white"] += 1
            elif result == "0-1":     r["black"] += 1
            elif result == "1/2-1/2": r["draw"]  += 1

        # Opening / Variation
        opening   = h.get("Opening",  "").strip()
        variation = h.get("Variation", "").strip()
        if bucket and opening:
            inc(stats["range_openings"][bucket], opening)
            full_var = f"{opening}: {variation}" if variation else opening
            inc(stats["range_variations"][bucket], full_var)

        # Time control
        tc = h.get("TimeControl", "").strip() or "Unknown"
        inc(stats["time_controls"], tc)

        # Termination
        inc(stats["terminations"],
            detect_termination(h.get("Termination", ""), result))

        # Website
        inc(stats["websites"], detect_website(h.get("Site", "")))

        # Day / Night
        utctime = h.get("UTCTime", "").strip()
        if utctime:
            m = re.match(r'(\d{1,2}):', utctime)
            if m:
                hour = int(m.group(1))
                inc(stats["day_night"], "Night" if is_night(hour) else "Day")

        # Progress
        if stats["total"] % PROGRESS_EVERY == 0:
            now     = time.time()
            elapsed = now - last_time
            rate    = PROGRESS_EVERY / elapsed if elapsed else 0
            print(f"  [{label}] {stats['total']:>7,} games  {rate:>6,.0f} g/s", flush=True)
            last_time = now

    text.close()
    print(f"  [{label}] ✅ done — {stats['total']:,} games", flush=True)
    return stats

# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------
def merge_stats(all_stats: list) -> dict:
    merged = empty_stats()
    for s in all_stats:
        merged["total"] += s["total"]
        for key in ("events", "players", "websites", "terminations",
                    "time_controls", "day_night"):
            for k, v in s[key].items():
                merged[key][k] = merged[key].get(k, 0) + v
        if s["highest_elo"] > merged["highest_elo"]:
            merged["highest_elo"]        = s["highest_elo"]
            merged["highest_elo_player"] = s["highest_elo_player"]
        for lbl in RANGE_LABELS:
            mr = merged["range_results"][lbl]
            sr = s["range_results"][lbl]
            for k in ("white", "black", "draw", "total"):
                mr[k] += sr[k]
            for op, cnt in s["range_openings"][lbl].items():
                merged["range_openings"][lbl][op] = \
                    merged["range_openings"][lbl].get(op, 0) + cnt
            for var, cnt in s["range_variations"][lbl].items():
                merged["range_variations"][lbl][var] = \
                    merged["range_variations"][lbl].get(var, 0) + cnt
    return merged

# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------
def print_report(stats: dict, num_files: int, elapsed: float):
    total = stats["total"]
    sep   = "=" * 72
    sep2  = "-" * 72

    def pct(n, t):    return f"{n/t*100:.1f}%" if t else "N/A"
    def top_n(d, n=10): return sorted(d.items(), key=lambda x: x[1], reverse=True)[:n]

    lines = []
    def p(*a, **kw):
        import io as _io
        buf = _io.StringIO()
        print(*a, **kw, file=buf)
        s = buf.getvalue()
        lines.append(s)
        sys.stdout.write(s)

    p()
    p(sep)
    p("  ♟  CHESS PGN ANALYSIS REPORT")
    p(sep)
    p(f"  Total games analysed : {total:,}")
    p(f"  PGN files scanned    : {num_files}")
    p(f"  Time taken           : {elapsed:.1f}s")
    if elapsed > 0:
        p(f"  Parse speed          : {total/elapsed:,.0f} games/s")
    p()

    p(sep2); p("  1. MOST PLAYED EVENT TYPES"); p(sep2)
    for event, count in top_n(stats["events"]):
        p(f"  {count:>8,}  ({pct(count,total):>6})  {event}")
    p()

    p(sep2); p("  2. MOST MENTIONED PLAYER"); p(sep2)
    ps = sorted(stats["players"].items(), key=lambda x: x[1], reverse=True)
    if ps:
        p(f"  ▶  {ps[0][0]}  —  {ps[0][1]:,} appearance(s)")
        p()
        p("  Top 10 players:")
        for name, cnt in ps[:10]:
            p(f"    {cnt:>8,}  {name}")
    p()

    p(sep2); p("  3. WIN RATES BY ELO RANGE  (avg ELO of both players)"); p(sep2)
    p(f"  {'Range':<12}  {'Games':>8}  {'White':>8}  {'Black':>8}  {'Draw':>8}")
    p(f"  {'-'*12}  {'-'*8}  {'-'*8}  {'-'*8}  {'-'*8}")
    for lbl in RANGE_LABELS:
        r = stats["range_results"][lbl]; t = r["total"]
        if t == 0: continue
        p(f"  {lbl:<12}  {t:>8,}  {pct(r['white'],t):>8}  "
          f"{pct(r['black'],t):>8}  {pct(r['draw'],t):>8}")
    p()

    p(sep2); p("  4. HIGHEST ELO EVER RECORDED"); p(sep2)
    if stats["highest_elo"] > 0:
        p(f"  {stats['highest_elo_player']}  —  ELO {stats['highest_elo']}")
    else:
        p("  No ELO data found.")
    p()

    p(sep2); p("  5. MOST PLAYED OPENING PER ELO RANGE"); p(sep2)
    for lbl in RANGE_LABELS:
        ops = stats["range_openings"][lbl]
        if not ops: continue
        sops = sorted(ops.items(), key=lambda x: x[1], reverse=True)
        top_op, top_cnt = sops[0]
        tr = stats["range_results"][lbl]["total"]
        p(f"  {lbl:<12}  ▶  {top_op}  ({top_cnt:,} games, {pct(top_cnt,tr)})")
        if len(sops) > 1:
            all_str = " | ".join(f"{op} ×{n}" for op, n in sops)
            _wrap_print(p, all_str)
        p()

    p(sep2); p("  6. MOST PLAYED VARIATION PER ELO RANGE"); p(sep2)
    for lbl in RANGE_LABELS:
        vs = stats["range_variations"][lbl]
        if not vs: continue
        svs = sorted(vs.items(), key=lambda x: x[1], reverse=True)
        top_v, top_cnt = svs[0]
        tr = stats["range_results"][lbl]["total"]
        p(f"  {lbl:<12}  ▶  {top_v}  ({top_cnt:,} games, {pct(top_cnt,tr)})")
        if len(svs) > 1:
            all_str = " | ".join(f"{v} ×{n}" for v, n in svs)
            _wrap_print(p, all_str)
        p()

    p(sep2); p("  7. TIME CONTROL DISTRIBUTION"); p(sep2)
    for tc, count in top_n(stats["time_controls"], 20):
        p(f"  {count:>8,}  ({pct(count,total):>6})  {tc}")
    p()

    p(sep2); p("  8. HOW GAMES ENDED"); p(sep2)
    for term, count in top_n(stats["terminations"], 20):
        p(f"  {count:>8,}  ({pct(count,total):>6})  {term}")
    p()

    p(sep2); p("  9. WEBSITE DISTRIBUTION"); p(sep2)
    for site, count in top_n(stats["websites"]):
        p(f"  {count:>8,}  ({pct(count,total):>6})  {site}")
    p()

    p(sep2); p("  10. TIME OF DAY  (UTC — Night 22:00-08:00 / Day 08:00-22:00)"); p(sep2)
    dn = stats["day_night"]; dn_total = sum(dn.values())
    if dn_total:
        for label in ["Night", "Day"]:
            cnt = dn.get(label, 0)
            p(f"  {label:<6}  {cnt:>8,}  ({pct(cnt,dn_total):>6})")
    else:
        p("  No UTCTime tags found.")
    p()
    p(sep); p("  ✅  Analysis complete."); p(sep)

    # Save to file
    report_path = "pgn_report.txt"
    try:
        with open(report_path, "w", encoding="utf-8") as rf:
            rf.writelines(lines)
        print(f"\n📄  Report saved to: {report_path}")
    except Exception as e:
        print(f"\n⚠️  Could not save report: {e}")

def _wrap_print(p_fn, text: str, width: int = 76, indent: str = "        "):
    words = text.split(" | ")
    line  = indent
    for w in words:
        candidate = (line + w + " | ")
        if len(candidate) > width and line != indent:
            p_fn(line.rstrip(" | "))
            line = indent + w + " | "
        else:
            line = candidate
    if line.strip(" | "):
        p_fn(line.rstrip(" | "))

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    args = sys.argv[1:]

    pgn_files = []
    if args:
        for a in args:
            p = Path(a)
            if p.is_file() and p.suffix.lower() == ".pgn":
                pgn_files.append(str(p))
            elif p.is_dir():
                pgn_files.extend(str(f) for f in p.rglob("*.pgn"))
            else:
                print(f"⚠️  Skipping: {a}")
    else:
        pgn_files = [str(f) for f in Path(".").rglob("*.pgn")]

    if not pgn_files:
        print("❌  No .pgn files found.")
        sys.exit(1)

    num_files     = len(pgn_files)
    total_size_mb = sum(os.path.getsize(f) for f in pgn_files) / 1_000_000
    cpu_count     = mp.cpu_count()
    num_workers   = min(cpu_count, 8)

    # Distribute chunks: split each file into (num_workers // num_files) chunks
    # so that total chunks == num_workers (or close to it)
    chunks_per_file = max(1, num_workers // num_files)
    extra_chunks    = num_workers - chunks_per_file * num_files  # distribute remainder

    print(f"\n📂  Found {num_files} PGN file(s)  ({total_size_mb:,.1f} MB total)")
    print(f"⚙️   Using {num_workers} worker(s) across {num_files} file(s)  "
          f"(~{chunks_per_file} chunk(s)/file)")
    print(f"💾  Read buffer: {READ_BUFFER_BYTES // 1024 // 1024} MB per worker\n")

    work_items = []
    worker_id  = 1
    for i, filepath in enumerate(pgn_files):
        n_chunks = chunks_per_file + (1 if i < extra_chunks else 0)
        print(f"  Splitting {Path(filepath).name} into {n_chunks} chunk(s)...", flush=True)
        offsets = find_chunk_offsets(filepath, n_chunks)
        for start, end in offsets:
            work_items.append((filepath, start, end, worker_id, num_workers))
            worker_id += 1

    print(f"\n🚀  Launching {len(work_items)} worker(s)...\n")
    t_start = time.time()

    with mp.Pool(processes=num_workers) as pool:
        all_stats = pool.map(process_chunk, work_items)

    elapsed = time.time() - t_start
    print(f"\n🔀  Merging {len(all_stats)} result(s)...")
    merged = merge_stats(all_stats)
    print_report(merged, num_files, elapsed)


if __name__ == "__main__":
    mp.freeze_support()
    main()
