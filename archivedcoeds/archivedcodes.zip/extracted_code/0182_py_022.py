#!/usr/bin/env python3
"""
wifi_passwords.py - Check saved Wi-Fi passwords on your device.

Supports: Windows, macOS, Linux (NetworkManager)
Run with admin/root privileges for best results.
"""

import subprocess
import platform
import sys
import re


def get_wifi_passwords_windows():
    """Get saved Wi-Fi profiles and passwords on Windows."""
    results = []

    try:
        # Get all saved Wi-Fi profiles
        output = subprocess.check_output(
            ["netsh", "wlan", "show", "profiles"],
            text=True, errors="ignore"
        )
    except subprocess.CalledProcessError as e:
        print(f"[!] Error listing profiles: {e}")
        return results

    # Extract profile names
    profiles = re.findall(r"All User Profile\s*:\s*(.+)", output)

    for profile in profiles:
        profile = profile.strip()
        try:
            # Get details for each profile, including password (key=clear)
            detail = subprocess.check_output(
                ["netsh", "wlan", "show", "profile", profile, "key=clear"],
                text=True, errors="ignore"
            )
            # Find the password
            match = re.search(r"Key Content\s*:\s*(.+)", detail)
            password = match.group(1).strip() if match else "(no password / open network)"
        except subprocess.CalledProcessError:
            password = "(could not retrieve)"

        results.append({"ssid": profile, "password": password})

    return results


def get_wifi_passwords_macos():
    """Get saved Wi-Fi passwords on macOS using the security command."""
    results = []

    try:
        # List all preferred networks
        airport_output = subprocess.check_output(
            ["/System/Library/PrivateFrameworks/Apple80211.framework/Resources/airport", "-s"],
            text=True, errors="ignore"
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        airport_output = ""

    # Try to read from networksetup
    try:
        preferred = subprocess.check_output(
            ["networksetup", "-listpreferredwirelessnetworks", "en0"],
            text=True, errors="ignore"
        )
        ssids = [line.strip() for line in preferred.splitlines() if line.strip() and "Preferred" not in line]
    except subprocess.CalledProcessError:
        ssids = []

    if not ssids:
        print("[!] No saved networks found via networksetup. Try running as root.")
        return results

    for ssid in ssids:
        try:
            pw_output = subprocess.check_output(
                ["security", "find-generic-password", "-D", "AirPort network password",
                 "-a", ssid, "-w"],
                text=True, stderr=subprocess.DEVNULL
            ).strip()
            password = pw_output if pw_output else "(no password / open network)"
        except subprocess.CalledProcessError:
            password = "(not found in Keychain — may need permissions)"

        results.append({"ssid": ssid, "password": password})

    return results


def get_wifi_passwords_linux():
    """Get saved Wi-Fi passwords on Linux (NetworkManager)."""
    results = []
    import os

    nm_dir = "/etc/NetworkManager/system-connections"

    if not os.path.exists(nm_dir):
        print("[!] NetworkManager config directory not found.")
        print("    Try: /etc/NetworkManager/system-connections/")
        return results

    try:
        files = os.listdir(nm_dir)
    except PermissionError:
        print("[!] Permission denied. Please run with: sudo python3 wifi_passwords.py")
        return results

    for filename in files:
        filepath = os.path.join(nm_dir, filename)
        try:
            with open(filepath, "r", errors="ignore") as f:
                content = f.read()
        except PermissionError:
            results.append({"ssid": filename, "password": "(permission denied — run as root)"})
            continue

        ssid_match = re.search(r"^ssid\s*=\s*(.+)", content, re.MULTILINE)
        psk_match = re.search(r"^psk\s*=\s*(.+)", content, re.MULTILINE)

        ssid = ssid_match.group(1).strip() if ssid_match else filename
        password = psk_match.group(1).strip() if psk_match else "(no password / open network)"

        results.append({"ssid": ssid, "password": password})

    return results


def print_results(results):
    if not results:
        print("\n[!] No Wi-Fi profiles found.\n")
        return

    print(f"\n{'='*50}")
    print(f"  Found {len(results)} saved Wi-Fi network(s)")
    print(f"{'='*50}")

    max_ssid = max(len(r["ssid"]) for r in results)
    header = f"  {'Network (SSID)':<{max_ssid}}   Password"
    print(header)
    print(f"  {'-'*max_ssid}   {'-'*30}")

    for r in results:
        print(f"  {r['ssid']:<{max_ssid}}   {r['password']}")

    print(f"{'='*50}\n")


def main():
    os_name = platform.system()
    print(f"\n[*] Wi-Fi Password Checker")
    print(f"[*] Detected OS: {os_name}")

    if os_name == "Windows":
        results = get_wifi_passwords_windows()
    elif os_name == "Darwin":
        results = get_wifi_passwords_macos()
    elif os_name == "Linux":
        results = get_wifi_passwords_linux()
    else:
        print(f"[!] Unsupported OS: {os_name}")
        sys.exit(1)

    print_results(results)


if __name__ == "__main__":
    main()
