import json
import os
from datetime import datetime

DATA_PATH = "/storage/emulated/0/download/guild_data.json"
LEADER = "AndreiSmek"
START_SEASON = 29
START_PART = 1
PARTS_PER_SEASON = 4


def load_data():
    if os.path.exists(DATA_PATH):
        with open(DATA_PATH, "r") as f:
            return json.load(f)
    # Initialize fresh data
    return {
        "members": {},          # { username: { "total_damage": int, "parts_participated": int, "active": bool } }
        "history": [],          # [ { "season": int, "part": int, "damages": { username: int } } ]
        "current_season": START_SEASON,
        "current_part": START_PART,
        "officers": []
    }


def save_data(data):
    os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
    with open(DATA_PATH, "w") as f:
        json.dump(data, f, indent=2)
    print(f"\n✅ Data saved to {DATA_PATH}")


def get_active_members(data):
    return [name for name, info in data["members"].items() if info["active"]]


def print_members(data):
    active = get_active_members(data)
    print(f"\n📋 Current members ({len(active)}):")
    for name in sorted(active):
        role = "👑 Leader" if name == LEADER else "⚔️ Member"
        total = data["members"][name]["total_damage"]
        parts = data["members"][name]["parts_participated"]
        print(f"  {role}  {name}  |  Total DMG: {total:,}  |  Parts played: {parts}")


def handle_membership_changes(data):
    print("\n--- Membership Changes ---")
    while True:
        answer = input("Did any member LEAVE since the last session? (yes/no): ").strip().lower()
        if answer == "yes":
            name = input("  Enter the username who left: ").strip()
            if name == LEADER:
                print("  ❌ You can't remove the leader.")
            elif name in data["members"] and data["members"][name]["active"]:
                data["members"][name]["active"] = False
                print(f"  ✅ {name} marked as inactive.")
            else:
                print(f"  ⚠️ '{name}' not found or already inactive.")
        elif answer == "no":
            break
        else:
            print("  Please answer yes or no.")

    while True:
        answer = input("Did any new member JOIN since the last session? (yes/no): ").strip().lower()
        if answer == "yes":
            name = input("  Enter the new member's username: ").strip()
            if name in data["members"]:
                data["members"][name]["active"] = True
                print(f"  ✅ {name} re-activated.")
            else:
                data["members"][name] = {
                    "total_damage": 0,
                    "parts_participated": 0,
                    "active": True
                }
                print(f"  ✅ {name} added as a new member.")
        elif answer == "no":
            break
        else:
            print("  Please answer yes or no.")


def input_damage(data, season, part):
    active = get_active_members(data)
    print(f"\n--- Damage Input: Season {season} Part {part} ---")
    damages = {}

    for name in sorted(active):
        while True:
            try:
                dmg = input(f"  Damage for {name} (or press Enter to skip/0): ").strip()
                if dmg == "":
                    dmg = 0
                else:
                    dmg = int(dmg)
                damages[name] = dmg
                break
            except ValueError:
                print("  ❌ Please enter a valid number.")

    # Update totals
    for name, dmg in damages.items():
        data["members"][name]["total_damage"] += dmg
        if dmg > 0:
            data["members"][name]["parts_participated"] += 1

    # Save history entry
    data["history"].append({
        "season": season,
        "part": part,
        "timestamp": datetime.now().isoformat(),
        "damages": damages
    })

    print("\n📊 Damage recorded:")
    for name, dmg in sorted(damages.items(), key=lambda x: -x[1]):
        print(f"  {name}: {dmg:,}")

    return damages


def choose_officer(data):
    active = get_active_members(data)
    candidates = {
        name: data["members"][name]["total_damage"]
        for name in active
        if name != LEADER
    }

    if not candidates:
        print("\n⚠️ No candidates for officer (no non-leader members).")
        return

    best = max(candidates, key=candidates.get)
    print(f"\n🏆 OFFICER SUGGESTION: Based on total damage, '{best}' should be officer!")
    print(f"   Total damage: {candidates[best]:,}")

    # Show top 3
    top = sorted(candidates.items(), key=lambda x: -x[1])[:3]
    print("\n  Top 3 damage dealers:")
    for i, (name, dmg) in enumerate(top, 1):
        print(f"    {i}. {name} — {dmg:,}")

    data["officers"] = [best]


def suggest_kicks(data):
    active = get_active_members(data)
    candidates = {
        name: data["members"][name]
        for name in active
        if name != LEADER
    }

    if not candidates:
        print("\n⚠️ No members to evaluate for kicking.")
        return

    print("\n🚨 KICK SUGGESTIONS (Season 30+):")

    # Count how many season 30+ parts have been tracked
    s30_parts = [h for h in data["history"] if h["season"] >= 30]
    total_s30_parts = len(s30_parts)

    if total_s30_parts == 0:
        print("  No Season 30 data yet. Come back after recording at least one Season 30 part.")
        return

    # Calculate average damage per part from S30 onwards
    s30_damage = {}
    for entry in s30_parts:
        for name, dmg in entry["damages"].items():
            if name not in s30_damage:
                s30_damage[name] = {"total": 0, "parts": 0}
            s30_damage[name]["total"] += dmg
            if dmg > 0:
                s30_damage[name]["parts"] += 1

    scores = {}
    for name in candidates:
        d = s30_damage.get(name, {"total": 0, "parts": 0})
        avg = d["total"] / total_s30_parts if total_s30_parts > 0 else 0
        participation = (d["parts"] / total_s30_parts) * 100
        scores[name] = {"avg": avg, "participation": participation, "total": d["total"]}

    # Sort by average damage ascending (lowest = kick candidates)
    sorted_scores = sorted(scores.items(), key=lambda x: x[1]["avg"])

    print(f"  (Based on {total_s30_parts} recorded Season 30+ part(s))\n")
    print("  ⬇️  Lowest performers (consider kicking):")
    for name, s in sorted_scores[:3]:
        print(f"    {name} — Avg DMG/part: {s['avg']:,.0f} | Participation: {s['participation']:.0f}% | S30 Total: {s['total']:,}")

    print("\n  ⬆️  Top performers (keep / promote):")
    for name, s in sorted_scores[-3:][::-1]:
        print(f"    {name} — Avg DMG/part: {s['avg']:,.0f} | Participation: {s['participation']:.0f}% | S30 Total: {s['total']:,}")


def advance_season_part(data):
    season = data["current_season"]
    part = data["current_part"]

    if part < PARTS_PER_SEASON:
        data["current_part"] += 1
    else:
        data["current_season"] += 1
        data["current_part"] = 1

    print(f"\n⏭️  Advanced to Season {data['current_season']} Part {data['current_part']}")


def main():
    print("=" * 50)
    print("  🍪 Cookie Run Kingdom — Guild Damage Tracker")
    print("=" * 50)

    data = load_data()

    # Add leader if not present
    if LEADER not in data["members"]:
        data["members"][LEADER] = {
            "total_damage": 0,
            "parts_participated": 0,
            "active": True
        }

    season = data["current_season"]
    part = data["current_part"]

    print(f"\n📅 Current session: Season {season} Part {part}")
    print_members(data)

    # Ask about membership changes
    handle_membership_changes(data)
    print_members(data)

    # Ask if this part has ended
    while True:
        ended = input(f"\nHas Season {season} Part {part} ended? (yes/no): ").strip().lower()
        if ended == "yes":
            break
        elif ended == "no":
            print("\n⏸️  Part not ended yet. Come back when it's over!")
            save_data(data)
            return
        else:
            print("Please answer yes or no.")

    # Input damage
    input_damage(data, season, part)

    # Officer suggestion (always, except leader)
    choose_officer(data)

    # Kick suggestion only from Season 30 onwards
    if season >= 30 or (season == 29 and part == PARTS_PER_SEASON):
        # After S29 ends, we start suggesting kicks
        completed_seasons = [h for h in data["history"] if h["season"] >= 30]
        if season >= 30:
            suggest_kicks(data)

    # Advance to next part/season
    advance_season_part(data)

    save_data(data)
    print("\n✨ All done! Run the script again for the next part.")
    print("=" * 50)


if __name__ == "__main__":
    main()
