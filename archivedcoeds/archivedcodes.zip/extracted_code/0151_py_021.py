import numpy as np
import wave
import sys
import os

def analyze_audio(filepath):
    """
    Analyzes an audio file and reports:
    - Average loudness in dBFS
    - Whether the peak exceeds 10, 20, ..., 130 dB thresholds
    """

    ext = os.path.splitext(filepath)[1].lower()

    # --- Load audio samples ---
    if ext == ".wav":
        with wave.open(filepath, 'rb') as wf:
            n_channels = wf.getnchannels()
            sampwidth = wf.getsampwidth()
            n_frames = wf.getnframes()
            raw = wf.readframes(n_frames)

        # Convert raw bytes to numpy array
        dtype_map = {1: np.int8, 2: np.int16, 4: np.int32}
        dtype = dtype_map.get(sampwidth)
        if dtype is None:
            raise ValueError(f"Unsupported sample width: {sampwidth} bytes")

        samples = np.frombuffer(raw, dtype=dtype).astype(np.float64)

        # Normalize to [-1.0, 1.0]
        max_val = float(2 ** (8 * sampwidth - 1))
        samples /= max_val

    else:
        # Try pydub for mp3, flac, ogg, m4a, etc.
        try:
            from pydub import AudioSegment
        except ImportError:
            print("ERROR: 'pydub' is required for non-WAV files.")
            print("Install it with: pip install pydub")
            print("You may also need ffmpeg: https://ffmpeg.org/download.html")
            sys.exit(1)

        audio = AudioSegment.from_file(filepath)
        samples = np.array(audio.get_array_of_samples(), dtype=np.float64)
        max_val = float(2 ** (8 * audio.sample_width - 1))
        samples /= max_val

    if len(samples) == 0:
        raise ValueError("Audio file is empty or could not be read.")

    # --- dBFS calculations ---
    # Avoid log(0) by clamping
    epsilon = 1e-10

    rms = np.sqrt(np.mean(samples ** 2))
    avg_dbfs = 20 * np.log10(max(rms, epsilon))

    peak = np.max(np.abs(samples))
    peak_dbfs = 20 * np.log10(max(peak, epsilon))

    # dBFS → approximate dB SPL
    # 0 dBFS is roughly 96 dB SPL for 16-bit audio (common convention)
    DBFS_TO_SPL_OFFSET = 96.0
    avg_db_spl = avg_dbfs + DBFS_TO_SPL_OFFSET
    peak_db_spl = peak_dbfs + DBFS_TO_SPL_OFFSET

    # --- Report ---
    print("=" * 50)
    print(f"  Audio File: {os.path.basename(filepath)}")
    print("=" * 50)
    print(f"\n  Average Loudness : {avg_dbfs:+.2f} dBFS  (~{avg_db_spl:.1f} dB SPL)")
    print(f"  Peak Loudness    : {peak_dbfs:+.2f} dBFS  (~{peak_db_spl:.1f} dB SPL)")
    print()
    print("  Peak threshold checks (dB SPL):")
    print("  " + "-" * 32)

    thresholds = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130]
    for t in thresholds:
        status = "✅ YES" if peak_db_spl >= t else "❌ NO "
        print(f"    Over {t:>3} dB? {status}")

    print("\n" + "=" * 50)
    print("  Note: dB SPL values use the 0 dBFS ≈ 96 dB SPL")
    print("  convention (standard for 16-bit digital audio).")
    print("=" * 50)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python audio_loudness_analyzer.py <audio_file>")
        print("Supported formats: .wav, .mp3, .flac, .ogg, .m4a (mp3/flac/ogg/m4a require pydub + ffmpeg)")
        sys.exit(1)

    path = sys.argv[1]

    if not os.path.isfile(path):
        print(f"ERROR: File not found: {path}")
        sys.exit(1)

    analyze_audio(path)
