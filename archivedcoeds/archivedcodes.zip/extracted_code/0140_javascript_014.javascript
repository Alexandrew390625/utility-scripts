   331	slide.addChart(pres.charts.BAR, chartData, {
   332	  x: 0.5, y: 1, w: 9, h: 4, barDir: "col",
   333	
   334	  // Custom colors (match your presentation palette)
   335	  chartColors: ["0D9488", "14B8A6", "5EEAD4"],
   336	
   337	  // Clean background
   338	  chartArea: { fill: { color: "FFFFFF" }, roundedCorners: true },
   339	
   340	  // Muted axis labels
   341	  catAxisLabelColor: "64748B",
   342	  valAxisLabelColor: "64748B",
   343	
   344	  // Subtle grid (value axis only)
   345	  valGridLine: { color: "E2E8F0", size: 0.5 },
   346	  catGridLine: { style: "none" },
   347	
   348	  // Data labels on bars
   349	  showValue: true,
   350	  dataLabelPosition: "outEnd",
   351	  dataLabelColor: "1E293B",
   352	
   353	  // Hide legend for single series
   354	  showLegend: false,
   355	});
   356	