   147	# List all embedded images with metadata (size, color, compression)
   148	pdfimages -list document.pdf
   149	
   150	# Extract all images as PNG
   151	pdfimages -png document.pdf /tmp/img
   152	
   153	# Extract from specific pages only (pages 3-5)
   154	pdfimages -png -f 3 -l 5 document.pdf /tmp/img
   155	
   156	# Extract in original format (JPEG stays JPEG, etc.)
   157	pdfimages -all document.pdf /tmp/img
   158	