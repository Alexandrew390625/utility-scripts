    24	# Always: page count, file size, PDF version, metadata
    25	pdfinfo document.pdf
    26	
    27	# Always: quick text extraction check — is this a text PDF or a scan?
    28	pdftotext -f 1 -l 1 document.pdf - | head -20
    29	
    30	# If figures/charts may matter:
    31	pdfimages -list document.pdf
    32	
    33	# If the PDF might contain embedded files (reports, portfolios):
    34	pdfdetach -list document.pdf
    35	
    36	# If text extraction looks garbled:
    37	pdffonts document.pdf
    38	