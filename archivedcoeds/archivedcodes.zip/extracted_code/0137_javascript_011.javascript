   251	// Solid color
   252	slide.background = { color: "F1F1F1" };
   253	
   254	// Color with transparency
   255	slide.background = { color: "FF3399", transparency: 50 };
   256	
   257	// Image from URL
   258	slide.background = { path: "https://example.com/bg.jpg" };
   259	
   260	// Image from base64
   261	slide.background = { data: "image/png;base64,iVBORw0KGgo..." };
   262	