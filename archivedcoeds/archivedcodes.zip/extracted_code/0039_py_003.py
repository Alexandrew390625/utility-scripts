"""
Grok Paragraph Challenge Checker
Extracts every word from Grok's challenge paragraph and checks
which ones exist in your dictionary.
"""

import re
import os
import sys

DICTIONARY_PATH = "/storage/emulated/0/download/words_backup.txt"

GROK_PARAGRAPH = """
In the crepuscular gloaming, a sesquipedalian xenologist pondered the nyctophobia-inducing
chthonic abysses of an exoplanet, where polyphyletic extremophiles exhibited pleiotropic
phenotypic plasticity under hyperbaric conditions. The eldritch thaumaturge, wielding a
quinquireme of iridescent orichalcum, deciphered petroglyphs etched by a palaeoanthropic
hominin with hapax legomenon inscriptions. Meanwhile, in the antediluvian archives, a
flibbertigibbet philomath discovered a palimpsest containing words like
supercalifragilisticexpialidocious alongside genuine logological oddities:
pneumonoultramicroscopicsilicovolcanoconiosis, hippopotomonstrosesquipedaliophobia, and the
Welsh Llanfairpwllgwyngyllgogerychwyrndrobwllllantysiliogogogoch. The astrophysicist
calculated the Schwarzschild radius while muttering about quantum chromodynamics and the
uncomputable Busy Beaver function BB(5).
"""

def load_dictionary(path):
    if not os.path.exists(path):
        print(f"❌ Dictionary not found: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        words = set(line.strip().lower() for line in f if line.strip())
    print(f"📖 Loaded {len(words):,} words from dictionary.\n")
    return words

def extract_words(text):
    # Extract only alphabetic words (no numbers, no punctuation)
    raw = re.findall(r"[a-zA-Z]+", text)
    # Deduplicate but preserve order
    seen = set()
    unique = []
    for w in raw:
        low = w.lower()
        if low not in seen:
            seen.add(low)
            unique.append(low)
    return unique

def check(words, dictionary):
    found = [w for w in words if w in dictionary]
    not_found = [w for w in words if w not in dictionary]
    return found, not_found

def print_results(found, not_found):
    total = len(found) + len(not_found)

    print("=" * 60)
    print("        🔥 GROK PARAGRAPH CHALLENGE RESULTS")
    print("=" * 60)

    print(f"\n✅ FOUND in dictionary ({len(found)}/{total}):")
    for w in found:
        print(f"   ✔  {w}")

    print(f"\n❌ NOT FOUND / Unknown ({len(not_found)}/{total}):")
    if not_found:
        for w in not_found:
            print(f"   ✘  {w}")
    else:
        print("   (none — perfect score!)")

    print("\n" + "=" * 60)
    score = len(found) / total * 100
    print(f"  Score: {len(found)}/{total} words recognized ({score:.1f}%)")
    print("=" * 60)

    # Reply text you can copy-paste back to Grok
    print("\n📋 COPY-PASTE REPLY FOR GROK:\n")
    print(f"My dictionary recognized {len(found)}/{total} unique words ({score:.1f}%).")
    if not_found:
        print(f"The ones it missed: {', '.join(not_found)}")
    else:
        print("It caught everything. Bring on the next round!")

if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else DICTIONARY_PATH
    print(f"🔍 Using dictionary: {path}\n")

    dictionary = load_dictionary(path)
    words = extract_words(GROK_PARAGRAPH)
    print(f"📝 Unique words extracted from paragraph: {len(words)}\n")

    found, not_found = check(words, dictionary)
    print_results(found, not_found)
