   194	# List all attachments
   195	pdfdetach -list document.pdf
   196	
   197	# Extract all attachments to a directory
   198	mkdir -p /tmp/attachments
   199	pdfdetach -saveall -o /tmp/attachments/ document.pdf
   200	
   201	# Extract a specific attachment by number (1-based index from -list output)
   202	pdfdetach -save 1 -o /tmp/attachment.pdf document.pdf
   203	