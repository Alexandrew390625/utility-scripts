# If you get a "spawn" error, try:
python pgn_analyzer_fast.py file1.pgn file2.pgn file3.pgn
# It should still work — mp.freeze_support() is already included