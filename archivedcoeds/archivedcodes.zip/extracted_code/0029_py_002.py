"""
Word Checker — ChatGPT Challenge Edition
Checks which words from the challenge list exist in your dictionary file.
"""

import os
import sys

DICTIONARY_PATH = "/storage/emulated/0/download/words_backup.txt"

CHALLENGE_WORDS = [
    "syzygy",
    "floccinaucinihilipilification",
    "antidisestablishmentarianism",
    "pneumatoultramicroscopicsilicovolcanoconiosis",
    "qiviut",
    "susurrus",
    "callipygian",
    "petrichor",
    "defenestration",
    "ultracrepidarian",
    "xylophagous",
    "psithurism",
    "aeipathy",
    "oubliette",
    "kakorrhaphiophobia",
    "honorificabilitudinitatibus",
    "zwitterion",
    "thaumaturgy",
    "quomodocunquizing",
    "hippopotomonstrosesquipedaliophobia",
    "yeet",
    "rizz",
    "unalive",
    "skibidi",
    "gyatt",
    "blorbo",
]

def load_dictionary(path):
    if not os.path.exists(path):
        print(f"❌ Dictionary file not found: {path}")
        print("   Make sure the path is correct and the file exists.")
        sys.exit(1)

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        words = set(line.strip().lower() for line in f if line.strip())

    print(f"📖 Loaded {len(words):,} words from dictionary.\n")
    return words

def check_words(dictionary):
    found = []
    not_found = []

    for word in CHALLENGE_WORDS:
        if word.lower() in dictionary:
            found.append(word)
        else:
            not_found.append(word)

    return found, not_found

def print_results(found, not_found):
    total = len(CHALLENGE_WORDS)
    print("=" * 55)
    print("        🏆 CHATGPT WORD CHALLENGE RESULTS")
    print("=" * 55)

    print(f"\n✅ FOUND in your dictionary ({len(found)}/{total}):")
    if found:
        for w in found:
            print(f"   ✔  {w}")
    else:
        print("   (none)")

    print(f"\n❌ NOT FOUND in your dictionary ({len(not_found)}/{total}):")
    if not_found:
        for w in not_found:
            print(f"   ✘  {w}")
    else:
        print("   (none — your dictionary is insane!)")

    print("\n" + "=" * 55)
    score = len(found) / total * 100
    print(f"  Score: {len(found)}/{total} words found ({score:.1f}%)")
    print("=" * 55)

if __name__ == "__main__":
    # Allow overriding the path via command line argument
    path = sys.argv[1] if len(sys.argv) > 1 else DICTIONARY_PATH

    print(f"🔍 Checking dictionary: {path}\n")
    dictionary = load_dictionary(path)
    found, not_found = check_words(dictionary)
    print_results(found, not_found)
