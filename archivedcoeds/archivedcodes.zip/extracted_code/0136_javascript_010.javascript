   226	const iconData = await iconToBase64Png(FaCheckCircle, "#4472C4", 256);
   227	
   228	slide.addImage({
   229	  data: iconData,
   230	  x: 1, y: 1, w: 0.5, h: 0.5  // Size in inches
   231	});
   232	