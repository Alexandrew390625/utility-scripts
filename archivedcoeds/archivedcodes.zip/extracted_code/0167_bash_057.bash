   212	jq 'type' /mnt/user-data/uploads/data.json
   213	jq 'if type == "array" then length elif type == "object" then keys else . end' /mnt/user-data/uploads/data.json
   214	