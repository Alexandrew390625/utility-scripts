"""
bytes_to_minecraft.py — Convert any file's raw bytes into a Minecraft 1.12.2 world.

Each byte (0-255) maps directly to a block ID.
Bytes fill X first, then Z (new row), then Y (new layer upward).
Byte 0 = air = left empty.

No external libraries needed — writes NBT binary directly.

HOW TO USE:
1. Set INPUT_FILE to any file you want to convert.
2. Set OUTPUT_DIR to a new empty folder name.
3. Run, then copy OUTPUT_DIR into your Minecraft saves folder.
"""

import os, sys, math, struct, zlib, gzip, io

# ── SETTINGS ──────────────────────────────────────────────────────────────────

INPUT_FILE = "/storage/emulated/0/Download/Bonnie's Lullaby.mid"
OUTPUT_DIR = "/storage/emulated/0/Download/ByteWorld"

FORCE_SIDE = None   # None = auto-calculate. Set an integer to override.

# ── BLOCK ID NAMES (just for the printed summary) ─────────────────────────────

BLOCK_NAMES = {
    0:"air",1:"stone",2:"grass",3:"dirt",4:"cobblestone",5:"planks",
    6:"sapling",7:"bedrock",8:"flowing_water",9:"water",10:"flowing_lava",
    11:"lava",12:"sand",13:"gravel",14:"gold_ore",15:"iron_ore",
    16:"coal_ore",17:"log",18:"leaves",19:"sponge",20:"glass",
    21:"lapis_ore",22:"lapis_block",24:"sandstone",25:"noteblock",
    30:"web",31:"tallgrass",35:"wool",37:"yellow_flower",38:"red_flower",
    39:"brown_mushroom",40:"red_mushroom",41:"gold_block",42:"iron_block",
    43:"double_stone_slab",44:"stone_slab",45:"brick_block",46:"tnt",
    47:"bookshelf",48:"mossy_cobblestone",49:"obsidian",50:"torch",
    51:"fire",56:"diamond_ore",57:"diamond_block",73:"redstone_ore",
    74:"lit_redstone_ore",78:"snow_layer",79:"ice",80:"snow",
    81:"cactus",82:"clay",87:"netherrack",88:"soul_sand",89:"glowstone",
    98:"stonebrick",103:"melon_block",110:"mycelium",112:"nether_brick",
    121:"end_stone",129:"emerald_ore",133:"emerald_block",138:"beacon",
    152:"redstone_block",153:"quartz_ore",155:"quartz_block",
    159:"stained_hardened_clay",168:"prismarine",169:"sea_lantern",
    170:"hay_block",172:"hardened_clay",173:"coal_block",174:"packed_ice",
    201:"purpur_block",213:"magma",214:"nether_wart_block",
    215:"red_nether_brick",216:"bone_block",
}

SECTOR = 4096

# ── PURE BINARY NBT WRITER ────────────────────────────────────────────────────
# NBT tag type IDs
TAG_BYTE       = 1
TAG_SHORT      = 2
TAG_INT        = 3
TAG_LONG       = 4
TAG_FLOAT      = 5
TAG_DOUBLE     = 6
TAG_BYTE_ARRAY = 7
TAG_STRING     = 8
TAG_LIST       = 9
TAG_COMPOUND   = 10
TAG_INT_ARRAY  = 11

def nbt_name(name: str) -> bytes:
    """Encode a tag name: 2-byte length + UTF-8 bytes."""
    encoded = name.encode("utf-8")
    return struct.pack(">H", len(encoded)) + encoded

def nbt_byte(name, value):
    return bytes([TAG_BYTE]) + nbt_name(name) + struct.pack(">b", value)

def nbt_short(name, value):
    return bytes([TAG_SHORT]) + nbt_name(name) + struct.pack(">h", value)

def nbt_int(name, value):
    return bytes([TAG_INT]) + nbt_name(name) + struct.pack(">i", value)

def nbt_long(name, value):
    return bytes([TAG_LONG]) + nbt_name(name) + struct.pack(">q", value)

def nbt_string(name, value):
    enc = value.encode("utf-8")
    return bytes([TAG_STRING]) + nbt_name(name) + struct.pack(">H", len(enc)) + enc

def nbt_byte_array(name, data: bytes):
    return (bytes([TAG_BYTE_ARRAY]) + nbt_name(name)
            + struct.pack(">i", len(data)) + bytes(data))

def nbt_int_array(name, values: list):
    payload = struct.pack(f">{len(values)}i", *values)
    return bytes([TAG_INT_ARRAY]) + nbt_name(name) + struct.pack(">i", len(values)) + payload

def nbt_list(name, element_type, elements: list):
    """elements = list of raw payload bytes (no tag id, no name)."""
    header = bytes([TAG_LIST]) + nbt_name(name)
    header += bytes([element_type]) + struct.pack(">i", len(elements))
    return header + b"".join(elements)

def nbt_compound(name, *fields):
    """fields = pre-serialized tag bytes. Ends with TAG_End (0x00)."""
    header = bytes([TAG_COMPOUND]) + nbt_name(name)
    return header + b"".join(fields) + b"\x00"

def nbt_compound_payload(*fields):
    """Just the payload of a compound (no tag id, no name) for use inside lists."""
    return b"".join(fields) + b"\x00"

# ── CHUNK BUILDER ─────────────────────────────────────────────────────────────

def build_chunk_nbt(chunk_x, chunk_z, blocks_3d) -> bytes:
    """
    Serialize a complete pre-1.13 chunk as raw NBT bytes (uncompressed).
    blocks_3d[y][z][x] = block ID 0-255
    """
    max_y = len(blocks_3d)
    num_sections = math.ceil(max_y / 16)

    section_payloads = []

    for sec_y in range(num_sections):
        y_start = sec_y * 16
        y_end   = min(y_start + 16, max_y)

        block_arr = bytearray(4096)
        has_blocks = False

        for y_local in range(y_end - y_start):
            y = y_start + y_local
            for z in range(16):
                for x in range(16):
                    bid = blocks_3d[y][z][x] if y < max_y else 0
                    if bid:
                        has_blocks = True
                    idx = (y_local << 8) | (z << 4) | x
                    block_arr[idx] = bid

        if not has_blocks:
            continue

        data_arr  = bytearray(2048)   # all metadata = 0
        light_arr = bytearray([255] * 2048)

        sec_payload = nbt_compound_payload(
            nbt_byte("Y", sec_y),
            nbt_byte_array("Blocks", block_arr),
            nbt_byte_array("Data", data_arr),
            nbt_byte_array("BlockLight", light_arr),
            nbt_byte_array("SkyLight", light_arr),
        )
        section_payloads.append(sec_payload)

    # Sections list (TAG_List of TAG_Compound)
    sections_tag = nbt_list("Sections", TAG_COMPOUND, section_payloads)

    # Empty lists for Entities and TileEntities
    entities_tag     = nbt_list("Entities",     TAG_COMPOUND, [])
    tile_ent_tag     = nbt_list("TileEntities", TAG_COMPOUND, [])

    biomes_tag    = nbt_byte_array("Biomes",    bytes([1] * 256))
    heightmap_tag = nbt_int_array("HeightMap",  [max_y] * 256)

    level_payload = nbt_compound_payload(
        nbt_int("xPos", chunk_x),
        nbt_int("zPos", chunk_z),
        nbt_long("LastUpdate", 0),
        nbt_byte("LightPopulated", 1),
        nbt_byte("TerrainPopulated", 1),
        nbt_long("InhabitedTime", 0),
        biomes_tag,
        heightmap_tag,
        sections_tag,
        entities_tag,
        tile_ent_tag,
    )

    # Wrap Level compound inside root compound
    level_tag = bytes([TAG_COMPOUND]) + nbt_name("Level") + level_payload
    dv_tag    = nbt_int("DataVersion", 1343)

    # Root compound (unnamed = empty name)
    root = (bytes([TAG_COMPOUND]) + nbt_name("")
            + dv_tag + level_tag + b"\x00")

    return root


def compress_chunk(nbt_bytes: bytes) -> bytes:
    """Compress chunk NBT and wrap in region format (length + compression byte)."""
    compressed = zlib.compress(nbt_bytes)
    return struct.pack(">I", len(compressed) + 1) + b'\x02' + compressed


# ── REGION FILE WRITER ────────────────────────────────────────────────────────

def write_region_file(path, chunks: dict):
    """
    chunks = {(local_cx, local_cz): compressed_chunk_bytes}
    """
    placements = {}
    current_sector = 2

    for (cx, cz), data in chunks.items():
        padded = math.ceil(len(data) / SECTOR) * SECTOR
        count  = padded // SECTOR
        placements[(cx, cz)] = (current_sector, count, data, padded)
        current_sector += count

    # Header: 4096 bytes locations + 4096 bytes timestamps
    header = bytearray(SECTOR * 2)
    for (cx, cz), (offset, count, _, _) in placements.items():
        idx = (cx + cz * 32) * 4
        header[idx:idx+4] = struct.pack(">I", (offset << 8) | (count & 0xFF))

    with open(path, "wb") as f:
        f.write(bytes(header))
        for (cx, cz), (offset, count, data, padded) in placements.items():
            f.seek(offset * SECTOR)
            f.write(data)
            remainder = padded - len(data)
            if remainder > 0:
                f.write(b'\x00' * remainder)


# ── LEVEL.DAT WRITER ──────────────────────────────────────────────────────────

def write_level_dat(output_dir, world_name):
    data_payload = nbt_compound_payload(
        nbt_string("LevelName", world_name),
        nbt_int("version", 19133),
        nbt_int("DataVersion", 1343),
        nbt_int("GameType", 1),          # Creative
        nbt_byte("allowCommands", 1),
        nbt_long("Time", 6000),           # Noon
        nbt_int("SpawnX", 8),
        nbt_int("SpawnY", 64),
        nbt_int("SpawnZ", 8),
        nbt_string("generatorName", "flat"),
        nbt_long("RandomSeed", 0),
    )
    data_tag = bytes([TAG_COMPOUND]) + nbt_name("Data") + data_payload
    root = bytes([TAG_COMPOUND]) + nbt_name("") + data_tag + b"\x00"

    path = os.path.join(output_dir, "level.dat")
    with gzip.open(path, "wb") as f:
        f.write(root)
    print("  Wrote level.dat")


# ── MAIN ──────────────────────────────────────────────────────────────────────

def bytes_to_world(input_file, output_dir, force_side=None):
    print(f"\nReading: {input_file}")
    with open(input_file, "rb") as f:
        raw_bytes = f.read()

    total_bytes = len(raw_bytes)
    print(f"File size: {total_bytes:,} bytes")

    side = force_side if force_side else max(1, math.ceil(total_bytes ** (1/3)))
    total_cells = side ** 3
    print(f"Cube size: {side} x {side} x {side} = {total_cells:,} cells")

    # Pad or truncate to exactly fit the cube
    if total_bytes > total_cells:
        print(f"Truncating to {total_cells:,} bytes")
        raw_bytes = raw_bytes[:total_cells]
    elif total_bytes < total_cells:
        raw_bytes = raw_bytes + b'\x00' * (total_cells - total_bytes)

    # Build 3D array [y][z][x]
    print("Building 3D block layout...")
    blocks_3d = [[[0]*side for _ in range(side)] for _ in range(side)]
    for i, b in enumerate(raw_bytes):
        y =  i // (side * side)
        z = (i //  side) % side
        x =  i % side
        blocks_3d[y][z][x] = b

    non_air  = sum(1 for i, b in enumerate(raw_bytes) if b != 0)
    used_ids = sorted(set(raw_bytes) - {0})
    print(f"Non-air blocks: {non_air:,}")
    print(f"Unique block IDs: {len(used_ids)}")
    for bid in used_ids[:10]:
        print(f"  ID {bid:3d} = {BLOCK_NAMES.get(bid, f'unknown_{bid}')}")
    if len(used_ids) > 10:
        print(f"  ... and {len(used_ids)-10} more")

    # Setup output folders
    region_dir = os.path.join(output_dir, "region")
    os.makedirs(region_dir, exist_ok=True)
    print(f"\nOutput: {output_dir}")

    write_level_dat(output_dir, "ByteWorld")

    chunks_needed = max(1, math.ceil(side / 16))
    print(f"Chunks per axis: {chunks_needed}")

    # Build and write region files
    region_chunks = {}
    total_chunks = chunks_needed * chunks_needed
    done = 0

    for cz in range(chunks_needed):
        for cx in range(chunks_needed):
            rx, rz = cx // 32, cz // 32
            lcx, lcz = cx % 32, cz % 32

            # Slice out this chunk's block data
            chunk_blocks = []
            for y in range(side):
                layer = []
                for z in range(16):
                    row = []
                    for x in range(16):
                        bx = cx * 16 + x
                        bz = cz * 16 + z
                        row.append(blocks_3d[y][bz][bx] if bx < side and bz < side else 0)
                    layer.append(row)
                chunk_blocks.append(layer)

            nbt_bytes  = build_chunk_nbt(cx, cz, chunk_blocks)
            chunk_data = compress_chunk(nbt_bytes)

            key = (rx, rz)
            if key not in region_chunks:
                region_chunks[key] = {}
            region_chunks[key][(lcx, lcz)] = chunk_data

            done += 1
            if done % max(1, total_chunks // 5) == 0 or done == total_chunks:
                print(f"  Chunks: {done}/{total_chunks}")

    print("\nWriting region files...")
    for (rx, rz), chunks in region_chunks.items():
        path = os.path.join(region_dir, f"r.{rx}.{rz}.mca")
        write_region_file(path, chunks)
        print(f"  Wrote r.{rx}.{rz}.mca")

    print(f"\nDone! Copy '{output_dir}' to your Minecraft saves folder.")
    print(f"Cube is at X=0 Y=0 Z=0, size {side}x{side}x{side}.")
    print(f"Spawn is at X=8 Y=64 Z=8 — fly down to Y=0 to see it.")


if __name__ == "__main__":
    if not os.path.isfile(INPUT_FILE):
        print(f"ERROR: File not found: {INPUT_FILE}")
        sys.exit(1)
    bytes_to_world(INPUT_FILE, OUTPUT_DIR, force_side=FORCE_SIDE)
