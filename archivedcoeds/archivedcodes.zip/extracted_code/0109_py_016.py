"""
bytes_to_minecraft.py — Convert any file's raw bytes into a Minecraft 1.12.2 world.

Each byte (0–255) maps directly to a block ID.
Bytes are arranged as a 3D cube: X fills first, then Z (new row), then Y (new layer).
Byte 0 = air = left empty.

Requirements:
    pip install nbt

HOW TO USE:
1. Set INPUT_FILE to any file you want to convert.
2. Set OUTPUT_DIR to a new folder — this becomes your Minecraft world folder.
3. Run the script, then copy OUTPUT_DIR into your Minecraft saves folder.
"""

import os, sys, math, struct, zlib, io
from nbt import nbt as nbtlib

# ── SETTINGS ──────────────────────────────────────────────────────────────────

INPUT_FILE = "/storage/emulated/0/Download/yourfile.txt"   # ← change this
OUTPUT_DIR = "/storage/emulated/0/Download/ByteWorld"      # ← change this

# Cube side length — auto-calculated from file size, or set manually (max 256)
# e.g. FORCE_SIDE = 64 means a 64x64x64 cube (262144 bytes used)
FORCE_SIDE = None   # None = auto

# ── BLOCK ID → NAME (for reference) ──────────────────────────────────────────

BLOCK_NAMES = {
    0:"air",1:"stone",2:"grass",3:"dirt",4:"cobblestone",5:"planks",
    6:"sapling",7:"bedrock",8:"flowing_water",9:"water",10:"flowing_lava",
    11:"lava",12:"sand",13:"gravel",14:"gold_ore",15:"iron_ore",
    16:"coal_ore",17:"log",18:"leaves",19:"sponge",20:"glass",
    21:"lapis_ore",22:"lapis_block",24:"sandstone",25:"noteblock",
    30:"web",31:"tallgrass",35:"wool",37:"yellow_flower",38:"red_flower",
    39:"brown_mushroom",40:"red_mushroom",41:"gold_block",42:"iron_block",
    43:"double_stone_slab",44:"stone_slab",45:"brick_block",46:"tnt",
    47:"bookshelf",48:"mossy_cobblestone",49:"obsidian",50:"torch",
    51:"fire",56:"diamond_ore",57:"diamond_block",73:"redstone_ore",
    74:"lit_redstone_ore",78:"snow_layer",79:"ice",80:"snow",
    81:"cactus",82:"clay",87:"netherrack",88:"soul_sand",89:"glowstone",
    98:"stonebrick",103:"melon_block",110:"mycelium",112:"nether_brick",
    121:"end_stone",129:"emerald_ore",133:"emerald_block",
    138:"beacon",152:"redstone_block",153:"quartz_ore",155:"quartz_block",
    159:"stained_hardened_clay",168:"prismarine",169:"sea_lantern",
    170:"hay_block",172:"hardened_clay",173:"coal_block",174:"packed_ice",
    201:"purpur_block",213:"magma",214:"nether_wart_block",
    215:"red_nether_brick",216:"bone_block",
}

# ── CORE LOGIC ────────────────────────────────────────────────────────────────

SECTOR = 4096

def make_level_dat(world_name, output_dir):
    """Create a minimal level.dat so Minecraft recognises the world."""
    root = nbtlib.NBTFile()
    data = nbtlib.TAG_Compound()
    data.name = "Data"
    data["LevelName"]    = nbtlib.TAG_String(world_name)
    data["version"]      = nbtlib.TAG_Int(19133)        # Anvil format
    data["DataVersion"]  = nbtlib.TAG_Int(1343)         # 1.12.2
    data["GameType"]     = nbtlib.TAG_Int(1)            # Creative
    data["allowCommands"]= nbtlib.TAG_Byte(1)
    data["Time"]         = nbtlib.TAG_Long(6000)        # Noon
    data["SpawnX"]       = nbtlib.TAG_Int(8)
    data["SpawnY"]       = nbtlib.TAG_Int(64)
    data["SpawnZ"]       = nbtlib.TAG_Int(8)
    data["generatorName"]= nbtlib.TAG_String("flat")
    data["RandomSeed"]   = nbtlib.TAG_Long(0)
    root["Data"] = data

    path = os.path.join(output_dir, "level.dat")
    root.write_file(filename=path)
    print(f"  Wrote level.dat")


def make_chunk_nbt(chunk_x, chunk_z, blocks_3d):
    """
    Build a pre-1.13 chunk NBT from a 3D array.
    blocks_3d[y][z][x] = block_id (0–255)
    Covers Y 0–127 (8 sections of 16).
    """
    root = nbtlib.NBTFile()
    root["DataVersion"] = nbtlib.TAG_Int(1343)

    level = nbtlib.TAG_Compound()
    level.name = "Level"
    level["xPos"]             = nbtlib.TAG_Int(chunk_x)
    level["zPos"]             = nbtlib.TAG_Int(chunk_z)
    level["LastUpdate"]       = nbtlib.TAG_Long(0)
    level["LightPopulated"]   = nbtlib.TAG_Byte(1)
    level["TerrainPopulated"] = nbtlib.TAG_Byte(1)
    level["InhabitedTime"]    = nbtlib.TAG_Long(0)
    level["Biomes"]           = nbtlib.TAG_Byte_Array([1] * 256)  # Plains
    level["HeightMap"]        = nbtlib.TAG_Int_Array([128] * 256)
    level["Entities"]         = nbtlib.TAG_List(type=nbtlib.TAG_Compound)
    level["TileEntities"]     = nbtlib.TAG_List(type=nbtlib.TAG_Compound)

    sections = nbtlib.TAG_List(type=nbtlib.TAG_Compound)

    max_y = len(blocks_3d)
    num_sections = math.ceil(max_y / 16)

    for section_y in range(num_sections):
        y_start = section_y * 16
        y_end   = min(y_start + 16, max_y)

        # Build flat 4096-byte Blocks array (YZX order)
        block_arr = bytearray(4096)
        data_arr  = bytearray(2048)   # 4-bit metadata, all 0

        has_blocks = False
        for y_local in range(y_end - y_start):
            y = y_start + y_local
            for z in range(16):
                for x in range(16):
                    bid = blocks_3d[y][z][x] if y < len(blocks_3d) else 0
                    if bid != 0:
                        has_blocks = True
                    idx = (y_local << 8) | (z << 4) | x
                    block_arr[idx] = bid

        if not has_blocks:
            continue  # skip empty sections

        section = nbtlib.TAG_Compound()
        section["Y"]          = nbtlib.TAG_Byte(section_y)
        section["Blocks"]     = nbtlib.TAG_Byte_Array(list(block_arr))
        section["Data"]       = nbtlib.TAG_Byte_Array(list(data_arr))
        section["BlockLight"] = nbtlib.TAG_Byte_Array([255] * 2048)
        section["SkyLight"]   = nbtlib.TAG_Byte_Array([255] * 2048)
        sections.append(section)

    level["Sections"] = sections
    root["Level"] = level
    return root


def write_chunk_to_region(region_data: dict, chunk_x, chunk_z, nbt_chunk):
    """Serialize a chunk NBT and store it in region_data dict."""
    buf = io.BytesIO()
    nbt_chunk.write_file(buffer=buf)
    raw = buf.getvalue()
    compressed = zlib.compress(raw)
    # 4-byte length + 1-byte compression type (2=zlib) + data
    chunk_bytes = struct.pack(">I", len(compressed) + 1) + b'\x02' + compressed
    region_data[(chunk_x % 32, chunk_z % 32)] = chunk_bytes


def write_region_file(path, chunks: dict):
    """Write a complete .mca region file from a dict of {(cx,cz): bytes}."""
    # Calculate sectors needed for each chunk
    placements = {}  # (cx,cz) -> (sector_offset, sector_count)
    current_sector = 2  # sectors 0 and 1 are the header

    for (cx, cz), data in chunks.items():
        # Pad to sector boundary
        padded_len = math.ceil(len(data) / SECTOR) * SECTOR
        sector_count = padded_len // SECTOR
        placements[(cx, cz)] = (current_sector, sector_count, data, padded_len)
        current_sector += sector_count

    # Build header (8192 bytes = 2 sectors)
    header = bytearray(SECTOR * 2)
    for (cx, cz), (offset, count, _, _) in placements.items():
        entry_idx = (cx + cz * 32) * 4
        val = (offset << 8) | (count & 0xFF)
        header[entry_idx:entry_idx+4] = struct.pack(">I", val)

    with open(path, "wb") as f:
        f.write(bytes(header))
        for (cx, cz), (offset, count, data, padded_len) in placements.items():
            f.seek(offset * SECTOR)
            f.write(data)
            # Pad to sector boundary
            remainder = padded_len - len(data)
            if remainder > 0:
                f.write(b'\x00' * remainder)


def bytes_to_world(input_file, output_dir, force_side=None):
    print(f"\nReading: {input_file}")
    with open(input_file, "rb") as f:
        raw_bytes = f.read()

    total_bytes = len(raw_bytes)
    print(f"File size: {total_bytes:,} bytes")

    # Calculate cube side length
    if force_side:
        side = force_side
    else:
        side = math.ceil(total_bytes ** (1/3))
        side = max(side, 1)

    total_cells = side * side * side
    print(f"Cube size: {side} x {side} x {side} = {total_cells:,} cells")

    if total_bytes > total_cells:
        print(f"Warning: file too large for cube, truncating to {total_cells:,} bytes")
        raw_bytes = raw_bytes[:total_cells]
    elif total_bytes < total_cells:
        # Pad with zeros (air)
        raw_bytes = raw_bytes + b'\x00' * (total_cells - total_bytes)

    # Build 3D block array [y][z][x]
    # Layout: X fills first (fastest), then Z, then Y (slowest = layers)
    print("Building 3D block layout...")
    blocks_3d = [[[0]*side for _ in range(side)] for _ in range(side)]
    for i, byte_val in enumerate(raw_bytes):
        y = i // (side * side)
        z = (i // side) % side
        x = i % side
        blocks_3d[y][z][x] = byte_val   # 0 stays as air

    # Count non-air blocks
    non_air = sum(
        1 for y in range(side) for z in range(side) for x in range(side)
        if blocks_3d[y][z][x] != 0
    )
    print(f"Non-air blocks to place: {non_air:,}")

    # Count unique block types used
    used_ids = set(raw_bytes) - {0}
    print(f"Unique block IDs used: {len(used_ids)}")
    for bid in sorted(used_ids)[:10]:
        name = BLOCK_NAMES.get(bid, f"unknown_{bid}")
        print(f"  ID {bid:3d} = {name}")
    if len(used_ids) > 10:
        print(f"  ... and {len(used_ids)-10} more")

    # Create world directory structure
    region_dir = os.path.join(output_dir, "region")
    os.makedirs(region_dir, exist_ok=True)
    print(f"\nOutput world: {output_dir}")

    # Write level.dat
    make_level_dat("ByteWorld", output_dir)

    # Figure out which region files we need
    # Each region covers 32x32 chunks, each chunk is 16x16 blocks
    chunks_needed = math.ceil(side / 16)
    regions_needed = math.ceil(chunks_needed / 32)
    print(f"Chunks per axis: {chunks_needed}, Region files per axis: {regions_needed}")

    # Group chunks by region
    region_chunks = {}  # (rx, rz) -> {(lcx, lcz): blocks_chunk}

    total_chunks = chunks_needed * chunks_needed
    done = 0

    for chunk_z in range(chunks_needed):
        for chunk_x in range(chunks_needed):
            rx = chunk_x // 32
            rz = chunk_z // 32
            lcx = chunk_x % 32
            lcz = chunk_z % 32

            # Extract this chunk's 16x16xside block column
            chunk_blocks = []
            for y in range(side):
                layer = []
                for z in range(16):
                    row = []
                    for x in range(16):
                        bx = chunk_x * 16 + x
                        bz = chunk_z * 16 + z
                        if bx < side and bz < side:
                            row.append(blocks_3d[y][bz][bx])
                        else:
                            row.append(0)
                    layer.append(row)
                chunk_blocks.append(layer)

            key = (rx, rz)
            if key not in region_chunks:
                region_chunks[key] = {}
            region_chunks[key][(lcx, lcz)] = chunk_blocks

            done += 1
            if done % 50 == 0 or done == total_chunks:
                print(f"  Prepared chunk {done}/{total_chunks}...")

    # Write region files
    print("\nWriting region files...")
    for (rx, rz), chunks in region_chunks.items():
        region_data = {}
        for (lcx, lcz), chunk_blocks in chunks.items():
            global_cx = rx * 32 + lcx
            global_cz = rz * 32 + lcz
            nbt_chunk = make_chunk_nbt(global_cx, global_cz, chunk_blocks)
            write_chunk_to_region(region_data, lcx, lcz, nbt_chunk)

        region_path = os.path.join(region_dir, f"r.{rx}.{rz}.mca")
        write_region_file(region_path, region_data)
        print(f"  Wrote {os.path.basename(region_path)}")

    print("\n✓ Done! Copy the folder to your Minecraft saves directory.")
    print(f"  World folder: {output_dir}")
    print(f"  Spawn point is at X=8 Y=64 Z=8 — you may need to fly up/down to see the cube.")
    print(f"  The cube starts at X=0 Y=0 Z=0 and extends to X={side} Y={side} Z={side}.")


# ── RUN ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not os.path.isfile(INPUT_FILE):
        print(f"ERROR: Input file not found: {INPUT_FILE}")
        print("Edit INPUT_FILE at the top of this script.")
        sys.exit(1)

    bytes_to_world(INPUT_FILE, OUTPUT_DIR, force_side=FORCE_SIDE)
