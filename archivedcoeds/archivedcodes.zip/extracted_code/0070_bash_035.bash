xxd originalfile > dump.hex      # file → hex dump
xxd -r dump.hex > restored file  # hex dump → file back