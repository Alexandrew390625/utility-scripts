   174	extract-text /mnt/user-data/uploads/deck.pptx | head -200
   175	