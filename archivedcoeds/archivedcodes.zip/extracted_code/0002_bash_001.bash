python word_checker.py /path/to/your/file.txt
# or just run it and it will prompt you for the path
python word_checker.py