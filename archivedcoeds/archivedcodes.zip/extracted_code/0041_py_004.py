"""
Grok PDF Challenge Checker
Checks all unique words from Chalmers' "Facing Up to the Problem of Consciousness"
against your dictionary file.
"""

import re
import os
import sys

DICTIONARY_PATH = "/storage/emulated/0/download/words_backup.txt"

# Full text extracted from the Chalmers PDF
PDF_TEXT = """
Facing Up to the Problem of Consciousness David J. Chalmers Philosophy Program
Research School of Social Sciences Australian National University

Consciousness poses the most baffling problems in the science of the mind. There is
nothing that we know more intimately than conscious experience, but there is nothing that is
harder to explain. All sorts of mental phenomena have yielded to scientific investigation in
recent years, but consciousness has stubbornly resisted. Many have tried to explain it, but the
explanations always seem to fall short of the target. Some have been led to suppose that the
problem is intractable, and that no good explanation can be given.

To make progress on the problem of consciousness, we have to confront it directly. In
this paper, I first isolate the truly hard part of the problem, separating it from more tractable
parts and giving an account of why it is so difficult to explain. I critique some recent work
that uses reductive methods to address consciousness, and argue that these methods inevitably
fail to come to grips with the hardest part of the problem. Once this failure is recognized, the
door to further progress is opened. In the second half of the paper, I argue that if we move to a
new kind of nonreductive explanation, a naturalistic account of consciousness can be given.
I put forward my own candidate for such an account: a nonreductive theory based on
principles of structural coherence and organizational invariance and a double-aspect view
of information.

The easy problems of consciousness include those of explaining the following phenomena:
the ability to discriminate, categorize, and react to environmental stimuli;
the integration of information by a cognitive system;
the reportability of mental states;
the ability of a system to access its own internal states;
the focus of attention;
the deliberate control of behavior;
the difference between wakefulness and sleep.

The really hard problem of consciousness is the problem of experience. When we think
and perceive, there is a whir of information-processing, but there is also a subjective aspect.
As Nagel has put it, there is something it is like to be a conscious organism. This
subjective aspect is experience. When we see, for example, we experience visual sensations:
the felt quality of redness, the experience of dark and light, the quality of depth in a visual
field. Other experiences go along with perception in different modalities: the sound of a
clarinet, the smell of mothballs. Then there are bodily sensations, from pains to orgasms;
mental images that are conjured up internally; the felt quality of emotion, and the experience
of a stream of conscious thought. What unites all of these states is that there is something it is
like to be in them. All of them are states of experience.

Why is it that when our cognitive systems engage in visual and auditory information-processing,
we have visual or auditory experience: the quality of deep blue, the sensation of middle C?
How can we explain why there is something it is like to entertain a mental image, or to
experience an emotion? It is widely agreed that experience arises from a physical basis, but we
have no good explanation of why and how it so arises. Why should physical processing give
rise to a rich inner life at all? It seems objectively unreasonable that it should, and yet it does.

Sometimes terms such as phenomenal consciousness and qualia are also used here, but I
find it more natural to speak of conscious experience or simply experience. Another
useful way to avoid confusion is to reserve the term consciousness for the phenomena of
experience, using the less loaded term awareness for the more straightforward phenomena
described earlier.

Why are the easy problems easy, and why is the hard problem hard? The easy problems
are easy precisely because they concern the explanation of cognitive abilities and functions.
To explain a cognitive function, we need only specify a mechanism that can perform the
function. The methods of cognitive science are well-suited for this sort of explanation.
By contrast, the hard problem is hard precisely because it is not a problem about the
performance of functions. The problem persists even when the performance of all the
relevant functions is explained.

To explain reportability, for instance, is just to explain how a system could perform the
function of producing reports on internal states. To explain internal access, we need to explain
how a system could be appropriately affected by its internal states and use information about
those states in directing later processes. To explain integration and control, we need to explain
how a system's central processes can bring information contents together and use them in the
facilitation of various behaviors.

The first is the neurobiological theory of consciousness outlined by Crick and Koch.
This theory centers on certain neural oscillations in the cerebral cortex; Crick and Koch
hypothesize that these oscillations are the basis of consciousness. This is partly because the
oscillations seem to be correlated with awareness in a number of different modalities within
the visual and olfactory systems, and also because they suggest a mechanism by which the
binding of information contents might be achieved. Binding is the process whereby separately
represented pieces of information about a single entity are brought together to be used by
later processing, as when information about the color and shape of a perceived object is
integrated from separate visual pathways.

The second example is an approach at the level of cognitive psychology. This is Bernard
Baars global workspace theory of consciousness. According to this theory, the contents of
consciousness are contained in a global workspace, a central processor used to mediate
communication between a host of specialized nonconscious processors. When these
specialized processors need to broadcast information to the rest of the system, they do so by
sending this information to the workspace, which acts as a kind of communal blackboard for
the rest of the system, accessible to all the other processors.

Nonalgorithmic processing is put forward by Penrose because of the role it might play
in the process of conscious mathematical insight. The arguments about mathematics are
controversial, but even if they succeed and an account of nonalgorithmic processing in the
human brain is given, it will still only be an account of the functions involved in mathematical
reasoning and the like.

Perhaps the most popular extra ingredient of all is quantum mechanics. The attractiveness
of quantum theories of consciousness may stem from a Law of Minimization of Mystery:
consciousness is mysterious and quantum mechanics is mysterious, so maybe the two
mysteries have a common source. Nevertheless, quantum theories of consciousness suffer
from the same difficulties as neural or computational theories. Quantum phenomena have some
remarkable functional properties, such as nondeterminism and nonlocality.

At the end of the day, the same criticism applies to any purely physical account of
consciousness. For any physical process we specify there will be an unanswered question:
Why should this process give rise to experience? Given any such process, it is conceptually
coherent that it could be instantiated in the absence of experience. It follows that no mere
account of the physical process will tell us why experience arises. The emergence of
experience goes beyond what can be derived from physical theory.

I suggest that a theory of consciousness should take experience as fundamental. We
know that a theory of consciousness requires the addition of something fundamental to our
ontology, as everything in physical theory is compatible with the absence of consciousness.
We might add some entirely new nonphysical feature, from which experience can be derived,
but it is hard to see what such a feature would be like. More likely, we will take experience
itself as a fundamental feature of the world, alongside mass, charge, and space-time.

This position qualifies as a variety of dualism, as it postulates basic properties over and
above the properties invoked by physics. But it is an innocent version of dualism, entirely
compatible with the scientific view of the world. Nothing in this approach contradicts
anything in physical theory; we simply need to add further bridging principles to explain how
experience arises from physical processes. There is nothing particularly spiritual or mystical
about this theory. If the position is to have a name, a good choice might be naturalistic dualism.

The principle of structural coherence. This is a principle of coherence between the
structure of consciousness and the structure of awareness. The contents of awareness are to be
understood as those information contents that are accessible to central systems, and brought
to bear in a widespread way in the control of behavior.

The principle of organizational invariance. This principle states that any two systems
with the same fine-grained functional organization will have qualitatively identical experiences.
If the causal patterns of neural organization were duplicated in silicon, for example, with a
silicon chip for every neuron and the same patterns of interaction, then the same experiences
would arise. According to this principle, what matters for the emergence of experience is not
the specific physical makeup of a system, but the abstract pattern of causal interaction
between its components.

The double-aspect theory of information. I understand information in more or less the
sense of Shannon. Where there is information, there are information states embedded in an
information space. An information space has a basic structure of difference relations between
its elements, characterizing the ways in which different elements in a space are similar or
different, possibly in complex ways. An information space is an abstract object, but following
Shannon we can see information as physically embodied when there is a space of distinct
physical states.

Wheeler has suggested that information is fundamental to the physics of the universe.
According to this it from bit doctrine, the laws of physics can be cast in terms of
information, postulating different states that give rise to different effects without actually
saying what those states are. If so, then information is a natural candidate to also play a role
in a fundamental theory of consciousness. We are led to a conception of the world on which
information is truly fundamental, and on which it has two basic aspects, corresponding to the
physical and the phenomenal features of the world.

The theory I have presented is speculative, but it is a candidate theory. I suspect that the
principles of structural coherence and organizational invariance will be planks in any
satisfactory theory of consciousness; the status of the double-aspect theory of information is
less certain. Most existing theories of consciousness either deny the phenomenon, explain
something else, or elevate the problem to an eternal mystery. I hope to have shown that it is
possible to make progress on the problem even while taking it seriously. The hard problem is
a hard problem, but there is no reason to believe that it will remain permanently unsolved.

Additional terms from the paper: psychophysical, nonreductive, reductio, explanandum,
isomorphism, phenomenal, qualia, epiphenomenal, neurophysiological, neurobiological,
introspective, nondeterminism, nonlocality, ontology, a posteriori, electromagnetism,
electromagnetic, vitalist, biochemical, cognitively, intersubjective, homogeneity,
underdetermined, extrinsic, panpsychism, thermostat, isomorph, nomologically,
intractable, ineffability, subjectivity, reportability, wakefulness, nonconscious,
nonalgorithmic, metaphysical, psychophysics, functionalism, eliminativism
"""


def load_dictionary(path):
    if not os.path.exists(path):
        print(f"❌ Dictionary not found: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        words = set(line.strip().lower() for line in f if line.strip())
    print(f"📖 Loaded {len(words):,} words from dictionary.\n")
    return words


def extract_words(text):
    raw = re.findall(r"[a-zA-Z]+", text)
    seen = set()
    unique = []
    for w in raw:
        low = w.lower()
        if low not in seen and len(low) > 2:  # skip tiny words like "a", "of"
            seen.add(low)
            unique.append(low)
    return unique


def check(words, dictionary):
    found = [w for w in words if w in dictionary]
    not_found = [w for w in words if w not in dictionary]
    return found, not_found


def print_results(found, not_found, total):
    print("=" * 60)
    print("      📄 GROK PDF CHALLENGE — CHALMERS PAPER")
    print("=" * 60)

    print(f"\n✅ FOUND in dictionary ({len(found)}/{total}):")
    for w in found:
        print(f"   ✔  {w}")

    print(f"\n❌ NOT FOUND / Unknown ({len(not_found)}/{total}):")
    if not_found:
        for w in not_found:
            print(f"   ✘  {w}")
    else:
        print("   (none — dictionary is a beast!)")

    print("\n" + "=" * 60)
    score = len(found) / total * 100
    print(f"  Score: {len(found)}/{total} unique words recognized ({score:.1f}%)")
    print("=" * 60)

    print("\n📋 COPY-PASTE REPLY FOR GROK:\n")
    print(f"My dictionary recognized {len(found)}/{total} unique words from the Chalmers paper ({score:.1f}%).")
    if not_found:
        missed = ", ".join(not_found)
        print(f"Words it missed: {missed}")
    else:
        print("It caught every single word. What's next?")


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else DICTIONARY_PATH
    print(f"🔍 Using dictionary: {path}\n")

    dictionary = load_dictionary(path)
    words = extract_words(PDF_TEXT)
    total = len(words)
    print(f"📝 Unique words extracted from PDF: {total}\n")

    found, not_found = check(words, dictionary)
    print_results(found, not_found, total)
