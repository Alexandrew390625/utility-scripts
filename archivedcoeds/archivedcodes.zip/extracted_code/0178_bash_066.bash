   339	file /mnt/user-data/uploads/mystery.bin
   340	xxd /mnt/user-data/uploads/mystery.bin | head -5
   341	