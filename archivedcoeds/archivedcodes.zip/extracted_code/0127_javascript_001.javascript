     6	const pptxgen = require("pptxgenjs");
     7	
     8	let pres = new pptxgen();
     9	pres.layout = 'LAYOUT_16x9';  // or 'LAYOUT_16x10', 'LAYOUT_4x3', 'LAYOUT_WIDE'
    10	pres.author = 'Your Name';
    11	pres.title = 'Presentation Title';
    12	
    13	let slide = pres.addSlide();
    14	slide.addText("Hello World!", { x: 0.5, y: 0.5, fontSize: 36, color: "363636" });
    15	
    16	pres.writeFile({ fileName: "Presentation.pptx" });
    17	