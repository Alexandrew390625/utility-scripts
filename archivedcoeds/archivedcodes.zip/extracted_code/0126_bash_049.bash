   213	python scripts/office/soffice.py --headless --convert-to pdf output.pptx
   214	rm -f slide-*.jpg
   215	pdftoppm -jpeg -r 150 output.pdf slide
   216	ls -1 "$PWD"/slide-*.jpg
   217	