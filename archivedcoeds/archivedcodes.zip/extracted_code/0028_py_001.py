"""
word_checker.py
---------------
Reads a target file, extracts every word from it, and checks each word
against a dictionary. Prints a summary of recognized vs. unrecognized words.

Dictionary path: /storage/emulated/0/download/words.txt
"""

import re
import sys
import os
from pathlib import Path

# ── Configuration ────────────────────────────────────────────────────────────

DICTIONARY_PATH = "/storage/emulated/0/download/words.txt"

# ── Helpers ──────────────────────────────────────────────────────────────────

def load_dictionary(path: str) -> set[str]:
    """Load words from the dictionary file into a lowercase set."""
    dict_path = Path(path)
    if not dict_path.exists():
        print(f"[ERROR] Dictionary not found: {path}")
        sys.exit(1)

    with open(dict_path, "r", encoding="utf-8", errors="ignore") as f:
        words = {line.strip().lower() for line in f if line.strip()}

    print(f"[✓] Dictionary loaded: {len(words):,} words from '{path}'")
    return words


def extract_words(filepath: str) -> list[str]:
    """Extract all alphabetic words from a text file (order preserved)."""
    path = Path(filepath)
    if not path.exists():
        print(f"[ERROR] Input file not found: {filepath}")
        sys.exit(1)

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()

    # Keep only sequences of letters (strips punctuation, numbers, etc.)
    words = re.findall(r"[a-zA-Z]+", text)
    return words


def check_words(words: list[str], dictionary: set[str]) -> dict:
    """
    Compare words against the dictionary.

    Returns a dict with:
      - all_words        : original list (lowercase)
      - unique_words     : deduplicated set
      - recognized       : words found in dictionary
      - unrecognized     : words NOT found in dictionary
      - unrecognized_ordered : unrecognized words in first-appearance order
    """
    lowered = [w.lower() for w in words]
    unique = set(lowered)

    recognized = unique & dictionary
    unrecognized = unique - dictionary

    # Preserve first-appearance order for unrecognized words
    seen: set[str] = set()
    unrecognized_ordered: list[str] = []
    for w in lowered:
        if w in unrecognized and w not in seen:
            unrecognized_ordered.append(w)
            seen.add(w)

    return {
        "all_words": lowered,
        "unique_words": unique,
        "recognized": recognized,
        "unrecognized": unrecognized,
        "unrecognized_ordered": unrecognized_ordered,
    }


def print_report(results: dict, input_file: str) -> None:
    """Print a formatted summary report."""
    total     = len(results["all_words"])
    unique    = len(results["unique_words"])
    known     = len(results["recognized"])
    unknown   = len(results["unrecognized"])
    pct_known = (known / unique * 100) if unique else 0

    sep = "─" * 60

    print()
    print(sep)
    print(f"  WORD CHECK REPORT — {os.path.basename(input_file)}")
    print(sep)
    print(f"  Total word tokens   : {total:,}")
    print(f"  Unique words        : {unique:,}")
    print(f"  Recognized          : {known:,}  ({pct_known:.1f}%)")
    print(f"  Unrecognized        : {unknown:,}  ({100 - pct_known:.1f}%)")
    print(sep)

    if results["unrecognized_ordered"]:
        print("\n  ❌ Words NOT found in dictionary (first-appearance order):\n")
        # Print in columns for readability
        cols = 4
        words = results["unrecognized_ordered"]
        col_width = max(len(w) for w in words) + 3
        for i, word in enumerate(words):
            end = "\n" if (i + 1) % cols == 0 else ""
            print(f"  {word:<{col_width}}", end=end)
        if len(words) % cols != 0:
            print()  # newline after last partial row
    else:
        print("\n  ✅ All words were found in the dictionary!")

    print()


# ── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    # --- Get input file from argument or prompt ---
    if len(sys.argv) >= 2:
        input_file = sys.argv[1]
    else:
        input_file = input("Enter the path to the file you want to check: ").strip()

    if not input_file:
        print("[ERROR] No file path provided.")
        sys.exit(1)

    print(f"\n[→] Checking file: {input_file}")

    # --- Load dictionary ---
    dictionary = load_dictionary(DICTIONARY_PATH)

    # --- Extract words ---
    words = extract_words(input_file)
    if not words:
        print("[!] No words found in the input file.")
        sys.exit(0)
    print(f"[✓] Extracted {len(words):,} word tokens ({len(set(w.lower() for w in words)):,} unique)")

    # --- Check against dictionary ---
    results = check_words(words, dictionary)

    # --- Print report ---
    print_report(results, input_file)

    # --- Optional: save unrecognized words to a file ---
    if results["unrecognized_ordered"]:
        save = input("Save unrecognized words to a file? (y/n): ").strip().lower()
        if save == "y":
            out_path = Path(input_file).stem + "_unrecognized.txt"
            with open(out_path, "w", encoding="utf-8") as f:
                f.write("\n".join(results["unrecognized_ordered"]))
            print(f"[✓] Saved to: {out_path}")


if __name__ == "__main__":
    main()
