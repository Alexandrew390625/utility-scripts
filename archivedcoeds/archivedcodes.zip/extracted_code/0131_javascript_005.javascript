   142	// From file path
   143	slide.addImage({ path: "images/photo.jpg", x: 1, y: 1, w: 5, h: 3 });
   144	
   145	// From URL
   146	slide.addImage({ path: "https://example.com/image.jpg", x: 1, y: 1, w: 5, h: 3 });
   147	
   148	// From base64 (faster, no file I/O)
   149	slide.addImage({ data: "image/png;base64,iVBORw0KGgo...", x: 1, y: 1, w: 5, h: 3 });
   150	