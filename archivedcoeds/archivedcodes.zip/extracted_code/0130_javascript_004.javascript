    88	slide.addShape(pres.shapes.RECTANGLE, {
    89	  x: 0.5, y: 0.8, w: 1.5, h: 3.0,
    90	  fill: { color: "FF0000" }, line: { color: "000000", width: 2 }
    91	});
    92	
    93	slide.addShape(pres.shapes.OVAL, { x: 4, y: 1, w: 2, h: 2, fill: { color: "0000FF" } });
    94	
    95	slide.addShape(pres.shapes.LINE, {
    96	  x: 1, y: 3, w: 5, h: 0, line: { color: "FF0000", width: 3, dashType: "dash" }
    97	});
    98	
    99	// With transparency
   100	slide.addShape(pres.shapes.RECTANGLE, {
   101	  x: 1, y: 1, w: 3, h: 2,
   102	  fill: { color: "0088CC", transparency: 50 }
   103	});
   104	
   105	// Rounded rectangle (rectRadius only works with ROUNDED_RECTANGLE, not RECTANGLE)
   106	// ⚠️ Don't pair with rectangular accent overlays — they won't cover rounded corners. Use RECTANGLE instead.
   107	slide.addShape(pres.shapes.ROUNDED_RECTANGLE, {
   108	  x: 1, y: 1, w: 3, h: 2,
   109	  fill: { color: "FFFFFF" }, rectRadius: 0.1
   110	});
   111	
   112	// With shadow
   113	slide.addShape(pres.shapes.RECTANGLE, {
   114	  x: 1, y: 1, w: 3, h: 2,
   115	  fill: { color: "FFFFFF" },
   116	  shadow: { type: "outer", color: "000000", blur: 6, offset: 2, angle: 135, opacity: 0.15 }
   117	});
   118	