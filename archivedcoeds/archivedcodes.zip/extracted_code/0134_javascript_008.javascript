   184	const origWidth = 1978, origHeight = 923, maxHeight = 3.0;
   185	const calcWidth = maxHeight * (origWidth / origHeight);
   186	const centerX = (10 - calcWidth) / 2;
   187	
   188	slide.addImage({ path: "image.png", x: centerX, y: 1.2, w: calcWidth, h: maxHeight });
   189	