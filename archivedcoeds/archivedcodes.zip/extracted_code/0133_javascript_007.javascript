   171	// Contain - fit inside, preserve ratio
   172	{ sizing: { type: 'contain', w: 4, h: 3 } }
   173	
   174	// Cover - fill area, preserve ratio (may crop)
   175	{ sizing: { type: 'cover', w: 4, h: 3 } }
   176	
   177	// Crop - cut specific portion
   178	{ sizing: { type: 'crop', x: 0.5, y: 0.5, w: 2, h: 2 } }
   179	