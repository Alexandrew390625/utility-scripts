   325	wc -c /mnt/user-data/uploads/app.log
   326	