xxd yourfile | head        # hex dump
file yourfile              # uses magic database automatically
hexdump -C yourfile | head