   409	   const shadow = { type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.15 };
   410	   slide.addShape(pres.shapes.RECTANGLE, { shadow, ... });  // ❌ second call gets already-converted values
   411	   slide.addShape(pres.shapes.RECTANGLE, { shadow, ... });
   412	
   413	   const makeShadow = () => ({ type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.15 });
   414	   slide.addShape(pres.shapes.RECTANGLE, { shadow: makeShadow(), ... });  // ✅ fresh object each time
   415	   slide.addShape(pres.shapes.RECTANGLE, { shadow: makeShadow(), ... });
   416	   