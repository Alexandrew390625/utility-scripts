"""
number_namer.py
===============
Name any number using standard English -illion names (short scale),
SI / binary prefixes, and a plain English description.

Supports arbitrarily large integers (no OverflowError).

Usage
-----
    python number_namer.py                  # interactive mode
    python number_namer.py 1e27             # single number from CLI
    python number_namer.py 1500000 1e9 2e60 # multiple numbers from CLI
"""

import sys
import math
from decimal import Decimal, getcontext, InvalidOperation

# Enough precision for very large numbers typed as integers
getcontext().prec = 50

# ---------------------------------------------------------------------------
# SI metric prefixes  (exponent of 10, symbol, full name)
# ---------------------------------------------------------------------------
SI_PREFIXES = [
    (30,  "Q",  "Quetta"),
    (27,  "R",  "Ronna"),
    (24,  "Y",  "Yotta"),
    (21,  "Z",  "Zetta"),
    (18,  "E",  "Exa"),
    (15,  "P",  "Peta"),
    (12,  "T",  "Tera"),
    (9,   "G",  "Giga"),
    (6,   "M",  "Mega"),
    (3,   "k",  "kilo"),
    (2,   "h",  "hecto"),
    (1,   "da", "deca"),
    (-1,  "d",  "deci"),
    (-2,  "c",  "centi"),
    (-3,  "m",  "milli"),
    (-6,  "µ",  "micro"),
    (-9,  "n",  "nano"),
    (-12, "p",  "pico"),
    (-15, "f",  "femto"),
    (-18, "a",  "atto"),
    (-21, "z",  "zepto"),
    (-24, "y",  "yocto"),
    (-27, "r",  "ronto"),
    (-30, "q",  "quecto"),
]

# ---------------------------------------------------------------------------
# Binary (IEC) prefixes  (bit-shift, symbol, name)
# ---------------------------------------------------------------------------
BINARY_PREFIXES = [
    (80, "Yi", "Yobi"),
    (70, "Zi", "Zebi"),
    (60, "Ei", "Exbi"),
    (50, "Pi", "Pebi"),
    (40, "Ti", "Tebi"),
    (30, "Gi", "Gibi"),
    (20, "Mi", "Mebi"),
    (10, "Ki", "Kibi"),
]

# ---------------------------------------------------------------------------
# Standard -illion names (short scale)   10^(3N+3)
# ---------------------------------------------------------------------------
_ONES = [
    "", "un", "duo", "tre", "quattuor", "quin", "se", "septen", "octo", "novem"
]
_TENS = [
    "", "dec", "vigint", "trigint", "quadragint", "quinquagint",
    "sexagint", "septuagint", "octogint", "nonagint",
]
_HUNDREDS = [
    "", "cent", "ducent", "trecent", "quadringent", "quingent",
    "sescent", "septingent", "octingent", "nongent",
]

_NAMED = {
    0:    "thousand",
    1:    "million",
    2:    "billion",
    3:    "trillion",
    4:    "quadrillion",
    5:    "quintillion",
    6:    "sextillion",
    7:    "septillion",
    8:    "octillion",
    9:    "nonillion",
    10:   "decillion",
    11:   "undecillion",
    12:   "duodecillion",
    13:   "tredecillion",
    14:   "quattuordecillion",
    15:   "quindecillion",
    16:   "sexdecillion",
    17:   "septendecillion",
    18:   "octodecillion",
    19:   "novemdecillion",
    20:   "vigintillion",
    100:  "centillion",
    1000: "millillion",
}

_SMALL = {
    10:        "ten",
    100:       "hundred",
    1_000:     "thousand",
    10_000:    "myriad",
    1_000_000: "million",
}


def _illion_name(n: int) -> str:
    """Name for 10^(3n+3)."""
    if n in _NAMED:
        return _NAMED[n]
    if n > 1_000_000:
        return f"(10^{3*n+3})"
    h, rem = divmod(n, 100)
    t, o = divmod(rem, 10)
    h = min(h, len(_HUNDREDS) - 1)
    t = min(t, len(_TENS) - 1)
    o = min(o, len(_ONES) - 1)
    prefix = _HUNDREDS[h] + _TENS[t] + _ONES[o]
    if prefix.endswith("i"):
        prefix = prefix[:-1]
    return prefix + "illion"


# ---------------------------------------------------------------------------
# Parse input → (Decimal, is_negative, num_digits_if_integer)
# ---------------------------------------------------------------------------

def _parse(raw: str):
    """
    Return (Decimal_abs_value, is_negative) or raise ValueError.
    Handles plain integers of any length, floats, and scientific notation.
    """
    raw = raw.strip().replace(",", "").replace("_", "")
    negative = raw.startswith("-")
    if negative:
        raw = raw[1:]
    d = Decimal(raw)          # raises InvalidOperation if unparseable
    if d < 0:                 # handle "- -3" edge case
        negative = not negative
        d = -d
    return d, negative


# ---------------------------------------------------------------------------
# Core naming function
# ---------------------------------------------------------------------------

def name_number(value) -> dict:
    """
    Given any number (int, float, Decimal, or string of any size),
    return a dict describing it with -illion name, SI prefix, and binary prefix.
    """
    original = str(value)
    try:
        abs_d, negative = _parse(original)
    except (InvalidOperation, ValueError):
        return {"error": f"Cannot parse '{original}' as a number."}

    result = {"input": original, "negative": negative}

    # ---- Zero ----
    if abs_d == 0:
        result.update(scientific="0", illion_name="zero",
                      si_prefix="0", binary_prefix=None)
        return result

    # ---- Exponent (base-10) ----
    # Use math.log10 on float approximation just to get the exponent integer;
    # all heavy arithmetic stays in Python int / Decimal.
    try:
        float_approx = float(abs_d)
        if math.isinf(float_approx):
            raise OverflowError
        exp = math.floor(math.log10(float_approx))
    except OverflowError:
        # Number is too big for float — count decimal digits of the integer part
        s = str(abs_d).split(".")[0].lstrip("0") or "0"
        exp = len(s) - 1

    # ---- Scientific notation ----
    pow10 = Decimal(10) ** exp
    mantissa = abs_d / pow10
    result["scientific"] = f"{float(mantissa):.6g} × 10^{exp}"

    # ---- -illion name ----
    if exp >= 3:
        N = (exp - 3) // 3
        illion = _illion_name(N)
        scale = Decimal(10) ** (3 * N + 3)
        coeff = float(abs_d / scale)
        result["illion_name"] = f"{coeff:.6g} {illion}"
    elif exp >= 0:
        best_key, best_val = 1, ""
        for k, v in _SMALL.items():
            if abs_d >= k:
                best_key, best_val = k, v
        result["illion_name"] = f"{float(abs_d / best_key):.6g} {best_val}".strip()
    else:
        result["illion_name"] = None

    # ---- SI prefix ----
    si_str = None
    for si_exp, symbol, name in SI_PREFIXES:
        threshold = Decimal(10) ** si_exp
        if abs_d >= threshold * Decimal("0.9999"):
            si_val = float(abs_d / threshold)
            si_str = f"{si_val:.6g} {symbol}  ({name}-)"
            break
    result["si_prefix"] = si_str or f"{float(abs_d):.6g} (no SI prefix)"

    # ---- Binary prefix (integer-like values only) ----
    bin_str = None
    # Check if integer (no fractional part)
    if abs_d == abs_d.to_integral_value() and abs_d >= 1024:
        abs_int = int(abs_d)
        for bits, symbol, name in BINARY_PREFIXES:
            threshold = 1 << bits
            if abs_int >= threshold:
                bin_val = abs_int / threshold   # plain Python float division
                bin_str = f"{bin_val:.6g} {symbol}  ({name}-)"
                break
    result["binary_prefix"] = bin_str

    return result


# ---------------------------------------------------------------------------
# Pretty printer
# ---------------------------------------------------------------------------

def print_result(r: dict) -> None:
    if "error" in r:
        print(f"  ✗  {r['error']}")
        return
    sign = "−" if r["negative"] else ""
    print(f"  Input        : {r['input']}")
    print(f"  Scientific   : {sign}{r['scientific']}")
    if r.get("illion_name"):
        print(f"  -illion name : {sign}{r['illion_name']}")
    print(f"  SI prefix    : {sign}{r['si_prefix']}")
    if r.get("binary_prefix"):
        print(f"  Binary prefix: {sign}{r['binary_prefix']}")


# ---------------------------------------------------------------------------
# Demo values
# ---------------------------------------------------------------------------

DEMO_VALUES = [
    "1", "10", "100", "1000", "1000000", "1e9", "1e12", "1e15",
    "1e18", "1e21", "1e24", "1e27", "1e30", "1e33", "1e63", "1e303",
    "1024", str(2**20), str(2**30), str(2**40), str(2**60),
    "1500", "2500000", "9.99e-7", "-5e18",
    # The giant integer from the bug report (first 30 digits shown here as a sample)
    "135293998974450669831097447094008241625229803915065243997108453987412246648154249379985562142243444811233696124088346544538005729520610159132349504800664129850686366510504673653556594817440697196820990532678455074539743470901039799951540310054578318165695258394453716009938076825925956706110946131836496405052970629865060314448410450926853664778064743913582433176682489684329978596741053991265777275550231439364289153408800458999804874414751593730422609508749879359062955389798814326689448714697866121701415912539169276125898332506337025206505537572785682452483328983977926616957471251009381561501883485995242901197637704972834773323458218964136085074860820564925140103945902839915625199678745975765121847726077624171696203950175882442696635730532164956907169030135670802173589899667459535057805410603700033371185504829332383433991152571325063148251599563848952131020423262066937760951945171538882879118743698545434594801427929622460351469550349591641862161895697819668448277796324125628777673894249937335434419681666816809614129505108681176155300817113498660462210895442192494321936192592010313872338491325904309169345454635583887744120176991014702013877043318614084929811782335302045478417380098263831501548609785140900962363308981988798263321094844738107113144116333568717422035791419792206557689557469134595098750998089748896612051946243880865899361678278662794711054665713976127938794717527954576692993069356724141180029714470822435711712056652760403322294814164047003260000708763035762759705336536530811632489041985287173120419771015162483144309121073074336357881674278662019967556301422456258564829877599459549594053967633555304647362542300484720974228061599879550052963772704847473269129091549195053342420361746765110085888818755696685698554347168649063390864316322182768471332757002528174899200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
]

BANNER = r"""
╔══════════════════════════════════════════════════════╗
║         N U M B E R   N A M E R                      ║
║  SI prefixes · -illion names · Binary (IEC) prefixes ║
╚══════════════════════════════════════════════════════╝
"""


def run_demo() -> None:
    print(BANNER)
    print("=" * 58)
    print("  DEMO — standard reference values")
    print("=" * 58)
    for v in DEMO_VALUES:
        print()
        print_result(name_number(v))
    print()


def interactive_mode() -> None:
    print(BANNER)
    print("Type a number and press Enter.  Type 'quit' to exit.\n")
    while True:
        try:
            raw = input("Number > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break
        if not raw:
            continue
        if raw.lower() in ("quit", "exit", "q"):
            print("Goodbye!")
            break
        print()
        print_result(name_number(raw))
        print()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    args = sys.argv[1:]
    if args:
        print(BANNER)
        for arg in args:
            print()
            print_result(name_number(arg))
        print()
    else:
        run_demo()
        interactive_mode()
