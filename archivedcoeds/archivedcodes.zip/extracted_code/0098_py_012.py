"""
read_mca.py — Scan for .mca files and list every block inside them.

Requirements:
    pip install anvil-parser

Usage:
    python read_mca.py                  # searches current directory
    python read_mca.py /path/to/region  # searches a specific directory
"""

import sys
import os
import glob

try:
    import anvil
except ImportError:
    sys.exit(
        "Missing dependency. Install it with:\n"
        "    pip install anvil-parser\n"
    )


def find_mca_files(search_dir: str) -> list[str]:
    """Recursively find all .mca files under search_dir."""
    pattern = os.path.join(search_dir, "**", "*.mca")
    return sorted(glob.glob(pattern, recursive=True))


def iter_blocks(region: anvil.Region):
    """
    Yield (chunk_x, chunk_z, x, y, z, block_name) for every non-air block
    in every chunk of the region.

    Minecraft regions contain up to 32×32 chunks.
    Each chunk spans 16×16 blocks in XZ and up to 384 blocks in Y
    (Y = -64 to 319 for 1.18+; older worlds use 0–255).
    """
    for chunk_x in range(32):
        for chunk_z in range(32):
            try:
                chunk = region.get_chunk(chunk_x, chunk_z)
            except Exception:
                # Chunk not generated yet — skip silently
                continue

            # Detect Y range from the chunk's section data
            try:
                sections = chunk.data["Level"]["Sections"].value  # 1.17-
            except (KeyError, AttributeError):
                try:
                    sections = chunk.data["sections"].value        # 1.18+
                except (KeyError, AttributeError):
                    sections = []

            if not sections:
                continue

            # Determine Y bounds from section Y-indices
            y_indices = []
            for section in sections:
                try:
                    y_indices.append(section["Y"].value)
                except (KeyError, AttributeError):
                    pass

            if not y_indices:
                continue

            y_min = min(y_indices) * 16
            y_max = (max(y_indices) + 1) * 16

            for y in range(y_min, y_max):
                for z in range(16):
                    for x in range(16):
                        try:
                            block = chunk.get_block(x, y, z)
                            if block is None:
                                continue
                            name = block.id          # e.g. "minecraft:stone"
                            if name in (None, "minecraft:air",
                                        "minecraft:cave_air",
                                        "minecraft:void_air"):
                                continue
                            yield chunk_x, chunk_z, x, y, z, name
                        except Exception:
                            # Malformed block data — skip
                            continue


def process_file(mca_path: str) -> None:
    print(f"\n{'='*60}")
    print(f"File: {mca_path}")
    print(f"{'='*60}")

    try:
        region = anvil.Region.from_file(mca_path)
    except Exception as e:
        print(f"  ERROR opening file: {e}")
        return

    block_count = 0
    type_counts: dict[str, int] = {}

    for chunk_x, chunk_z, x, y, z, name in iter_blocks(region):
        block_count += 1
        type_counts[name] = type_counts.get(name, 0) + 1

        # Print individual block entries (can be millions — cap at 10 000)
        if block_count <= 10_000:
            print(f"  chunk({chunk_x:2d},{chunk_z:2d})  "
                  f"pos({x:2d},{y:4d},{z:2d})  {name}")

    if block_count > 10_000:
        print(f"\n  ... output truncated after 10 000 blocks ...")

    print(f"\n  --- Summary ---")
    print(f"  Total non-air blocks : {block_count:,}")
    print(f"  Unique block types   : {len(type_counts):,}")
    if type_counts:
        print("  Top 20 block types:")
        for name, count in sorted(type_counts.items(),
                                  key=lambda kv: kv[1], reverse=True)[:20]:
            print(f"    {count:>10,}  {name}")


def main() -> None:
    search_dir = sys.argv[1] if len(sys.argv) > 1 else "."
    search_dir = os.path.abspath(search_dir)

    print(f"Searching for .mca files in: {search_dir}")
    files = find_mca_files(search_dir)

    if not files:
        print("No .mca files found.")
        return

    print(f"Found {len(files)} .mca file(s).")
    for path in files:
        process_file(path)

    print("\nDone.")


if __name__ == "__main__":
    main()
