#!/usr/bin/env python3
"""
Chess PGN Analyzer — Fast Edition
===================================
Uses the `chess` library for fast PGN parsing and Python multiprocessing
to spread work across all available CPU cores.

Usage:
    python pgn_analyzer_fast.py                    # scans current folder
    python pgn_analyzer_fast.py /path/to/pgns      # scans given folder
    python pgn_analyzer_fast.py a.pgn b.pgn c.pgn  # specific files

Each file is assigned to its own worker process. Results are merged at the end.
"""

import os
import re
import sys
import io
import time
import multiprocessing as mp
from collections import Counter
from pathlib import Path

try:
    import chess.pgn
except ImportError:
    print("❌  The 'chess' library is not installed.")
    print("    Run:  pip install chess")
    sys.exit(1)

# ---------------------------------------------------------------------------
# ELO ranges
# ---------------------------------------------------------------------------
ELO_RANGES = [
    (0,     100,  "0-100"),
    (100,   200,  "100-200"),
    (200,   300,  "200-300"),
    (300,   400,  "300-400"),
    (400,   500,  "400-500"),
    (500,   600,  "500-600"),
    (600,   700,  "600-700"),
    (700,   800,  "700-800"),
    (800,   900,  "800-900"),
    (900,   1000, "900-1000"),
    (1000,  1100, "1000-1100"),
    (1100,  1200, "1100-1200"),
    (1200,  1300, "1200-1300"),
    (1300,  1400, "1300-1400"),
    (1400,  1500, "1400-1500"),
    (1500,  1600, "1500-1600"),
    (1600,  1700, "1600-1700"),
    (1700,  1800, "1700-1800"),
    (1800,  1900, "1800-1900"),
    (1900,  2000, "1900-2000"),
    (2000,  99999,"2000+"),
]
RANGE_LABELS = [label for *_, label in ELO_RANGES]

def elo_bucket(elo: int) -> str:
    for lo, hi, label in ELO_RANGES:
        if lo <= elo < hi:
            return label
    return "2000+"

# ---------------------------------------------------------------------------
# Empty stats skeleton (plain dicts — picklable for multiprocessing)
# ---------------------------------------------------------------------------
def empty_stats() -> dict:
    return {
        "total":            0,
        "events":           {},   # Counter-like dict
        "players":          {},
        "websites":         {},
        "terminations":     {},
        "time_controls":    {},
        "day_night":        {},
        "highest_elo":      -1,
        "highest_elo_player": "Unknown",
        # per ELO range dicts-of-dicts
        "range_results":    {lbl: {"white": 0, "black": 0, "draw": 0, "total": 0} for lbl in RANGE_LABELS},
        "range_openings":   {lbl: {} for lbl in RANGE_LABELS},
        "range_variations": {lbl: {} for lbl in RANGE_LABELS},
    }

def inc(d: dict, key: str, n: int = 1):
    d[key] = d.get(key, 0) + n

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def safe_int(value, default: int = -1) -> int:
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def detect_website(site: str) -> str:
    s = (site or "").lower()
    if "lichess" in s:
        return "lichess.org"
    if "chess.com" in s:
        return "chess.com"
    if s.strip():
        m = re.search(r'([\w-]+\.\w+)', s)
        if m:
            return m.group(1)
    return "Unknown"

def detect_termination(termination: str, result: str) -> str:
    t = (termination or "").lower()
    if "checkmate" in t or "mate" in t:
        return "Checkmate"
    if "time" in t or "forfeit" in t:
        return "Time forfeit"
    if "resign" in t:
        return "Resignation"
    if "draw" in t or "stalemate" in t or "repetition" in t or "insufficient" in t or "agreement" in t:
        return "Draw"
    if "abandon" in t:
        return "Abandoned"
    if result == "1/2-1/2":
        return "Draw"
    return "Other / Unknown"

def is_night(hour: int) -> bool:
    return hour >= 22 or hour < 8

# ---------------------------------------------------------------------------
# Worker: process one PGN file, return stats dict
# ---------------------------------------------------------------------------
def process_file(args):
    filepath, worker_id, total_workers = args
    stats = empty_stats()
    filesize = os.path.getsize(filepath)

    print(f"  [Worker {worker_id}/{total_workers}] Starting → {Path(filepath).name}  "
          f"({filesize / 1_000_000:.1f} MB)", flush=True)

    progress_every = 50_000   # print a progress line every N games
    last_time = time.time()

    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        while True:
            try:
                game = chess.pgn.read_game(f)
            except Exception:
                continue
            if game is None:
                break

            stats["total"] += 1
            h = game.headers

            # --- Event ---
            event = h.get("Event", "Unknown").strip() or "Unknown"
            inc(stats["events"], event)

            # --- Players ---
            white = h.get("White", "").strip()
            black = h.get("Black", "").strip()
            if white:
                inc(stats["players"], white)
            if black:
                inc(stats["players"], black)

            # --- ELOs ---
            white_elo = safe_int(h.get("WhiteElo", ""))
            black_elo = safe_int(h.get("BlackElo", ""))

            for elo, name in [(white_elo, white), (black_elo, black)]:
                if elo > stats["highest_elo"]:
                    stats["highest_elo"] = elo
                    stats["highest_elo_player"] = name or "Unknown"

            valid_elos = [e for e in [white_elo, black_elo] if e > 0]
            avg_elo = int(sum(valid_elos) / len(valid_elos)) if valid_elos else -1
            bucket = elo_bucket(avg_elo) if avg_elo >= 0 else None

            # --- Result ---
            result = h.get("Result", "").strip()
            if bucket:
                r = stats["range_results"][bucket]
                r["total"] += 1
                if result == "1-0":
                    r["white"] += 1
                elif result == "0-1":
                    r["black"] += 1
                elif result == "1/2-1/2":
                    r["draw"] += 1

            # --- Opening / Variation ---
            opening   = h.get("Opening",   "").strip()
            variation = h.get("Variation",  "").strip()

            if bucket and opening:
                inc(stats["range_openings"][bucket],   opening)
                full_var = f"{opening}: {variation}" if variation else opening
                inc(stats["range_variations"][bucket], full_var)

            # --- Time control ---
            tc = h.get("TimeControl", "").strip() or "Unknown"
            inc(stats["time_controls"], tc)

            # --- Termination ---
            term_raw = h.get("Termination", "").strip()
            inc(stats["terminations"], detect_termination(term_raw, result))

            # --- Website ---
            inc(stats["websites"], detect_website(h.get("Site", "")))

            # --- Day / Night ---
            utctime = h.get("UTCTime", "").strip()
            if utctime:
                m = re.match(r'(\d{1,2}):', utctime)
                if m:
                    hour = int(m.group(1))
                    inc(stats["day_night"], "Night" if is_night(hour) else "Day")

            # --- Progress ---
            if stats["total"] % progress_every == 0:
                elapsed = time.time() - last_time
                rate = progress_every / elapsed if elapsed else 0
                print(f"  [Worker {worker_id}] {stats['total']:,} games  "
                      f"({rate:,.0f} games/s)", flush=True)
                last_time = time.time()

    print(f"  [Worker {worker_id}] ✅ Done — {stats['total']:,} games parsed", flush=True)
    return stats

# ---------------------------------------------------------------------------
# Merge stats from multiple workers
# ---------------------------------------------------------------------------
def merge_stats(all_stats: list) -> dict:
    merged = empty_stats()

    for s in all_stats:
        merged["total"] += s["total"]

        for key in ("events", "players", "websites", "terminations", "time_controls", "day_night"):
            for k, v in s[key].items():
                merged[key][k] = merged[key].get(k, 0) + v

        if s["highest_elo"] > merged["highest_elo"]:
            merged["highest_elo"] = s["highest_elo"]
            merged["highest_elo_player"] = s["highest_elo_player"]

        for lbl in RANGE_LABELS:
            sr = s["range_results"][lbl]
            mr = merged["range_results"][lbl]
            for k in ("white", "black", "draw", "total"):
                mr[k] += sr[k]

            for op, cnt in s["range_openings"][lbl].items():
                merged["range_openings"][lbl][op] = \
                    merged["range_openings"][lbl].get(op, 0) + cnt

            for var, cnt in s["range_variations"][lbl].items():
                merged["range_variations"][lbl][var] = \
                    merged["range_variations"][lbl].get(var, 0) + cnt

    return merged

# ---------------------------------------------------------------------------
# Report printer
# ---------------------------------------------------------------------------
def print_report(stats: dict, num_files: int, elapsed: float):
    total = stats["total"]
    sep  = "=" * 72
    sep2 = "-" * 72

    def pct(n, t):
        return f"{n / t * 100:.1f}%" if t else "N/A"

    def top_n(d: dict, n: int = 10):
        return sorted(d.items(), key=lambda x: x[1], reverse=True)[:n]

    print()
    print(sep)
    print("  ♟  CHESS PGN ANALYSIS REPORT")
    print(sep)
    print(f"  Total games analysed : {total:,}")
    print(f"  PGN files scanned    : {num_files}")
    print(f"  Time taken           : {elapsed:.1f}s")
    if elapsed > 0:
        print(f"  Parse speed          : {total / elapsed:,.0f} games/s")
    print()

    # 1. Event types
    print(sep2)
    print("  1. MOST PLAYED EVENT TYPES")
    print(sep2)
    for event, count in top_n(stats["events"]):
        print(f"  {count:>8,}  ({pct(count, total):>6})  {event}")
    print()

    # 2. Most mentioned player
    print(sep2)
    print("  2. MOST MENTIONED PLAYER")
    print(sep2)
    players_sorted = sorted(stats["players"].items(), key=lambda x: x[1], reverse=True)
    if players_sorted:
        top_p, top_c = players_sorted[0]
        print(f"  ▶  {top_p}  —  {top_c:,} appearance(s)")
        print()
        print("  Top 10 players:")
        for p, c in players_sorted[:10]:
            print(f"    {c:>8,}  {p}")
    print()

    # 3. Win rates by ELO range
    print(sep2)
    print("  3. WIN RATES BY ELO RANGE  (avg ELO of both players)")
    print(sep2)
    print(f"  {'Range':<12}  {'Games':>8}  {'White':>8}  {'Black':>8}  {'Draw':>8}")
    print(f"  {'-'*12}  {'-'*8}  {'-'*8}  {'-'*8}  {'-'*8}")
    for lbl in RANGE_LABELS:
        r = stats["range_results"][lbl]
        t = r["total"]
        if t == 0:
            continue
        print(f"  {lbl:<12}  {t:>8,}  {pct(r['white'],t):>8}  "
              f"{pct(r['black'],t):>8}  {pct(r['draw'],t):>8}")
    print()

    # 4. Highest ELO
    print(sep2)
    print("  4. HIGHEST ELO EVER RECORDED")
    print(sep2)
    if stats["highest_elo"] > 0:
        print(f"  {stats['highest_elo_player']}  —  ELO {stats['highest_elo']}")
    else:
        print("  No ELO data found.")
    print()

    # 5. Most played opening per ELO range
    print(sep2)
    print("  5. MOST PLAYED OPENING PER ELO RANGE")
    print(sep2)
    for lbl in RANGE_LABELS:
        ops = stats["range_openings"][lbl]
        if not ops:
            continue
        sorted_ops = sorted(ops.items(), key=lambda x: x[1], reverse=True)
        top_op, top_cnt = sorted_ops[0]
        total_range = stats["range_results"][lbl]["total"]
        print(f"  {lbl:<12}  ▶  {top_op}  ({top_cnt:,} games, {pct(top_cnt, total_range)})")
        if len(sorted_ops) > 1:
            all_list = "  All: " + " | ".join(
                f"{op} ×{n}" for op, n in sorted_ops
            )
            # word-wrap at 80 chars
            words = all_list.split(" | ")
            line = ""
            for w in words:
                if len(line) + len(w) > 78:
                    print(f"        {line.rstrip(' |')}")
                    line = w + " | "
                else:
                    line += w + " | "
            if line.strip(" |"):
                print(f"        {line.rstrip(' |')}")
        print()

    # 6. Most played variation per ELO range
    print(sep2)
    print("  6. MOST PLAYED VARIATION PER ELO RANGE")
    print(sep2)
    for lbl in RANGE_LABELS:
        vars_ = stats["range_variations"][lbl]
        if not vars_:
            continue
        sorted_vars = sorted(vars_.items(), key=lambda x: x[1], reverse=True)
        top_var, top_cnt = sorted_vars[0]
        total_range = stats["range_results"][lbl]["total"]
        print(f"  {lbl:<12}  ▶  {top_var}  ({top_cnt:,} games, {pct(top_cnt, total_range)})")
        if len(sorted_vars) > 1:
            all_list = " | ".join(f"{v} ×{n}" for v, n in sorted_vars)
            words = all_list.split(" | ")
            line = "  All: "
            for w in words:
                if len(line) + len(w) > 78:
                    print(f"        {line.rstrip(' |')}")
                    line = w + " | "
                else:
                    line += w + " | "
            if line.strip(" |"):
                print(f"        {line.rstrip(' |')}")
        print()

    # 7. Time controls
    print(sep2)
    print("  7. TIME CONTROL DISTRIBUTION")
    print(sep2)
    for tc, count in top_n(stats["time_controls"], 20):
        print(f"  {count:>8,}  ({pct(count, total):>6})  {tc}")
    print()

    # 8. Terminations
    print(sep2)
    print("  8. HOW GAMES ENDED")
    print(sep2)
    for term, count in top_n(stats["terminations"], 20):
        print(f"  {count:>8,}  ({pct(count, total):>6})  {term}")
    print()

    # 9. Websites
    print(sep2)
    print("  9. WEBSITE DISTRIBUTION")
    print(sep2)
    for site, count in top_n(stats["websites"]):
        print(f"  {count:>8,}  ({pct(count, total):>6})  {site}")
    print()

    # 10. Day / Night
    print(sep2)
    print("  10. TIME OF DAY  (UTC — Night: 22:00-08:00 / Day: 08:00-22:00)")
    print(sep2)
    dn = stats["day_night"]
    dn_total = sum(dn.values())
    if dn_total:
        for label in ["Night", "Day"]:
            count = dn.get(label, 0)
            print(f"  {label:<6}  {count:>8,}  ({pct(count, dn_total):>6})")
    else:
        print("  No UTCTime tags found in these PGN files.")
    print()

    print(sep)
    print("  ✅  Analysis complete.")
    print(sep)

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main():
    args = sys.argv[1:]

    # Determine list of PGN files
    if args:
        # Check if args are files or a directory
        pgn_files = []
        for a in args:
            p = Path(a)
            if p.is_file() and p.suffix.lower() == ".pgn":
                pgn_files.append(str(p))
            elif p.is_dir():
                pgn_files.extend(str(f) for f in p.rglob("*.pgn"))
            else:
                print(f"⚠️  Skipping (not a .pgn file or directory): {a}")
    else:
        pgn_files = [str(f) for f in Path(".").rglob("*.pgn")]

    if not pgn_files:
        print("❌  No .pgn files found.")
        sys.exit(1)

    num_files = len(pgn_files)
    total_size_mb = sum(os.path.getsize(f) for f in pgn_files) / 1_000_000

    # How many workers? Min(num_files × 1, cpu_count, 8)
    # Each file gets its own process; extras do nothing so cap at file count
    cpu_count = mp.cpu_count()
    num_workers = min(num_files, cpu_count, 8)

    print(f"\n📂  Found {num_files} PGN file(s)  ({total_size_mb:,.1f} MB total)")
    print(f"⚙️   Using {num_workers} worker process(es)  ({cpu_count} CPUs available)")
    print()

    # Build work items — distribute files across workers
    # If more files than workers, multiple files can go to same worker,
    # but here we just assign one process per file (up to 8).
    # For >8 files we batch them.
    work_items = [
        (filepath, i + 1, num_files)
        for i, filepath in enumerate(pgn_files)
    ]

    t_start = time.time()

    if num_workers == 1:
        # Single-process path (avoids mp overhead)
        all_stats = [process_file(work_items[0])]
    else:
        with mp.Pool(processes=num_workers) as pool:
            all_stats = pool.map(process_file, work_items)

    t_end = time.time()
    elapsed = t_end - t_start

    print("\n🔀  Merging results from all workers...")
    merged = merge_stats(all_stats)

    print_report(merged, num_files, elapsed)

    # Optionally save report to file
    report_path = "pgn_report.txt"
    try:
        import io as _io
        old_stdout = sys.stdout
        sys.stdout = buf = _io.StringIO()
        print_report(merged, num_files, elapsed)
        sys.stdout = old_stdout
        with open(report_path, "w", encoding="utf-8") as rf:
            rf.write(buf.getvalue())
        print(f"\n📄  Report also saved to: {report_path}")
    except Exception:
        pass  # stdout redirect failed, no big deal


if __name__ == "__main__":
    # Required on Windows / some Android environments
    mp.freeze_support()
    main()
