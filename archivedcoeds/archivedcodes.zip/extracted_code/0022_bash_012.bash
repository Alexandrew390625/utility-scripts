   295	zcat /mnt/user-data/uploads/data.json.gz | head -50
   296	