    22	# Text extraction, one `## Slide N` section per slide
    23	extract-text presentation.pptx
    24	
    25	# Visual overview
    26	python scripts/thumbnail.py presentation.pptx
    27	
    28	# Raw XML
    29	python scripts/office/unpack.py presentation.pptx unpacked/
    30	