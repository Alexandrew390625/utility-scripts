# Analyse the current folder (and subfolders)
python pgn_analyzer.py

# Or point it at a specific folder
python pgn_analyzer.py /path/to/your/pgn/files