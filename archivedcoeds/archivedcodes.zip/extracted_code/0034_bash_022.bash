# 1. Install Python first
pkg install python

# 2. Navigate to your download folder
cd /storage/emulated/0/download

# 3. Run the script
python check_words.py