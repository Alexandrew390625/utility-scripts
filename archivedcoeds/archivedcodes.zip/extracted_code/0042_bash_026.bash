# Install pypdf first (only needed once)
pip install pypdf

# Run it
cd /storage/emulated/0/download
python grok_pdf_challenge.py