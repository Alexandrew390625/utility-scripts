# Interactive mode (type numbers one by one)
python number_namer.py

# Single number
python number_namer.py 1e27

# Multiple numbers at once
python number_namer.py 1000 1e9 2097152 9.99e-7