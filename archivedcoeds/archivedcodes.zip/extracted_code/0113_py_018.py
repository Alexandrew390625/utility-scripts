#!/usr/bin/env python3
"""
Chess PGN Analyzer
==================
Scans the current directory (and subdirectories) for .pgn files and produces
a detailed statistical report covering:
  - Most common event types
  - Most mentioned player
  - Win rates by ELO range (white vs black vs draw)
  - Highest ELO ever recorded
  - Most played opening per ELO range
  - Most played variation per ELO range
  - Time control distribution
  - Game termination types
  - Website distribution
  - Day vs Night play distribution
"""

import os
import re
import sys
from collections import defaultdict, Counter
from pathlib import Path
from datetime import datetime

# ---------------------------------------------------------------------------
# ELO ranges
# ---------------------------------------------------------------------------
ELO_RANGES = [
    (0,    100,  "0-100"),
    (100,  200,  "100-200"),
    (200,  300,  "200-300"),
    (300,  400,  "300-400"),
    (400,  500,  "400-500"),
    (500,  600,  "500-600"),
    (600,  700,  "600-700"),
    (700,  800,  "700-800"),
    (800,  900,  "800-900"),
    (900,  1000, "900-1000"),
    (1000, 1100, "1000-1100"),
    (1100, 1200, "1100-1200"),
    (1200, 1300, "1200-1300"),
    (1300, 1400, "1300-1400"),
    (1400, 1500, "1400-1500"),
    (1500, 1600, "1500-1600"),
    (1600, 1700, "1600-1700"),
    (1700, 1800, "1700-1800"),
    (1800, 1900, "1800-1900"),
    (1900, 2000, "1900-2000"),
    (2000, 99999,"2000+"),
]

def elo_bucket(elo: int) -> str:
    for lo, hi, label in ELO_RANGES:
        if lo <= elo < hi:
            return label
    return "2000+"

# ---------------------------------------------------------------------------
# PGN parser (no external dependencies)
# ---------------------------------------------------------------------------
TAG_RE = re.compile(r'\[(\w+)\s+"([^"]*)"\]')

def parse_pgn_file(filepath: str):
    """
    Yields one dict per game found in the PGN file.
    Each dict contains lowercased tag names as keys plus a 'moves' key.
    """
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    # Split on double-newline sequences that separate tag blocks
    # Strategy: split file into games by finding lines that start with [Event
    games_raw = re.split(r'\n(?=\[Event )', content)

    for raw in games_raw:
        if not raw.strip():
            continue
        tags = {}
        for m in TAG_RE.finditer(raw):
            tags[m.group(1).lower()] = m.group(2)
        if not tags:
            continue
        # Extract moves (everything after the last tag line)
        lines = raw.splitlines()
        move_lines = [l for l in lines if l and not l.startswith("[")]
        tags["moves"] = " ".join(move_lines).strip()
        yield tags

def find_pgn_files(root: str = "."):
    """Recursively find all .pgn files under root."""
    return list(Path(root).rglob("*.pgn"))

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def safe_int(value: str, default: int = -1) -> int:
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def detect_website(site: str, link: str) -> str:
    combined = (site + " " + link).lower()
    if "lichess" in combined:
        return "lichess.org"
    if "chess.com" in combined:
        return "chess.com"
    if combined.strip():
        # Try to extract domain
        m = re.search(r'([\w-]+\.\w+)', combined)
        if m:
            return m.group(1)
    return "Unknown"

def detect_termination(termination: str, result: str) -> str:
    t = (termination or "").lower()
    if "checkmate" in t or "mate" in t:
        return "Checkmate"
    if "time" in t or "forfeit" in t:
        return "Time forfeit"
    if "resign" in t:
        return "Resignation"
    if "draw" in t or "stalemate" in t or "repetition" in t or "insufficient" in t or "agreement" in t:
        return "Draw"
    if "abandon" in t:
        return "Abandoned"
    # Infer from result
    if result == "1/2-1/2":
        return "Draw"
    return "Other / Unknown"

def hour_from_time_tag(utctime: str) -> int | None:
    """Parse HH:MM:SS or HH:MM and return the hour."""
    m = re.match(r'(\d{1,2}):', utctime or "")
    if m:
        return int(m.group(1))
    return None

def is_night(hour: int) -> bool:
    """Night = 22:00-08:00 UTC."""
    return hour >= 22 or hour < 8

# ---------------------------------------------------------------------------
# Main analysis
# ---------------------------------------------------------------------------
def analyse(root: str = "."):
    pgn_files = find_pgn_files(root)
    if not pgn_files:
        print("❌  No .pgn files found under:", os.path.abspath(root))
        sys.exit(1)

    print(f"🔍  Found {len(pgn_files)} PGN file(s). Parsing...\n")

    # Accumulators
    total_games = 0
    event_counter        = Counter()
    player_counter       = Counter()
    website_counter      = Counter()
    termination_counter  = Counter()
    time_control_counter = Counter()
    day_night_counter    = Counter()

    highest_elo          = -1
    highest_elo_player   = "Unknown"

    # Per ELO-range: wins/draws
    range_results = {label: {"white": 0, "black": 0, "draw": 0, "total": 0}
                     for *_, label in ELO_RANGES}

    # Per ELO-range: opening counters  (label -> Counter of opening names)
    range_openings    = {label: Counter() for *_, label in ELO_RANGES}
    # Per ELO-range: variation counters (label -> Counter of ECO+variation)
    range_variations  = {label: Counter() for *_, label in ELO_RANGES}

    for pgn_path in pgn_files:
        for game in parse_pgn_file(str(pgn_path)):
            total_games += 1

            # --- Event ---
            event = game.get("event", "").strip() or "Unknown"
            event_counter[event] += 1

            # --- Players ---
            white = game.get("white", "").strip()
            black = game.get("black", "").strip()
            if white:
                player_counter[white] += 1
            if black:
                player_counter[black] += 1

            # --- ELOs ---
            white_elo = safe_int(game.get("whiteelo", "-1"))
            black_elo = safe_int(game.get("blackelo", "-1"))

            for elo, name in [(white_elo, white), (black_elo, black)]:
                if elo > highest_elo:
                    highest_elo = elo
                    highest_elo_player = name or "Unknown"

            # Use average ELO of the two players to bucket the game
            valid_elos = [e for e in [white_elo, black_elo] if e > 0]
            avg_elo = int(sum(valid_elos) / len(valid_elos)) if valid_elos else -1
            bucket = elo_bucket(avg_elo) if avg_elo >= 0 else None

            # --- Result ---
            result = game.get("result", "").strip()
            if bucket:
                r = range_results[bucket]
                r["total"] += 1
                if result == "1-0":
                    r["white"] += 1
                elif result == "0-1":
                    r["black"] += 1
                elif result == "1/2-1/2":
                    r["draw"] += 1

            # --- Opening / Variation ---
            opening   = game.get("opening",   "").strip()
            variation = game.get("variation", "").strip()
            eco       = game.get("eco",       "").strip()

            if bucket and opening:
                range_openings[bucket][opening] += 1
                full_var = f"{opening}: {variation}" if variation else opening
                range_variations[bucket][full_var] += 1

            # --- Time control ---
            tc = game.get("timecontrol", "").strip() or "Unknown"
            time_control_counter[tc] += 1

            # --- Termination ---
            termination_raw = game.get("termination", "").strip()
            term_label = detect_termination(termination_raw, result)
            termination_counter[term_label] += 1

            # --- Website ---
            site = game.get("site", "")
            link = game.get("link", "")
            website_counter[detect_website(site, link)] += 1

            # --- Time of day ---
            utctime = game.get("utctime", "").strip()
            if utctime:
                h = hour_from_time_tag(utctime)
                if h is not None:
                    day_night_counter["Night" if is_night(h) else "Day"] += 1

    # ---------------------------------------------------------------------------
    # Report
    # ---------------------------------------------------------------------------
    sep  = "=" * 70
    sep2 = "-" * 70

    def pct(n, total):
        return f"{n/total*100:.1f}%" if total else "N/A"

    print(sep)
    print("  ♟  CHESS PGN ANALYSIS REPORT")
    print(sep)
    print(f"  Total games analysed : {total_games:,}")
    print(f"  PGN files scanned    : {len(pgn_files)}")
    print()

    # 1. Event types
    print(sep2)
    print("  1. MOST PLAYED EVENT TYPES")
    print(sep2)
    for event, count in event_counter.most_common(10):
        print(f"  {count:>7,}  ({pct(count, total_games):>6})  {event}")
    print()

    # 2. Most mentioned player
    print(sep2)
    print("  2. MOST MENTIONED PLAYER")
    print(sep2)
    top_player, top_count = player_counter.most_common(1)[0] if player_counter else ("N/A", 0)
    print(f"  {top_player}  —  mentioned in {top_count:,} game(s)")
    print()
    print("  Top 10 players:")
    for p, c in player_counter.most_common(10):
        print(f"    {c:>7,}  {p}")
    print()

    # 3. Win rates by ELO range
    print(sep2)
    print("  3. WIN RATES BY ELO RANGE  (average ELO of both players)")
    print(sep2)
    print(f"  {'Range':<12}  {'Games':>7}  {'White':>8}  {'Black':>8}  {'Draw':>8}")
    print(f"  {'-'*12}  {'-'*7}  {'-'*8}  {'-'*8}  {'-'*8}")
    for *_, label in ELO_RANGES:
        r = range_results[label]
        t = r["total"]
        if t == 0:
            continue
        print(f"  {label:<12}  {t:>7,}  {pct(r['white'],t):>8}  {pct(r['black'],t):>8}  {pct(r['draw'],t):>8}")
    print()

    # 4. Highest ELO recorded
    print(sep2)
    print("  4. HIGHEST ELO EVER RECORDED")
    print(sep2)
    if highest_elo > 0:
        print(f"  {highest_elo_player}  —  ELO {highest_elo}")
    else:
        print("  No ELO data found.")
    print()

    # 5. Most played opening per ELO range
    print(sep2)
    print("  5. MOST PLAYED OPENING PER ELO RANGE")
    print(sep2)
    for *_, label in ELO_RANGES:
        c = range_openings[label]
        if not c:
            continue
        top_op, top_op_count = c.most_common(1)[0]
        total_range = range_results[label]["total"]
        print(f"  {label:<12}  ▶  {top_op}  ({top_op_count:,} games, {pct(top_op_count, total_range)})")
        # List all openings in this range
        all_ops = c.most_common()
        if len(all_ops) > 1:
            others = ", ".join(f"{op} ×{n}" for op, n in all_ops[1:])
            # Wrap at 80 chars
            for chunk in [others[i:i+80] for i in range(0, len(others), 80)]:
                print(f"              {chunk}")
        print()

    # 6. Most played variation per ELO range
    print(sep2)
    print("  6. MOST PLAYED VARIATION PER ELO RANGE")
    print(sep2)
    for *_, label in ELO_RANGES:
        c = range_variations[label]
        if not c:
            continue
        top_var, top_var_count = c.most_common(1)[0]
        total_range = range_results[label]["total"]
        print(f"  {label:<12}  ▶  {top_var}  ({top_var_count:,} games, {pct(top_var_count, total_range)})")
        all_vars = c.most_common()
        if len(all_vars) > 1:
            others = ", ".join(f"{v} ×{n}" for v, n in all_vars[1:])
            for chunk in [others[i:i+80] for i in range(0, len(others), 80)]:
                print(f"              {chunk}")
        print()

    # 7. Time controls
    print(sep2)
    print("  7. TIME CONTROL DISTRIBUTION")
    print(sep2)
    for tc, count in time_control_counter.most_common():
        print(f"  {count:>7,}  ({pct(count, total_games):>6})  {tc}")
    print()

    # 8. Termination types
    print(sep2)
    print("  8. HOW GAMES ENDED (TERMINATION)")
    print(sep2)
    for term, count in termination_counter.most_common():
        print(f"  {count:>7,}  ({pct(count, total_games):>6})  {term}")
    print()

    # 9. Website distribution
    print(sep2)
    print("  9. WEBSITE DISTRIBUTION")
    print(sep2)
    for site, count in website_counter.most_common():
        print(f"  {count:>7,}  ({pct(count, total_games):>6})  {site}")
    print()

    # 10. Day / Night
    print(sep2)
    print("  10. TIME OF DAY  (UTC — Night: 22:00-08:00 / Day: 08:00-22:00)")
    print(sep2)
    dn_total = sum(day_night_counter.values())
    if dn_total:
        for label in ["Night", "Day"]:
            count = day_night_counter.get(label, 0)
            print(f"  {label:<6}  {count:>7,}  ({pct(count, dn_total):>6})")
    else:
        print("  No UTCTime tags found in the PGN files.")
    print()

    print(sep)
    print("  ✅  Analysis complete.")
    print(sep)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    search_root = sys.argv[1] if len(sys.argv) > 1 else "."
    print(f"\n📂  Searching for .pgn files in: {os.path.abspath(search_root)}\n")
    analyse(search_root)
