   296	// Bar chart
   297	slide.addChart(pres.charts.BAR, [{
   298	  name: "Sales", labels: ["Q1", "Q2", "Q3", "Q4"], values: [4500, 5500, 6200, 7100]
   299	}], {
   300	  x: 0.5, y: 0.6, w: 6, h: 3, barDir: 'col',
   301	  showTitle: true, title: 'Quarterly Sales'
   302	});
   303	
   304	// Line chart
   305	slide.addChart(pres.charts.LINE, [{
   306	  name: "Temp", labels: ["Jan", "Feb", "Mar"], values: [32, 35, 42]
   307	}], { x: 0.5, y: 4, w: 6, h: 3, lineSize: 3, lineSmooth: true });
   308	
   309	// Pie chart
   310	slide.addChart(pres.charts.PIE, [{
   311	  name: "Share", labels: ["A", "B", "Other"], values: [35, 45, 20]
   312	}], { x: 7, y: 1, w: 5, h: 4, showPercent: true });
   313	
   314	// Scatter with a computed trend line (tier-2: stay native, add regression as a second series)
   315	const xs = [8, 12, 18, 22, 25, 31], ys = [102, 145, 198, 241, 267, 312];
   316	const n = xs.length, sx = xs.reduce((a,b)=>a+b), sy = ys.reduce((a,b)=>a+b);
   317	const sxy = xs.reduce((a,x,i)=>a+x*ys[i],0), sxx = xs.reduce((a,x)=>a+x*x,0);
   318	const m = (n*sxy - sx*sy)/(n*sxx - sx*sx), b = (sy - m*sx)/n;
   319	slide.addChart(pres.charts.SCATTER, [
   320	  { name: "X",     values: xs },
   321	  { name: "Data",  values: ys },
   322	  { name: "Trend", values: xs.map(x => m*x + b) },
   323	], { x: 0.5, y: 1, w: 9, h: 4 });
   324	