   225	head -3 /mnt/user-data/uploads/data.jsonl | jq .
   226	wc -l /mnt/user-data/uploads/data.jsonl
   227	