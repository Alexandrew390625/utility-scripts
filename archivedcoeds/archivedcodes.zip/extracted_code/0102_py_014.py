"""
diagnose_mca.py — Peek inside an .mca file and identify the chunk format.

Usage:
    python diagnose_mca.py path/to/file.mca
"""
import sys, struct, zlib, gzip, io

try:
    from nbt import nbt as nbtlib
except ImportError:
    sys.exit("pip install nbt")

SECTOR = 4096

def read_chunk_raw(mca_path, chunk_x=0, chunk_z=0):
    """Find and return the raw (still compressed) bytes of a chunk."""
    with open(mca_path, "rb") as f:
        header = f.read(SECTOR * 2)
        file_size = f.seek(0, 2)

    # Scan all 1024 chunks to find the first one that actually exists
    for cz in range(32):
        for cx in range(32):
            entry = (cx + cz * 32) * 4
            raw = struct.unpack(">I", header[entry:entry+4])[0]
            offset_sectors = raw >> 8
            size_sectors   = raw & 0xFF
            if offset_sectors == 0 or size_sectors == 0:
                continue
            byte_offset = offset_sectors * SECTOR
            if byte_offset + SECTOR > file_size:
                continue
            with open(mca_path, "rb") as f:
                f.seek(byte_offset)
                data = f.read(size_sectors * SECTOR)
            print(f"  First populated chunk: ({cx}, {cz})")
            print(f"  Raw chunk size on disk: {len(data)} bytes")
            print(f"  First 5 bytes (hex): {data[:5].hex()}")
            return cx, cz, data
    return None, None, None

def decompress(data):
    if len(data) < 5:
        return None
    length = struct.unpack(">I", data[0:4])[0]
    comp   = data[4]
    payload = data[5:5+length-1]
    print(f"  Compression type byte: {comp}  ", end="")
    if comp == 2:
        print("(zlib)")
        return zlib.decompress(payload)
    elif comp == 1:
        print("(gzip)")
        return gzip.decompress(payload)
    elif comp == 3:
        print("(uncompressed)")
        return payload
    else:
        print(f"(UNKNOWN — {comp})")
        return None

def inspect_nbt(raw_bytes):
    nbt_file = nbtlib.NBTFile(buffer=io.BytesIO(raw_bytes))

    print("\n  Top-level NBT keys:", list(nbt_file.keys()))

    # Detect format by looking for known keys
    if "sections" in nbt_file:
        print("  Format: 1.18+ (sections at root level)")
        sections = nbt_file["sections"]
    elif "Level" in nbt_file:
        level = nbt_file["Level"]
        print("  Format: pre-1.18 (has 'Level' key)")
        print("  Level keys:", list(level.keys()))

        if "Sections" in level:
            sections = level["Sections"]
            print(f"  Number of sections: {len(sections)}")

            if len(sections) > 0:
                s = sections[0]
                print(f"  Section[0] keys: {list(s.keys())}")

                if "Palette" in s or "block_states" in s:
                    print("  Block format: MODERN palette (1.13+)")
                elif "Blocks" in s:
                    print("  Block format: LEGACY numeric IDs (pre-1.13)")
                    blocks_tag = s["Blocks"]
                    print(f"  Blocks array length: {len(blocks_tag)}")
                    sample = [b for b in bytes(blocks_tag.value[:20])]
                    print(f"  First 20 block IDs: {sample}")
                else:
                    print("  Block format: UNKNOWN - section keys don't match known formats")
        else:
            print("  No 'Sections' found in Level")

        # Print DataVersion if available
        if "DataVersion" in nbt_file:
            dv = nbt_file["DataVersion"].value
            print(f"\n  DataVersion: {dv}  ", end="")
            # Map common DataVersions to MC versions
            versions = {
                (0, 99):    "pre-1.9",
                (100, 175): "1.9–1.10",
                (176, 510): "1.11",
                (511, 819): "1.12",
                (820, 1343): "1.13",
                (1344, 1631): "1.14",
                (1632, 2129): "1.15",
                (2130, 2584): "1.16",
                (2585, 2724): "1.17",
                (2725, 2860): "1.18",
                (2861, 3105): "1.19",
                (3106, 3337): "1.20",
                (3338, 9999): "1.21+",
            }
            for (lo, hi), label in versions.items():
                if lo <= dv <= hi:
                    print(f"→ approx Minecraft {label}")
                    break
            else:
                print()
        elif "DataVersion" in nbt_file:
            pass
        else:
            print("\n  No DataVersion found → likely very old world (pre-1.9)")
    else:
        print("  Format: UNKNOWN — no 'Level' or 'sections' key")

def main():
    if len(sys.argv) < 2:
        sys.exit("Usage: python diagnose_mca.py path/to/file.mca")

    path = sys.argv[1]
    print(f"Diagnosing: {path}")

    cx, cz, raw = read_chunk_raw(path)
    if raw is None:
        print("No populated chunks found in this file (all offsets are zero).")
        return

    decompressed = decompress(raw)
    if decompressed is None:
        print("Could not decompress chunk data.")
        return

    print(f"  Decompressed size: {len(decompressed):,} bytes")
    inspect_nbt(decompressed)

if __name__ == "__main__":
    main()
